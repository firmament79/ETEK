#ifndef MINI_V2_4_SE_h
#define MINI_V2_4_SE_h

    #define LED 13
    #define JO1 2
    #define JO2 3
    #define JO3 4
    #define JO4 5
    #define JO5 6
    #define JO6 7
    #define JO7 8
    #define JO8 9
    #define JO9 10
    #define JO10 11
    #define JSN1 12
    #define JSN2 14
    #define JSN3 15
    #define JSN4 16
    #define JSN5 17
    #define JSN6 18
    #define JSN7 19
    
class DefinePin_Mini_SE
{
    public:
    DefinePin_Mini_SE();

    private: 
};






#endif