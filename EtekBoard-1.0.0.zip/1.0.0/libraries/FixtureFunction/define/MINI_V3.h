/*
Fuse Set
LOW         E2
HIGH        D9
EXTENDED    FD
LOCKBIT     FF
*/
#ifndef MINI_V2_4_h
#define MINI_V2_4_h

    #define LED (13)
    #define JO1 (24)
    #define JO2 (5)
    #define JO3 (6)
    #define JO4 (7)
    #define JO5 (8)
    #define JO6 (9)
    #define JO7 (10)
    #define JSN1 (25)
    #define JSN2 (26)
    #define JSN3 (14)
    #define JSN4 (15)
    #define JSN5 (16)
    #define JSN6 (17)
    #define JSN7 (2)
    #define JSN8 (3)
    #define JSN9 (4)
    #define JSN10 (23)
    #define JSN11 (20)
    #define JSN12 (21)



#endif