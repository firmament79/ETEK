// Release Date: 2023.07.28
// Version: 1.0.0.0

#include    "Arduino.h"
#include    "FixtureFunction.h"


FixtureFunction::FixtureFunction(int pin)
{
    _pin = pin;
}

void FixtureFunction::isInput()
{
    pinMode(_pin, INPUT_PULLUP);
}

void FixtureFunction::isOutput()
{
    pinMode(_pin, OUTPUT);
}

void FixtureFunction::turnOn()
{
    digitalWrite(_pin, HIGH);
}

void FixtureFunction::turnOff()
{
    digitalWrite(_pin, LOW);
}

boolean FixtureFunction::checkNPN()
{
    if (digitalRead(_pin) == LOW){
        return true;
    }
    else{
        return false;
    }
}

boolean FixtureFunction::checkPNP()
{
    if (digitalRead(_pin) == HIGH){
        return true;
    }
    else{
        return false;
    }
}

void FixtureFunction::sw_debounce()
{
    int debounceDelay = 22;
    boolean currentState;  //current pin state
    boolean previousState; //previous pin state
    previousState = digitalRead(_pin); //record current state as previous

    for (int i = 0; i < debounceDelay; i++) //detect if stable
    {
      delay(1); //delay 1 ms
      currentState = digitalRead(_pin); //get current state
      if (currentState != previousState) //still unstable
      {
        i = 0; //reset counter
        previousState = currentState; //updtae previous state
      }
      while (digitalRead(_pin) == LOW);
    }
    return; //switch pressed (pull-up)
}


