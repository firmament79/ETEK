// Release Date: 2023.07.28
// Version: 1.0.0.0

#include    "Arduino.h"
#include    "FixtureFunction.h"


eName::eName(int pin)
{
    _pin = pin;
}

void eName::isInput()
{
    pinMode(_pin, INPUT_PULLUP);
}

void eName::isOutput()
{
    pinMode(_pin, OUTPUT);
}

void eName::On()
{
    digitalWrite(_pin, HIGH);
}

void eName::Off()
{
    digitalWrite(_pin, LOW);
}

boolean eName::checkNPN()
{
    if (digitalRead(_pin) == LOW){
        return true;
    }
    else{
        return false;
    }
}

// FixtureFunction
boolean eName::checkPNP()
{
    if (digitalRead(_pin) == HIGH){
        return true;
    }
    else{
        return false;
    }
}


//按鍵除彈跳
void eName::sw_debounce()
{
    int debounceDelay = 22;
    boolean currentState;  //current pin state
    boolean previousState; //previous pin state
    previousState = digitalRead(_pin); //record current state as previous

    for (int i = 0; i < debounceDelay; i++) //detect if stable
    {
      delay(1); //delay 1 ms
      currentState = digitalRead(_pin); //get current state
      if (currentState != previousState) //still unstable
      {
        i = 0; //reset counter
        previousState = currentState; //updtae previous state
      }
      while (digitalRead(_pin) == LOW);
    }
    return; //switch pressed (pull-up)
}


CoilGroup::CoilGroup(int pin1, int pin2)
{
    _pin1 = pin1;
    _pin2 = pin2;
}

void CoilGroup::On()
{
    // eName P1(_pin1);
    // eName P2(_pin2);
    // P1.On();
    // P2.Off();
    digitalWrite(_pin1, HIGH);
    digitalWrite(_pin2, LOW);
}

void CoilGroup::Off()
{
    // eName P1(_pin1);
    // eName P2(_pin2);
    // P1.Off();
    // P2.On();
    digitalWrite(_pin1, LOW);
    digitalWrite(_pin2, HIGH);
}

void CoilGroup::Stop()
{
    // eName P1(_pin1);
    // eName P2(_pin2);
    // P1.Off();
    // P2.Off();
    digitalWrite(_pin1, LOW);
    digitalWrite(_pin2, LOW);
}