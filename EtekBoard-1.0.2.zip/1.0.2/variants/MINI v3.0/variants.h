
#ifndef variants_h
  #define variants_h


  // Digital pins
  #define NUM_DIGITAL_PINS            (27)

  #if defined (__AVR_ATmega328PB__)

    //LED
    #if !defined(MLED)
        #define MLED (13)
    #endif
    static const uint8_t LED = MLED;


    #define PIN_WIRE_SDA  (18)
    #define PIN_WIRE_SCL  (19)
    static const uint8_t SDA = PIN_WIRE_SDA;
    static const uint8_t SCL = PIN_WIRE_SCL;

    #define JO1 (24)
    #define JO2 (5)
    #define JO3 (6)
    #define JO4 (7)
    #define JO5 (8)
    #define JO6 (9)
    #define JO7 (10)
    #define JSN1 (25)
    #define JSN2 (26)
    #define JSN3 (14)
    #define JSN4 (15)
    #define JSN5 (16)
    #define JSN6 (17)
    #define JSN7 (2)
    #define JSN8 (3)
    #define JSN9 (4)
    #define JSN10 (23)
    #define JSN11 (20)
    #define JSN12 (21)




    #ifdef ARDUINO_MAIN

      // These arrays map port names (e.g. port B) to the
      // appropriate addresses for various functions (e.g. reading
      // and writing)
      const uint16_t PROGMEM port_to_mode_PGM[] = {
        NOT_A_PORT,
        NOT_A_PORT,
        (uint16_t) &DDRB,
        (uint16_t) &DDRC,
        (uint16_t) &DDRD,
        (uint16_t) &DDRE,
      };

      const uint16_t PROGMEM port_to_output_PGM[] = {
        NOT_A_PORT,
        NOT_A_PORT,
        (uint16_t) &PORTB,
        (uint16_t) &PORTC,
        (uint16_t) &PORTD,
        (uint16_t) &PORTE,
      };

      const uint16_t PROGMEM port_to_input_PGM[] = {
        NOT_A_PORT,
        NOT_A_PORT,
        (uint16_t) &PINB,
        (uint16_t) &PINC,
        (uint16_t) &PIND,
        (uint16_t) &PINE,
      };

      const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
        PD, // PD0 - D0
        PD, // PD1 - D1
        PD, // PD2 - D2
        PD, // PD3 - D3
        PD, // PD4 - D4
        PD, // PD5 - D5
        PD, // PD6 - D6
        PD, // PD7 - D7
        PB, // PB0 - D8
        PB, // PB1 - D9
        PB, // PB2 - D10
        PB, // PB3 - D11
        PB, // PB4 - D12
        PB, // PB5 - D13
        PC, // PC0 - D14 / A0
        PC, // PC1 - D15 / A1
        PC, // PC2 - D16 / A2
        PC, // PC3 - D17 / A3
        PC, // PC4 - D18 / A4
        PC, // PC5 - D19 / A5
        PB, // PB6 - D20 / XTAL1
        PB, // PB7 - D21 / XTAL2
        PC, // PC6 - D22 / RESET
        PE, // PE0 - D23
        PE, // PE1 - D24
        PE, // PE2 - D25 / A6
        PE, // PE3 - D26 / A7
      };

      const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
        _BV(0), // PD0 - D0
        _BV(1), // PD1 - D1
        _BV(2), // PD2 - D2
        _BV(3), // PD3 - D3
        _BV(4), // PD4 - D4
        _BV(5), // PD5 - D5
        _BV(6), // PD6 - D6
        _BV(7), // PD7 - D7
        _BV(0), // PB0 - D8
        _BV(1), // PB1 - D9
        _BV(2), // PB2 - D10
        _BV(3), // PB3 - D11
        _BV(4), // PB4 - D12
        _BV(5), // PB5 - D13
        _BV(0), // PC0 - D14 / A0
        _BV(1), // PC1 - D15 / A1
        _BV(2), // PC2 - D16 / A2
        _BV(3), // PC3 - D17 / A3
        _BV(4), // PC4 - D18 / A4
        _BV(5), // PC5 - D19 / A5
        _BV(6), // PB6 - D20 / XTAL1
        _BV(7), // PB7 - D21 / XTAL2
        _BV(6), // PC6 - D22 / RESET
        _BV(0), // PE0 - D23
        _BV(1), // PE1 - D24
        _BV(2), // PE2 - D25 / A6
        _BV(3), // PE3 - D26 / A7
      };

      const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
        TIMER3A,      // PD0 - D0
        TIMER4A,      // PD1 - D1
        TIMER4B,      // PD2 - D2 -> TIMER3B is also an option
        TIMER2B,      // PD3 - D3
        NOT_ON_TIMER, // PD4 - D4
        TIMER0B,      // PD5 - D5
        TIMER0A,      // PD6 - D6
        NOT_ON_TIMER, // PD7 - D7
        NOT_ON_TIMER, // PB0 - D8
        TIMER1A,      // PB1 - D9
        TIMER1B,      // PB2 - D10
        TIMER2A,      // PB3 - D11
        NOT_ON_TIMER, // PB4 - D12
        NOT_ON_TIMER, // PB5 - D13
        NOT_ON_TIMER, // PC0 - D14 / A0
        NOT_ON_TIMER, // PC1 - D15 / A1
        NOT_ON_TIMER, // PC2 - D16 / A2
        NOT_ON_TIMER, // PC3 - D17 / A3
        NOT_ON_TIMER, // PC4 - D18 / A4
        NOT_ON_TIMER, // PC5 - D19 / A5
        NOT_ON_TIMER, // PB6 - D20 / XTAL1
        NOT_ON_TIMER, // PB7 - D21 / XTAL2
        NOT_ON_TIMER, // PC6 - D22 / RESET
        NOT_ON_TIMER, // PE0 - D23
        NOT_ON_TIMER, // PE1 - D24
        NOT_ON_TIMER, // PE2 - D25 / A6
        NOT_ON_TIMER, // PE3 - D26 / A7
      };

    #endif // ARDUINO_MAIN





      class etekPinMode
      {
          public:
              etekPinMode();
      };




  #endif



#endif