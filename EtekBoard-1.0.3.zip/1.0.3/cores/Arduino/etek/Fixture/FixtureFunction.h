// Release Date: 2023.07.28
// Version: 1.0.0.0

#ifndef FixtureFunction_h
#define FixtureFunction_h



#include "Arduino.h"
// #include "BoardDefine.h"




class eName
{
    public:
        #define isIn isInput()
        #define isOut isOutput()
        // void ON = On();
        #define ON On()
        #define setOn On()
        #define OFF Off()
        #define setOff Off()
        #define isLow checkNPN()
        #define checkLow checkNPN()
        #define isHigh checkPNP()
        #define ckeckHigh checkPNP()
        #define debounce sw_debounce()

        eName(int pin);
        // CoilGroup(int pin1, int pin2);
        // eName(int pin);
        // uint8_t CoilGroup2(int pin1, int pin2);
        void isInput();
        void isOutput();
        void On();
        void Off();
        boolean checkNPN();
        boolean checkPNP();
        void sw_debounce();

    private:
        int _pin;
        
};

class CoilGroup
{
    public:
        #define gOn On()
        #define gOff Off()
        #define gStop Stop()
        CoilGroup(int pin1, int pin2);
        void On();
        void Off();
        void Stop();

    private:
        int _pin1;
        int _pin2;
};




#endif