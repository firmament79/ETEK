#include "Arduino.h"
#include "variants.h"

etekPinMode::etekPinMode()
{
    pinMode(LED, OUTPUT);
    pinMode(JO1, OUTPUT);
    pinMode(JO2, OUTPUT);
    pinMode(JO3, OUTPUT);
    pinMode(JO4, OUTPUT);
    pinMode(JO5, OUTPUT);
    pinMode(JO6, OUTPUT);
    pinMode(JO7, OUTPUT);
    pinMode(JO8, OUTPUT);
    pinMode(JO9, OUTPUT);
    pinMode(JO10, OUTPUT);    
    pinMode(JSN1, INPUT_PULLUP);
    pinMode(JSN2, INPUT_PULLUP);
    pinMode(JSN3, INPUT_PULLUP);
    pinMode(JSN4, INPUT_PULLUP);
    pinMode(JSN5, INPUT_PULLUP);
    pinMode(JSN6, INPUT_PULLUP);
    pinMode(JSN7, INPUT_PULLUP);

}