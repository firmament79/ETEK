// Release Date: 2023.07.28
// Version: 1.0.0.0

#include    "Arduino.h"
#include    "FixtureFunction.h"


eName::eName(int pin, boolean func)
{
    _pin = pin;
    _func = func;
}

void eName::isInput()
{
    pinMode(_pin, INPUT_PULLUP);
}

void eName::isOutput()
{
    pinMode(_pin, OUTPUT);
}

void eName::on()
{
    digitalWrite(_pin, _func);
}

void eName::off()
{
    digitalWrite(_pin, !_func);
}

boolean eName::check()
{
    if (digitalRead(_pin) == _func){
        return true;
    }
    else{
        return false;
    }
}

// // FixtureFunction
// boolean eName::checkPNP()
// {
//     if (digitalRead(_pin) == HIGH){
//         return true;
//     }
//     else{
//         return false;
//     }
// }


//按鍵除彈跳
void eName::sw_debounce()
{
    int debounceDelay = 22;
    boolean currentState;  //current pin state
    boolean previousState; //previous pin state
    previousState = digitalRead(_pin); //record current state as previous

    for (int i = 0; i < debounceDelay; i++) //detect if stable
    {
      delay(1); //delay 1 ms
      currentState = digitalRead(_pin); //get current state
      if (currentState != previousState) //still unstable
      {
        i = 0; //reset counter
        previousState = currentState; //updtae previous state
      }
      while (digitalRead(_pin) == LOW);
    }
    return; //switch pressed (pull-up)
}


gName::gName(int pin1, int pin2, boolean func)
{
    _pin1 = pin1;
    _pin2 = pin2;
    _func = func;
}

void gName::on()
{    
    digitalWrite(_pin1, _func);
    digitalWrite(_pin2, !_func);
}

void gName::off()
{    
    digitalWrite(_pin1, !_func);
    digitalWrite(_pin2, _func);
}

void gName::stop()
{    
    digitalWrite(_pin1, !_func);
    digitalWrite(_pin2, !_func);
}

boolean gName::checkOn()
{
    if (digitalRead(_pin2) == _func) {
        return true;
    }
    else {
        return false;
    }
}

boolean gName::checkOff()
{
    if (digitalRead(_pin1) == _func) {
        return true;
    }
    else {
        return false;
    }
}


// //雙線圈 sol1啟動 sol2初始
// DoubleSolenoid::DoubleSolenoid(int sol1, int sol2, boolean func)
// {
//     _sol1 = sol1;
//     _sol2 = sol2;
//     _func = func;
// }

// void DoubleSolenoid::on()
// {    
//     digitalWrite(_sol1, _func);
//     digitalWrite(_sol2, !_func);
// }

// void DoubleSolenoid::off()
// {    
//     digitalWrite(_sol1, !_func);
//     digitalWrite(_sol2, _func);
// }

// void DoubleSolenoid::Stop()
// {    
//     digitalWrite(_sol1, !_func);
//     digitalWrite(_sol2, !_func);
// }


// //感應器組 sen1覆歸位置 sen2執行位置 func檢測閾值(HIGH/LOW)
// SensorGroup::SensorGroup(int sen1, int sen2, boolean func)
// {
//     _sen1 = sen1;
//     _sen2 = sen2;
//     _func = func;
// }

// boolean SensorGroup::on()
// {
//     if (digitalRead(_sen2) == _func) {
//         return true;
//     }
//     else {
//         return false;
//     }
// }

// boolean SensorGroup::off()
// {
//     if (digitalRead(_sen1) == _func) {
//         return true;
//     }
//     else {
//         return false;
//     }
// }

// boolean SensorGroup::unknow()
// {
//     if ((digitalRead(_sen1) != _func) && digitalRead(_sen2) != _func){
//         return true;
//     }
//     else{
//         return false;
//     }
// }