// Release Date: 2024.02.21
// Version: 1.0.4

#include    "Arduino.h"
#include    "FixtureFunction.h"


eName::eName(int pin, boolean func)
{
    _pin = pin;
    _func = func;
}

void eName::isInput()
{
    pinMode(_pin, INPUT_PULLUP);
}

void eName::isOutput()
{
    pinMode(_pin, OUTPUT);
}

void eName::on()
{
    digitalWrite(_pin, _func);
}

void eName::off()
{
    digitalWrite(_pin, !_func);
}

boolean eName::check()
{
    if (digitalRead(_pin) == _func){
        return true;
    }
    else{
        return false;
    }
}


//按鍵除彈跳
void eName::sw_debounce()
{
    int debounceDelay = 22;
    boolean currentState;  //current pin state
    boolean previousState; //previous pin state
    previousState = digitalRead(_pin); //record current state as previous

    for (int i = 0; i < debounceDelay; i++) //detect if stable
    {
      delay(1); //delay 1 ms
      currentState = digitalRead(_pin); //get current state
      if (currentState != previousState) //still unstable
      {
        i = 0; //reset counter
        previousState = currentState; //updtae previous state
      }
      while (digitalRead(_pin) == LOW);
    }
    return; //switch pressed (pull-up)
}


gName::gName(int pin1, int pin2, boolean func)
{
    _pin1 = pin1;
    _pin2 = pin2;
    _func = func;
}

void gName::on()
{    
    digitalWrite(_pin1, _func);
    digitalWrite(_pin2, !_func);
}

void gName::off()
{    
    digitalWrite(_pin1, !_func);
    digitalWrite(_pin2, _func);
}

void gName::stop()
{    
    digitalWrite(_pin1, !_func);
    digitalWrite(_pin2, !_func);
}

boolean gName::checkOn()
{
    if (digitalRead(_pin2) == _func) {
        return true;
    }
    else {
        return false;
    }
}

boolean gName::checkOff()
{
    if (digitalRead(_pin1) == _func) {
        return true;
    }
    else {
        return false;
    }
}

