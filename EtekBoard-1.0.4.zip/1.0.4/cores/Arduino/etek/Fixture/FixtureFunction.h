// Release Date: 2023.07.28
// Version: 1.0.0.0

#ifndef FixtureFunction_h
#define FixtureFunction_h



#include "Arduino.h"
// #include "BoardDefine.h"




class eName
{
    public:
        #define isIn isInput()
        #define isOut isOutput()
        // void ON = on();
        #define ON on()
        #define setOn on()
        #define OFF off()
        #define setOff off()
        #define isTrue check()
        // #define isLow check()
        // #define checkLow check()
        // #define isHigh checkPNP()
        // #define ckeckHigh checkPNP()
        #define debounce sw_debounce()

        eName(int pin, boolean func);
        // CoilGroup(int pin1, int pin2);
        // eName(int pin);
        // uint8_t CoilGroup2(int pin1, int pin2);
        void isInput();
        void isOutput();
        void on();
        void off();
        boolean check();
        // boolean checkNPN();
        // boolean checkPNP();
        void sw_debounce();

    private:
        int _pin;
        boolean _func;
        
};

class gName
{
    public:
        #define gOn on()
        #define gOff off()
        #define gStop stop()
        #define isAct checkOn()
        #define isRst checkOff()
        gName(int pin1, int pin2, boolean func);
        void on();
        void off();
        void stop();
        boolean checkOn();
        boolean checkOff();

    private:
        int _pin1;
        int _pin2;
        boolean _func;
};


// class DoubleSolenoid
// {
//     public:
//         #define gOn on()
//         #define gOff off()
//         #define gStop Stop()
//         DoubleSolenoid(int sol1, int sol2, boolean func);
//         void on();
//         void off();
//         void Stop();
//     private:
//         int _sol1;
//         int _sol2;
//         boolean _func;
// };

// class SensorGroup
// {
//     public:
//         #define isAct on()
//         #define isRst off()
//         #define snUn unknow()
//         SensorGroup(int sen1, int sen2, boolean func);
//         boolean on();
//         boolean off();
//         boolean unknow();

//     private:
//         int _sen1;
//         int _sen2;
//         boolean _func;
// };



#endif