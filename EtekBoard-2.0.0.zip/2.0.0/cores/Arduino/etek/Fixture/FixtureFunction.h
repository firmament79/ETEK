// Release Date: 2024.02.21
// Version: 2.0.0

#ifndef FixtureFunction_h
#define FixtureFunction_h



#include "Arduino.h"




class eName
{
    public:
        #define isIn isInput()
        #define isOut isOutput()
        // void ON = on();
        #define ON on()
        #define setOn on()
        #define OFF off()
        #define setOff off()
        #define isTrue check()
        #define debounce sw_debounce()

        eName(int pin, boolean func);
        void isInput();
        void isOutput();
        void on();
        void off();
        boolean check();
        void sw_debounce();

    private:
        int _pin;
        boolean _func;
        
};

class gName
{
    public:
        #define gOn on()
        #define gOff off()
        #define gStop stop()
        #define isAct checkOn()
        #define isRst checkOff()
        gName(int pin1, int pin2, boolean func);
        void on();
        void off();
        void stop();
        boolean checkOn();
        boolean checkOff();

    private:
        int _pin1;
        int _pin2;
        boolean _func;
};




#endif