// pinref.h

#pragma once
#include "board_config.h"

// extern const PinInit pinMap[];

// inline const PinInit* getPinInit(uint8_t pin) {
//   static PinInit tmp;
//   if (pin >= sizeof(pinMap)/sizeof(pinMap[0])) return nullptr;
//   memcpy_P(&tmp, &pinMap[pin], sizeof(PinInit));
//   return &tmp;
// }


class PinRef {
public:
  PinRef(uint8_t pin) : pin(getPinInit(pin)) {}
  PinRef(const PinInit* init) : pin(init) {}

  void on() const { *pin->port |= (1 << pin->bit); }
  void off() const { *pin->port &= ~(1 << pin->bit); }
  void toggle() const { *pin->port ^= (1 << pin->bit); }
  bool get() const { return (*(pin->port - 2)) & (1 << pin->bit); }

  void setOutput() const { *pin->ddr |= (1 << pin->bit); }
  void setInputPullup() const {
    *pin->ddr &= ~(1 << pin->bit);
    *pin->port |= (1 << pin->bit);
  }

private:
  const PinInit* pin;
};