#pragma once
#include <Arduino.h>

inline void on(uint8_t pin) { digitalWrite(pin, HIGH); }
inline void off(uint8_t pin) { digitalWrite(pin, LOW); }
inline void toggle(uint8_t pin) { digitalWrite(pin, !digitalRead(pin)); }
inline bool get(uint8_t pin) { return digitalRead(pin); }
inline void setOutput(uint8_t pin) { pinMode(pin, OUTPUT); }
inline void setInputPullup(uint8_t pin) { pinMode(pin, INPUT_PULLUP); }
