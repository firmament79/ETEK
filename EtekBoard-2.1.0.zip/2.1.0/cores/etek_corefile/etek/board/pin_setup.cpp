// [EtekBoard 專用] 低階腳位初始化
// 此檔案由 EtekBoard 專案維護，非 Arduino 官方核心一部分


#include "pin_setup.h"
#include "board_config.h"

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
  #else
    #define CONSTEXPR const
  #endif
#else
  #define CONSTEXPR const
#endif


// --- 初始化函式實作 ---
void initOutputPins() {
  for (uint8_t i = 0; i < sizeof(OUTPUT_PINS) / sizeof(PinInit); i++) {
    PinInit temp;
    memcpy_P(&temp, &OUTPUT_PINS[i], sizeof(PinInit)); // 從PROGMEM讀出資料
    *(temp.ddr) |= (1 << temp.bit);
  }
}

void initInputPullupPins() {
  for (uint8_t i = 0; i < sizeof(INPUT_PULLUP_PINS) / sizeof(PinInit); i++) {
    PinInit temp;
    memcpy_P(&temp, &INPUT_PULLUP_PINS[i], sizeof(PinInit));
    *(temp.ddr) &= ~(1 << temp.bit);
    *(temp.port) |= (1 << temp.bit);
  }
}

void initInputPins() {
  for (uint8_t i = 0; i < sizeof(INPUT_PINS) / sizeof(PinInit); i++) {
    PinInit temp;
    memcpy_P(&temp, &INPUT_PINS[i], sizeof(PinInit));
    *(temp.ddr) &= ~(1 << temp.bit);
    *(temp.port) &= ~(1 << temp.bit);
  }
}

// void initVariant(void) {
//     Serial.begin(9600);
//   Serial.println(F("initVariant() called1"));

//   // pinMode(13, OUTPUT);

//   initOutputPins();
//   initInputPullupPins();
//   initInputPins();


// }