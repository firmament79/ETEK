#include "SerialCommand.h"

#define FSH(str) (reinterpret_cast<const __FlashStringHelper*>(str))

static inline void trim(char* str) {
  char* p = str;
  while (isspace(*p)) ++p;
  size_t len = strlen(p);
  while (len > 0 && isspace(p[len - 1])) --len;
  p[len] = '\0';
  memmove(str, p, len + 1);
}

#if SERIALCOMMAND_USE_EMOJI
const char status_0[]  PROGMEM = "None";
const char status_1[]  PROGMEM = "🔵FINISH";
const char status_2[]  PROGMEM = "❔WAITING";
const char status_3[]  PROGMEM = "❕CHECK";
const char status_4[]  PROGMEM = "🟣PROGRESS";
const char status_5[]  PROGMEM = "🟠BUSY";
const char status_6[]  PROGMEM = "🟢START";
const char status_7[]  PROGMEM = "🔴STOP";
const char status_8[]  PROGMEM = "🟡PAUSE";
const char status_9[]  PROGMEM = "🟢RESUME";
const char status_10[] PROGMEM = "⚪RESET";
const char status_11[] PROGMEM = "⚙️SETPARAM";
//自節offset的方式
// const char statusMessages[] PROGMEM =
//   "None\0"
//   "🔵FINISH\0"
//   "❔WAITING\0"
//   "❕CHECK\0"
//   "🟣PROGRESS\0"
//   "🟠BUSY\0"
//   "🟢START\0"
//   "🔴STOP\0"
//   "🟡PAUSE\0"
//   "🟢RESUME\0"
//   "⚪RESET\0"
//   "⚙️SETPARAM\0";

// const uint16_t statusOffsets[] PROGMEM = {
//   0, 5, 14, 23, 31, 43, 51, 60, 68, 78, 87, 94
// };
#else
const char status_0[]  PROGMEM = "None";
const char status_1[]  PROGMEM = "FINISH";
const char status_2[]  PROGMEM = "WAITING";
const char status_3[]  PROGMEM = "CHECK";
const char status_4[]  PROGMEM = "PROGRESS";
const char status_5[]  PROGMEM = "BUSY";
const char status_6[]  PROGMEM = "START";
const char status_7[]  PROGMEM = "STOP";
const char status_8[]  PROGMEM = "PAUSE";
const char status_9[]  PROGMEM = "RESUME";
const char status_10[] PROGMEM = "RESET";
const char status_11[] PROGMEM = "SETPARAM";
//自節offset的方式
// const char statusMessages[] PROGMEM =
//   "None\0"
//   "FINISH\0"
//   "WAITING\0"
//   "CHECK\0"
//   "PROGRESS\0"
//   "BUSY\0"
//   "START\0"
//   "STOP\0"
//   "PAUSE\0"
//   "RESUME\0"
//   "RESET\0"
//   "SETPARAM\0";

// const uint16_t statusOffsets[] PROGMEM = {
//   0, 5, 12, 20, 26, 35, 40, 46, 51, 57, 64, 70
// };
#endif

//用offset這行要隱藏
const char* const STATUS_MESSAGES[STATUS_COUNT] PROGMEM ={
    status_0,    status_1,    status_2,    status_3,    status_4,    status_5,
    status_6,    status_7,    status_8,    status_9,    status_10,    status_11,
};


const char cmd_0[] PROGMEM = "start";
const char cmd_1[] PROGMEM = "stop";
const char cmd_2[] PROGMEM = "reset";
const char cmd_3[] PROGMEM = "pause";
const char cmd_4[] PROGMEM = "resume";
const char cmd_5[] PROGMEM = "set";

const char* const CMD_STRING[CMD_COUNT] PROGMEM = {
  cmd_0, cmd_1, cmd_2, cmd_3, cmd_4, cmd_5
};

const char msgExecuting[] PROGMEM = " Executing: ";
const char msgUnknown[]   PROGMEM = " Unknown: ";
const char msgStatus[]    PROGMEM = "Status: ";


int8_t matchCommand(const char* command) {
  char temp[8];
  for (int i = 0; i < CMD_COUNT; i++) {
    strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
    if (strcmp(command, temp) == 0) return i;
  }
  return -1;
}


SerialCommand::SerialCommand(char breakChar_, unsigned long timeout_) 
  : index(0), lastByteTime(0), commandTimeout(timeout_), breakChar(breakChar_), cmd("") {
    memset(inputBuffer, 0, BUFFER_SIZE);
}

void SerialCommand::begin(long baudrate) {
    Serial.begin(baudrate);
}

void SerialCommand::handle() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        lastByteTime = millis();

        if (c == breakChar) {
            inputBuffer[index] = '\0';
            // String command = String(inputBuffer);
            // command.trim();
            trim(inputBuffer);
            checkCommand(inputBuffer);

            // checkCommand(command.c_str());

            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
        else if (isPrintable(c)) {
            if (index < BUFFER_SIZE - 1) {
                inputBuffer[index++] = c;
            }
            else {
                DEBUG_PRINT(F("Buffer overflow. Resetting buffer."));
                index = 0;
                memset(inputBuffer, 0, BUFFER_SIZE);
            }
        }
        else if (c == '\r' || c == '\n') {
            // 忽略回車換行
        }
        else {
            DEBUG_PRINT(F("Invalid character: 0x"));
            DEBUG_PRINTLN((c, HEX));
            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
    }

    if (index > 0 && millis() - lastByteTime > commandTimeout) {
        inputBuffer[index] = '\0';
        // String errCommand = String(inputBuffer);
        // errCommand.trim();
        // trim(inputBuffer);

        DEBUG_PRINTLN(F("Command timeout. Discarding incomplete command."));
        #if SERIALCOMMAND_USE_EMOJI
          Serial.print(F("⛔"));
        #endif
        Serial.print(F(" Command must end with '"));
        Serial.print(breakChar);
        Serial.println(F("'"));
        DEBUG_PRINT(F("Your command: "));
        DEBUG_PRINTLN(inputBuffer);
        index = 0;
        memset(inputBuffer, 0, BUFFER_SIZE);
    }
}


void SerialCommand::checkCommand(const char* command) {
  int8_t idx = matchCommand(command);
  if (idx >= 0 && idx < CMD_COUNT) {
    strcpy_P(cmd, (PGM_P)pgm_read_ptr(&CMD_STRING[idx]));
    #if SERIALCOMMAND_USE_EMOJI
        Serial.print(F("✔️"));
    #endif
    Serial.println(FSH(msgExecuting));
    Serial.println(cmd);
  } else {
    #if SERIALCOMMAND_USE_EMOJI
        Serial.print(F("⚠️"));
    #endif
    Serial.print(FSH(msgUnknown));
    Serial.println(command);
    cmd[0] = '\0';
    showCommands();
  }
}



void SerialCommand::showCommands() {
  char temp[8];
        #if SERIALCOMMAND_USE_EMOJI
          Serial.print(F("💬"));
        #endif
        Serial.println(F(" Available commands:"));
        for (int i = 0; i < CMD_COUNT; i++) {
          strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
          #if SERIALCOMMAND_USE_EMOJI
              Serial.print(F("✔️"));
          #else
              Serial.print(F(" "));
          #endif
          Serial.print(temp);
          Serial.print(breakChar);
        }
  Serial.println();
}



const char* SerialCommand::getCommand() {
    static char result[BUFFER_SIZE];
    strncpy(result, cmd, BUFFER_SIZE);
    cmd[0] = '\0';
    return result;
}


void SerialCommand::printStatus(SystemStatus status, const __FlashStringHelper* prefix) {
  if (status < STATUS_COUNT) {
    char buffer[20];
    strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
    if (prefix) {
      Serial.print(prefix);
    } else {
      #if SERIALCOMMAND_USE_EMOJI
        Serial.print(F("⚪"));
      #endif
      Serial.print(FSH(msgStatus));
    }
    Serial.println(buffer);
  } else {
      #if SERIALCOMMAND_USE_EMOJI
        DEBUG_PRINTLN(F("⚠️"));
      #endif
      DEBUG_PRINTLN(F(" Invalid status."));
  }
}


//自節offset的方式
// void SerialCommand::printStatus(SystemStatus status, const __FlashStringHelper* prefix) {
//   if (status < STATUS_COUNT) {
//     char buffer[20];  // 最長字串含 emoji 也不會超過 24
//     uint16_t offset = pgm_read_word(&statusOffsets[status]);
//     strcpy_P(buffer, statusMessages + offset);

//     if (prefix) {
//       Serial.print(prefix);
//     } else {
// #if SERIALCOMMAND_USE_EMOJI
//       Serial.print(F("⚪"));
// #endif
//       Serial.print(F("Status: "));
//     }

//     Serial.println(buffer);
//   } else {
// #if SERIALCOMMAND_USE_EMOJI
//     Serial.println(F("⚠️ Invalid status"));
// #else
//     Serial.println(F("Invalid status"));
// #endif
//   }
// }