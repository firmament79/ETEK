#ifndef SERIALCOMMAND_H
#define SERIALCOMMAND_H

#include "Arduino.h"


// === DEBUG 開關（使用者可在主程式中 #define SERIALCOMMAND_DEBUG 開啟） ===
#ifndef SERIALCOMMAND_DEBUG
#define SERIALCOMMAND_DEBUG 0
#endif

#if SERIALCOMMAND_DEBUG
  #define DEBUG_PRINT(x) Serial.print(x)
  #define DEBUG_PRINTLN(x) Serial.println(x)
#else
  #define DEBUG_PRINT(x)
  #define DEBUG_PRINTLN(x)
#endif

#ifndef SERIALCOMMAND_USE_EMOJI
#define SERIALCOMMAND_USE_EMOJI 1  // 預設開啟，若空間不足可關閉
#endif


#ifdef __cplusplus


// ✅ 狀態列舉
enum SystemStatus : uint8_t {
  STATUS_NONE,
  STATUS_FINISH,
  STATUS_WAIT,
  STATUS_CHECK,
  STATUS_PGRS,
  STATUS_BUSY,
  STATUS_START,
  STATUS_STOP,
  STATUS_PAUSE,
  STATUS_RESUME,
  STATUS_RESET,
  STATUS_SET,
  STATUS_COUNT
};



// // ✅ 狀態對應訊息（在 .cpp 定義）
// extern const char* STATUS_MESSAGES[STATUS_COUNT];
extern const char* const STATUS_MESSAGES[STATUS_COUNT];


enum CommandIndex : uint8_t {
    CMD_START,
    CMD_STOP,
    CMD_RESET,
    CMD_PAUSE,
    CMD_RESUME,
    CMD_SET,
    CMD_COUNT
};

extern const char* const CMD_STRING[CMD_COUNT] PROGMEM;

int8_t matchCommand(const String& command);  // 可選：提供 enum 回傳

class SerialCommand {
public:
    SerialCommand(char breakChar = ';', unsigned long timeout = 500);

    void begin(long baudrate);
    void handle();
    const char* getCommand();

    void printStatus(SystemStatus status, const __FlashStringHelper* prefix = nullptr);

private:
    static const byte BUFFER_SIZE = 32;
    char inputBuffer[BUFFER_SIZE];
    char cmd[BUFFER_SIZE];  // 儲存上一個命令

    byte index;
    unsigned long lastByteTime;
    unsigned long commandTimeout;
    char breakChar;

    // String cmd;
    // void trim(char* s);
    void checkCommand(const char* command);
    void showCommands();
};

#else

#endif

#endif // SERIALCOMMAND_H