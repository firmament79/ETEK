#pragma once
#include <Arduino.h>

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
    #define NULLVALUE nullptr
  #else
    #define CONSTEXPR const
    #define NULLVALUE NULL
  #endif
#else
  #define CONSTEXPR const
  #define NULLVALUE NULL
#endif



typedef struct {
  volatile uint8_t* ddr;
  volatile uint8_t* port;
  uint8_t bit;
} PinInit;

// --- Arduino 腳位名稱定義（提供 digitalWrite 調用） ---

CONSTEXPR uint8_t LED   = 13; //PB5

CONSTEXPR uint8_t JO1   = 2;  //PD2
CONSTEXPR uint8_t JO2   = 3;  //PD3
CONSTEXPR uint8_t JO3   = 4;  //PD4
CONSTEXPR uint8_t JO4   = 5;  //PD5
CONSTEXPR uint8_t JO5   = 6;  //PD6
CONSTEXPR uint8_t JO6   = 7;  //PD7
CONSTEXPR uint8_t JO7   = 8;  //PB0
CONSTEXPR uint8_t JO8   = 9;  //PB1
CONSTEXPR uint8_t JO9   = 10; //PB2
CONSTEXPR uint8_t JO10  = 11; //PB3

CONSTEXPR uint8_t JSN1  = 12; //PB4
CONSTEXPR uint8_t JSN2  = 14; //PC0
CONSTEXPR uint8_t JSN3  = 15; //PC1
CONSTEXPR uint8_t JSN4  = 16; //PC2
CONSTEXPR uint8_t JSN5  = 17; //PC3
CONSTEXPR uint8_t JSN6  = 18; //PC4
CONSTEXPR uint8_t JSN7  = 19; //PC5




// --- 底層控制定義 ---

// --- 輸出腳位定義 ---
const PinInit OUTPUT_PINS[] PROGMEM = {
  { &DDRB, NULLVALUE, PB5 }, // LED (13)
  { &DDRD, NULLVALUE, PD2 }, // JO1 (2)
  { &DDRD, NULLVALUE, PD3 }, // JO2 (3)
  { &DDRD, NULLVALUE, PD4 }, // JO3 (4)
  { &DDRD, NULLVALUE, PD5 }, // JO4 (5)
  { &DDRD, NULLVALUE, PD6 }, // JO5 (6)
  { &DDRD, NULLVALUE, PD7 }, // JO6 (7)
  { &DDRB, NULLVALUE, PB0 }, // JO7 (8)
  { &DDRB, NULLVALUE, PB1 }, // JO8 (9)
  { &DDRB, NULLVALUE, PB2 }, // JO9 (10)
  { &DDRB, NULLVALUE, PB3 }, // JO10 (11)
};


// --- 輸入+上拉腳位定義 ---
const PinInit INPUT_PULLUP_PINS[] PROGMEM = {
  { &DDRB, &PORTB, PB4 },  // JSN1 (12)
  { &DDRC, &PORTC, PC0 },  // JSN2 (14)
  { &DDRC, &PORTC, PC1 },  // JSN3 (15)
  { &DDRC, &PORTC, PC2 },  // JSN4 (16)
  { &DDRC, &PORTC, PC3 },  // JSN5 (17)
  { &DDRC, &PORTC, PC4 },  // JSN6 (18)
  { &DDRC, &PORTC, PC5 },  // JSN7 (19)
};

// --- 輸入腳位定義（無上拉） ---
const PinInit INPUT_PINS[] PROGMEM = {
  // 若有，放在這邊
};


static const PinInit pinMap[] = {
  { &DDRD, &PORTD, PD0 },  // 0
  { &DDRD, &PORTD, PD1 },  // 1
  { &DDRD, &PORTD, PD2 },  // 2  = JO1
  { &DDRD, &PORTD, PD3 },  // 3  = JO2
  { &DDRD, &PORTD, PD4 },  // 4  = JO3
  { &DDRD, &PORTD, PD5 },  // 5  = JO4
  { &DDRD, &PORTD, PD6 },  // 6  = JO5
  { &DDRD, &PORTD, PD7 },  // 7  = JO6
  { &DDRB, &PORTB, PB0 },  // 8  = JO7
  { &DDRB, &PORTB, PB1 },  // 9  = JO8
  { &DDRB, &PORTB, PB2 },  // 10 = JO9
  { &DDRB, &PORTB, PB3 },  // 11 = JO10
  { &DDRB, &PORTB, PB4 },  // 12 = JSN1
  { &DDRB, &PORTB, PB5 },  // 13 = LED
  { &DDRC, &PORTC, PC0 },  // 14 = JSN2
  { &DDRC, &PORTC, PC1 },  // 15 = JSN3
  { &DDRC, &PORTC, PC2 },  // 16 = JSN4
  { &DDRC, &PORTC, PC3 },  // 17 = JSN5
  { &DDRC, &PORTC, PC4 },  // 18 = JSN6
  { &DDRC, &PORTC, PC5 },  // 19 = JSN7
};

inline const PinInit* getPinInit(uint8_t pin) {
  return &pinMap[pin];
}

