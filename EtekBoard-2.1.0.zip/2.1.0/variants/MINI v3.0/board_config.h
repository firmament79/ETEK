#pragma once
#include <Arduino.h>

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
    #define NULLVALUE nullptr
  #else
    #define CONSTEXPR const
    #define NULLVALUE NULL
  #endif
#else
  #define CONSTEXPR const
  #define NULLVALUE NULL
#endif



typedef struct {
  volatile uint8_t* ddr;
  volatile uint8_t* port;
  uint8_t bit;
} PinInit;

// --- Arduino 腳位名稱定義（提供 digitalWrite 調用） ---

CONSTEXPR uint8_t LED = 13;

CONSTEXPR uint8_t JO1 = 24;
CONSTEXPR uint8_t JO2 = 5;
CONSTEXPR uint8_t JO3 = 6;
CONSTEXPR uint8_t JO4 = 7;
CONSTEXPR uint8_t JO5 = 8;
CONSTEXPR uint8_t JO6 = 9;
CONSTEXPR uint8_t JO7 = 10;

CONSTEXPR uint8_t JSN1 = 25;
CONSTEXPR uint8_t JSN2 = 26;
CONSTEXPR uint8_t JSN3 = 14;
CONSTEXPR uint8_t JSN4 = 15;
CONSTEXPR uint8_t JSN5 = 16;
CONSTEXPR uint8_t JSN6 = 17;
CONSTEXPR uint8_t JSN7 = 2;
CONSTEXPR uint8_t JSN8 = 3;
CONSTEXPR uint8_t JSN9 = 4;
CONSTEXPR uint8_t JSN10 = 23;
CONSTEXPR uint8_t JSN11 = 20;
CONSTEXPR uint8_t JSN12 = 21;



// --- 底層控制定義 ---

// --- 輸出腳位定義 ---
const PinInit OUTPUT_PINS[] PROGMEM = {
  { &DDRB, &PORTB, PB5 }, // LED
  { &DDRE, &PORTE, PE3 }, // JO1
  { &DDRD, &PORTD, PD5 }, // JO2
  { &DDRD, &PORTD, PD6 }, // JO3
  { &DDRD, &PORTD, PD7 }, // JO4
  { &DDRB, &PORTB, PB0 }, // JO5
  { &DDRB, &PORTB, PB1 }, // JO6
  { &DDRB, &PORTB, PB2 }, // JO7
};


// --- 輸入+上拉腳位定義 ---
const PinInit INPUT_PULLUP_PINS[] PROGMEM = {
  { &DDRE, &PORTE, PE2 },  // JSN1
  { &DDRE, &PORTE, PE3 },  // JSN2
  { &DDRC, &PORTC, PC0 },  // JSN3
  { &DDRC, &PORTC, PC1 },  // JSN4
  { &DDRC, &PORTC, PC2 },  // JSN5
  { &DDRC, &PORTC, PC3 },  // JSN6
  { &DDRD, &PORTD, PD2 },  // JSN7
  { &DDRD, &PORTD, PD3 },  // JSN8
  { &DDRD, &PORTD, PD4 },  // JSN9
  { &DDRE, &PORTE, PE0 },  // JSN10
  { &DDRB, &PORTB, PB6 },  // JSN11
  { &DDRB, &PORTB, PB7 },  // JSN12
};

// --- 輸入腳位定義（無上拉） ---
const PinInit INPUT_PINS[] PROGMEM = {
  // 若有，放在這邊
};


// Arduino 腳位 0~26 的對應表（index = 腳位編號）
static const PinInit pinMap[] = {
  { &DDRD, &PORTD, PD0 },  // 0
  { &DDRD, &PORTD, PD1 },  // 1
  { &DDRD, &PORTD, PD2 },  // 2 = JSN7
  { &DDRD, &PORTD, PD3 },  // 3 = JSN8
  { &DDRD, &PORTD, PD4 },  // 4 = JSN9
  { &DDRD, &PORTD, PD5 },  // 5 = JO2
  { &DDRD, &PORTD, PD6 },  // 6 = JO3
  { &DDRD, &PORTD, PD7 },  // 7 = JO4
  { &DDRB, &PORTB, PB0 },  // 8 = JO5
  { &DDRB, &PORTB, PB1 },  // 9 = JO6
  { &DDRB, &PORTB, PB2 },  // 10 = JO7
  { &DDRB, &PORTB, PB3 },  // 11
  { &DDRB, &PORTB, PB4 },  // 12
  { &DDRB, &PORTB, PB5 },  // 13 = LED
  { &DDRC, &PORTC, PC0 },  // 14 = JSN3
  { &DDRC, &PORTC, PC1 },  // 15 = JSN4
  { &DDRC, &PORTC, PC2 },  // 16 = JSN5
  { &DDRC, &PORTC, PC3 },  // 17 = JSN6
  { &DDRC, &PORTC, PC4 },  // 18
  { &DDRC, &PORTC, PC5 },  // 19
  { &DDRB, &PORTB, PB6 },  // 20 = JSN11
  { &DDRB, &PORTB, PB7 },  // 21 = JSN12
  { &DDRC, &PORTC, PC6 },  // 22
  { &DDRE, &PORTE, PE0 },  // 23 = JSN10
  { &DDRE, &PORTE, PE1 },  // 24 = JO1
  { &DDRE, &PORTE, PE2 },  // 25 = JSN1
  { &DDRE, &PORTE, PE3 },  // 26 = JSN2
};

inline const PinInit* getPinInit(uint8_t pin) {
  return &pinMap[pin];
}
