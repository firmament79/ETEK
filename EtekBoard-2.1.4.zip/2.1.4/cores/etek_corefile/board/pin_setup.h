// [EtekBoard 專用] 低階腳位初始化
// 此檔案由 EtekBoard 專案維護，非 Arduino 官方核心一部分
#pragma once

#include <Arduino.h>
#include "board_config.h"


extern const PinInit outputPins[];
extern const PinInit inputPullupPins[];
extern const PinInit inputPins[];

void initOutputPins();
void initInputPullupPins();
void initInputPins();