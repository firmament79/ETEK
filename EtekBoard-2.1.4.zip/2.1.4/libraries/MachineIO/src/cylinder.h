#ifndef VALVE_H
    #define VALVE_H

    #include <arduino.h>
    #include <io_simple.h>




    // inline bool sensorTwoWire(int pin){ return sensorNPN(pin); }

    // inline bool sensorNPN(int pin){ return !get(pin); }

    // inline bool sensorPNP(int pin){ return get(pin); }


    // inline void ThreePositionValve(int portA, int portB, int state=0){
    //     if (state == 1){
    //         on(portA);
    //         off(portB);
    //     }else if (state == 2){
    //         off(portA);
    //         on(portB);
    //     }else{
    //         off(portA);
    //         off(portB);
    //     }
    // }


    // inline void twoPositionValve(int port, int state=0){
    //     digitalWrite(port, state);
    // }


    // inline void valveFwdPos(int type, int portA, int portB = -1){
    //     if(type == 3 && portB != -1){
    //         ThreePositionValve(portA, portB, 1);
    //     }
    //     else if (type == 2){
    //         twoPositionValve(portA, 1);
    //     }
    // }

    // inline void valveBwdPos(int type, int portA, int portB = -1){
    //     if(type == 3 && portB != -1){
    //         ThreePositionValve(portA, portB, 2);
    //     }
    //     else if (type == 2){
    //         twoPositionValve(portA, 0);
    //     }
    // }

    // inline void valveCtrPos(int type, int portA, int portB = -1){
    //     if(type == 3 && portB != -1){
    //         ThreePositionValve(portA, portB, 0);
    //     }
    //     else if (type == 2){
    //         twoPositionValve(portA, 0);
    //     }
    // }



    // inline void initValve(int type, int portA, int portB = -1){
    //     if (type == 3 && portB != -1){
    //         valveStop(3, portA, portB);
    //     }else if (type == 2){
    //         valveStop(2, portA);
    //     }
    // }



    // inline bool initCYL(int type, int sensor1, int sensor2, int portA, int portB= -1 ){
    //     if (type == 3 && portB != -1){
    //         initValve(3, portA, portB);
    //         while(get(sensor1));
    //     }else if (type == 2){
    //         initValve(2, portA);
    //         while(get(sensor1));
    //     }
    // }


    // inline bool isAtWork(int sensor, int sensorType = 2){
    //     if (sensorType == 3){
    //         return sensorPNP(sensor);
    //     }else{
    //         return sensorNPN(sensor);
    //     }
    // }

    // inline bool isAtHome(int sensor, int sensorType = 2){
    //     if (sensorType == 3){
    //         return sensorPNP(sensor);
    //     }else{
    //         return sensorNPN(sensor);
    //     }
    // }



    struct Sensor{
        uint8_t pin;
        enum Type { NPN= 0, PNP=1, TwoWire = 2} type;

        Sensor(uint8_t p, Type t = NPN): pin(p), type(t) {}

        bool isTriggered() const {
            if (type == NPN || type == TwoWire) return !get(pin);
            else return get(pin);
        }
    };

    struct Valve{
        uint8_t A;
        int8_t B;
        enum Type { TwoPosition = 2, ThreePosition = 3} type;

        Valve(uint8_t A, int8_t B = -1)
            : A(A), B(B) ,type(B == -1 ? TwoPosition : ThreePosition){
            init();
        }

        void init(){
            if (type == ThreePosition) stop();
            else off(A);
        }

        void set(int state){
            if (state <0 || state > 2) state = 0;
            if (type == ThreePosition) {
                if (state == 1){
                    off(B);
                    on(A);
                }else if (state == 2){
                    off(A);
                    on(B);
                }else{
                    off(A);
                    off(B);
                }
            }else{
                if (state == 1) on(A);
                else off(A); 
            }
        }

        void fwdPos(){set(1);}
        void bwdPos(){set(2);}
        void stop(){set(0);}

    };


    // enum ActuatorState{
    //     Idle,
    //     MovingForward,
    //     Extended,
    //     MovingBackward,
    //     Retracted,
    //     TimeoutError
    // };
     enum ActuatorState{
        Idle,
        MovingToWork,
        AtWork,
        MovingToHome,
        AtHome,
        TimeoutError
    };
 



    struct Actuator{
        Valve valve;
        Sensor sensorWork;
        Sensor sensorHome;

        public: 

        


        Actuator(uint8_t valveA, int8_t valveB, uint8_t sFwd, uint8_t sBwd, Sensor::Type stype = Sensor::NPN)
            : valve(valveA, valveB), sensorWork(sFwd, stype), sensorHome(sBwd, stype){}
                
            void activate() {valve.fwdPos();}
            void deactivate() {valve.bwdPos();}
            void stopMotion()  {valve.stop();}
            
            bool isAtWork() const {return sensorWork.isTriggered();}
            bool isAtHome() const {return sensorHome.isTriggered();}
        
            void update(){
                switch (state){
                    case ActuatorState::Idle:
                        break;

                    case ActuatorState::MovingToWork:
                        if(isAtWork()){
                            // stop();
                            state = ActuatorState::AtWork;
                        }
                        // else if (timeout()){
                        //     stop();
                        //     state = ActuatorState::TimeoutError;
                        // }
                        break;

                    case ActuatorState::MovingToHome:
                        if(isAtHome()){
                            // stop();
                            state = ActuatorState::AtHome;
                        }
                        // else if (timeout()){
                        //     stop();
                        //     state = ActuatorState::TimeoutError;
                        // }
                        break;

                    default:
                        break;
                }
            }

            void goWork(){
                activate();
                // startTimer();
                state = ActuatorState::MovingToWork;
            }

            void goHome(){
                deactivate();
                // startTimer();
                state = ActuatorState::MovingToHome;
            }

            void stop(){
                stopMotion();
                // startTimer();
                state = ActuatorState::Idle;
            }

            void init( Sensor initSensor){
                deactivate();
                startTimer();
                state = ActuatorState::MovingToHome;
            }


            ActuatorState getState() const {
                return state;
            }

            void printState(String name = "Actuator"){
                switch (getState()){
                    case ActuatorState::Idle:
                        Serial.print(name);
                        Serial.println(F(": Idle"));
                        break;

                    case ActuatorState::MovingToWork:
                        Serial.print(name);
                        Serial.println(F(": going work"));
                        break;

                    case ActuatorState::AtWork:
                        Serial.print(name);
                        Serial.println(F(": at work"));
                        break;

                    case ActuatorState::MovingToHome:
                        Serial.print(name);
                        Serial.println(F(": going home"));
                        break;

                    case ActuatorState::AtHome:
                        Serial.print(name);
                        Serial.println(F(": at home"));
                        break;

                    case ActuatorState::TimeoutError:
                        Serial.print(name);
                        Serial.println(F(": Timeout!"));
                        break;

                }
            }


            // void moveTo(bool forward){
            //     if (forward) activate();
            //     else deactivate();
            // }

            // void init( Sensor initSensor){
            //     valve.stop();
            //     Serial.println(F("cylinder init"));
            //     unsigned long start = millis();
            //     const unsigned long timeout = 3000;
            //     while (!initSensor.isTriggered()){
            //         toggle(LED);
            //         delay(100);
            //         if(millis() - start > timeout) {
            //             Serial.println(F("cylinder init timeout!"));
            //             // break;
            //             return;
            //         }
            //     }; //初始化先回原點&3秒超時避免卡死
            //     Serial.println(F("cylinder init ok!"));
            // }

            
            private:
                
                bool timeout(){
                    return (millis() - startTime) > maxDuration;
                }

                void startTimer(){
                    startTime = millis();
                }


                ActuatorState state = ActuatorState::Idle;
                unsigned long startTime = 0;
                const unsigned long maxDuration = 3000;
                int retry = 3;

    };



#endif