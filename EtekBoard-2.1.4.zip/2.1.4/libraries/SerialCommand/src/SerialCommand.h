#ifndef SERIALCOMMAND_H
#define SERIALCOMMAND_H

#include "Arduino.h"


// === DEBUG 開關（使用者可在主程式中 #define SERIALCOMMAND_DEBUG 開啟） ===
#ifndef SERIALCOMMAND_DEBUG
  #define SERIALCOMMAND_DEBUG 0
#endif

#if SERIALCOMMAND_DEBUG
  #define DEBUG_PRINT(x) Serial.print(x)
  #define DEBUG_PRINTLN(x) Serial.println(x)
#else
  #define DEBUG_PRINT(x)
  #define DEBUG_PRINTLN(x)
#endif

#ifndef SERIALCOMMAND_USE_EMOJI
  #define SERIALCOMMAND_USE_EMOJI 1  // 使用Emoji 0:不使用 1:使用
#endif

//還沒做
#ifndef SERIALCOMMAND_USER_SETEMOJI
  #define SERIALCOMMAND_USER_SETEMOJI 0  // 終端使用者可以自行切換 0:不能切換 1:可以切換
#endif

#ifndef _DEBUG_
  #define _DEBUG_ 1
#endif

#if _DEBUG_
  #define DEBUG(x) cmd.printDebug(x)
#else
  #define DEBUG(x)
#endif





#ifdef __cplusplus


// ✅ 狀態列舉
enum SystemStatus : uint8_t {
  STATUS_NONE,
  STATUS_FINISH,
  STATUS_WAIT,
  STATUS_CHECK,
  STATUS_PGRS,
  STATUS_BUSY,
  STATUS_START,
  STATUS_STOP,
  STATUS_PAUSE,
  STATUS_RESUME,
  STATUS_RESET,
  STATUS_SET,
  STATUS_COUNT
};



// // ✅ 狀態對應訊息（在 .cpp 定義）
// extern const char* STATUS_MESSAGES[STATUS_COUNT];
extern const char* const STATUS_MESSAGES[STATUS_COUNT];
extern const char* const STATUS_EMOJI[STATUS_COUNT];


enum CommandIndex : uint8_t {
    CMD_START,
    CMD_STOP,
    CMD_RESET,
    CMD_PAUSE,
    CMD_RESUME,
    CMD_SET,
    CMD_COUNT
};

extern const char* const CMD_STRING[CMD_COUNT] PROGMEM;

int8_t matchCommand(const String& command);  // 可選：提供 enum 回傳




class SerialCommand {
public:
    SerialCommand(char breakChar = ';', unsigned long timeout = 500);

    void begin(long baudrate);
    void handle();
    void showInfo(bool enable = true);
    const char* getCommand();

    void printStatus(SystemStatus status, const __FlashStringHelper* prefix = nullptr);
    void useEmoji(bool enable){showEmoji = enable;} 
    void debugText(bool enable){showDebugText = enable;} 

    // bool showDebugText = false;    

    void printDebug(const String& str);
    void printDebug(const char* text);
    void printDebug(const __FlashStringHelper* ftext);

    template<typename T>
    void printDebug(const T& value){if (showDebugText){Serial.println(value);}} //顯示變數
    // inline void ptintDebug(String text);
    // inline void ptintlnDebug(String text);
    // void printDebug(const __FlashStringHelper* emoji, const __FlashStringHelper* text);
    // void printlnDebug(const __FlashStringHelper* emoji, const __FlashStringHelper* text);


private:
    static const byte BUFFER_SIZE = 32;
    char inputBuffer[BUFFER_SIZE];
    char cmd[BUFFER_SIZE];  // 儲存上一個命令

    byte index;
    unsigned long lastByteTime;
    unsigned long commandTimeout;
    char breakChar;

    // String cmd;
    // void trim(char* s);
    void checkCommand(const char* command);
    void showCommands();

    bool showEmoji = false;
    bool showDebugText = false;    

    void printEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text);
    void printlnEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text);

  };


#else

#endif


#endif // SERIALCOMMAND_H