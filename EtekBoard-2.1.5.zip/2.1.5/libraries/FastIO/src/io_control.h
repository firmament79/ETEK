// pinref.h

#pragma once
#include "board_config.h"



// class PinRef {
// public:
//   PinRef(uint8_t pin) : pin(getPinInit(pin)) {}
//   PinRef(const PinInit* init) : pin(init) {}

//   void on() const { *pin->port |= (1 << pin->bit); }
//   void off() const { *pin->port &= ~(1 << pin->bit); }
//   void toggle() const { *pin->port ^= (1 << pin->bit); }
//   bool get() const { return (*(pin->port - 2)) & (1 << pin->bit); }

//   void setOUTPUT() const { *pin->ddr |= (1 << pin->bit); }
  
//   void setINPUT() const {
//     *pin->ddr &= ~(1 << pin->bit);
//     *pin->port &= ~(1 << pin->bit);
//   }
//   void setINPUT_PULLUP() const {
//     *pin->ddr &= ~(1 << pin->bit);
//     *pin->port |= (1 << pin->bit);
//   }

// private:
//   const PinInit* pin;
// };



inline PinInit getPinOutput(uint8_t pin) {
  PinInit temp;
  memcpy_P(&temp, &OUTPUT_PINS[pin], sizeof(PinInit));
  return temp;
}
inline PinInit getPinInputPullup(uint8_t pin) {
  PinInit temp;
  memcpy_P(&temp, &INPUT_PULLUP_PINS[pin], sizeof(PinInit));
  return temp;
}
inline PinInit getPinAll(uint8_t pin) {
  PinInit temp;
  memcpy_P(&temp, &pinMap[pin], sizeof(PinInit));
  return temp;
}


class PinRef {
public:
  explicit PinRef(uint8_t idx) : index(idx) {  }

  void setOUTPUT() const {
    PinInit p = getPinOutput(index);
    *const_cast<volatile uint8_t*>(p.ddr) |= (1 << p.bit);
  }

  void on() const {
    PinInit p = getPinOutput(index);
    *const_cast<volatile uint8_t*>(p.port) |= (1 << p.bit);
  }

  void off() const {
    PinInit p = getPinOutput(index);
    *const_cast<volatile uint8_t*>(p.port) &= ~(1 << p.bit);
  }

//   void toggle() const { *pin->port ^= (1 << pin->bit); }
  void toggle() const {
    PinInit p = getPinOutput(index);
    *const_cast<volatile uint8_t*>(p.port) ^= (1 << p.bit);
  }

//   bool get() const { return (*(pin->port - 2)) & (1 << pin->bit); }
  bool get() const{
    PinInit p = getPinAll(index);
    // return (*(p.port - 2) & (1 << p.bit));
    return (*(p.port - 2) & (1 << p.bit)) != 0;
  }

  void setINPUT(){
    PinInit p = getPinInputPullup(index);
    *const_cast<volatile uint8_t*>(p.ddr) &= ~(1 << p.bit);   // DDR 清 bit
    *const_cast<volatile uint8_t*>(p.port) &= ~(1 << p.bit);  // PORT 清 bit（無上拉）
  }

  void setINPUT_PULLUP(){
    PinInit p = getPinInputPullup(index);
    *const_cast<volatile uint8_t*>(p.ddr) &= ~(1 << p.bit);   // DDR 清 bit
    *const_cast<volatile uint8_t*>(p.port) |= (1 << p.bit);   // PORT 設 bit（啟用上拉）
  }

private:
  uint8_t index;
};