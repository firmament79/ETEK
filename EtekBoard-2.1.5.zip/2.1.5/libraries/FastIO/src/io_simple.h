#pragma once
#include <Arduino.h>

inline void on(uint8_t pin) { digitalWrite(pin, HIGH); }
inline void off(uint8_t pin) { digitalWrite(pin, LOW); }
inline void toggle(uint8_t pin) { digitalWrite(pin, !digitalRead(pin)); }
inline bool get(uint8_t pin) { return digitalRead(pin); }
inline void setOUTPUT(uint8_t pin) { pinMode(pin, OUTPUT); }
inline void setINPUT(uint8_t pin) { pinMode(pin, INPUT); }
inline void setINPUT_PULLUP(uint8_t pin) { pinMode(pin, INPUT_PULLUP); }
