// TANK 2.0

#pragma once
#include <Arduino.h>

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
    #define NULLVALUE nullptr
  #else
    #define CONSTEXPR const
    #define NULLVALUE NULL
  #endif
#else
  #define CONSTEXPR const
  #define NULLVALUE NULL
#endif



typedef struct {
  volatile uint8_t* ddr;
  volatile uint8_t* port;
  uint8_t bit;
} PinInit;

// --- Arduino 腳位名稱定義（提供 digitalWrite 調用） ---

// LED
CONSTEXPR uint8_t LED = 22;   // PB7 MCU燈號

//EMO
// CONSTEXPR uint8_t EMO = 85;   // PG5 急停開關

// CH (1~6)
CONSTEXPR uint8_t CH6 = 2;   // PE2
CONSTEXPR uint8_t CH5 = 3;   // PE3
CONSTEXPR uint8_t CH4 = 4;   // PE4
CONSTEXPR uint8_t CH3 = 5;   // PE5
CONSTEXPR uint8_t CH2 = 6;   // PE6
CONSTEXPR uint8_t CH1 = 7;   // PE7


// LB (1~20)
CONSTEXPR uint8_t LB3  = 19;  // PB4
CONSTEXPR uint8_t LB4  = 20;  // PB5
CONSTEXPR uint8_t LB5  = 21;  // PB6
CONSTEXPR uint8_t LB6 = 23; // PH7
CONSTEXPR uint8_t LB7 = 24; // PG3
CONSTEXPR uint8_t LB8 = 25; // PG4
CONSTEXPR uint8_t LB9 = 26; // PL0
CONSTEXPR uint8_t LB10 = 27; // PL1
CONSTEXPR uint8_t LB11 = 28; // PL2
CONSTEXPR uint8_t LB12 = 29; // PL3
CONSTEXPR uint8_t LB13 = 30; // PL4
CONSTEXPR uint8_t LB14 = 31; // PL5
CONSTEXPR uint8_t LB15 = 32; // PL6
CONSTEXPR uint8_t LB16 = 33; // PL7
CONSTEXPR uint8_t LB17 = 38; // PD4
CONSTEXPR uint8_t LB18 = 39; // PD5
CONSTEXPR uint8_t LB19 = 40; // PD6
CONSTEXPR uint8_t LB20 = 41; // PD7
CONSTEXPR uint8_t LB2 = 42; // PG0
CONSTEXPR uint8_t LB1 = 43; // PG1

// JSN (1~38)
// CONSTEXPR uint8_t JSN1  = 60; // PA7
// CONSTEXPR uint8_t JSN2  = 59; // PG2
// CONSTEXPR uint8_t JSN3  = 58; // PJ6
// CONSTEXPR uint8_t JSN4  = 57; // PJ5
// CONSTEXPR uint8_t JSN5  = 56; // PJ4
// CONSTEXPR uint8_t JSN6  = 55; // PJ3
// CONSTEXPR uint8_t JSN7  = 54; // PJ2
// CONSTEXPR uint8_t JSN8  = 53; // PJ0
// CONSTEXPR uint8_t JSN9  = 52; // PJ1
// CONSTEXPR uint8_t JSN10 = 51; // PC7
// CONSTEXPR uint8_t JSN11 = 50; // PC6
// CONSTEXPR uint8_t JSN12 = 49; // PC5
// CONSTEXPR uint8_t JSN13 = 48; // PC4
// CONSTEXPR uint8_t JSN14 = 47; // PC3
// CONSTEXPR uint8_t JSN15 = 46; // PC2
// CONSTEXPR uint8_t JSN16 = 45; // PC1
// CONSTEXPR uint8_t JSN17 = 44; // PC0
// CONSTEXPR uint8_t JSN24 = 37; // PD3
// CONSTEXPR uint8_t JSN25 = 36; // PD2
// CONSTEXPR uint8_t JSN26 = 35; // PD1 SDA
// CONSTEXPR uint8_t JSN27 = 34; // PD0 SCL

// JLN (光柵)
// CONSTEXPR uint8_t JLN1 = 76;  // PF7
// CONSTEXPR uint8_t JLN2 = 75;  // PF6

// JVN
// CONSTEXPR uint8_t JVN1 = 74;  // PF5
// CONSTEXPR uint8_t JVN2 = 73;  // PF4
// CONSTEXPR uint8_t JVN3 = 72;  // PF3
// CONSTEXPR uint8_t JVN4 = 71;  // PF2
// CONSTEXPR uint8_t JVN5 = 70;  // PF1
// CONSTEXPR uint8_t JVN6 = 69;  // PF0

// J1 (PK)
// CONSTEXPR uint8_t J1_1 = 84;  // PK7
// CONSTEXPR uint8_t J1_2 = 83;  // PK6
// CONSTEXPR uint8_t J1_3 = 82;  // PK5
// CONSTEXPR uint8_t J1_4 = 81;  // PK4
// CONSTEXPR uint8_t J1_5 = 80;  // PK3
// CONSTEXPR uint8_t J1_6 = 79;  // PK2
// CONSTEXPR uint8_t J1_7 = 78;  // PK1
// CONSTEXPR uint8_t J1_8 = 77;  // PK0

// J2 (PJ + PA)
// CONSTEXPR uint8_t J2_1 = 68;  // PJ7
// CONSTEXPR uint8_t J2_2 = 67;  // PA0
// CONSTEXPR uint8_t J2_3 = 66;  // PA1
// CONSTEXPR uint8_t J2_4 = 65;  // PA2
// CONSTEXPR uint8_t J2_5 = 64;  // PA3
// CONSTEXPR uint8_t J2_6 = 63;  // PA4
// CONSTEXPR uint8_t J2_7 = 62;  // PA5
// CONSTEXPR uint8_t J2_8 = 61;  // PA6


// --- 底層控制定義 ---

// --- 輸出腳位定義 ---
const PinInit OUTPUT_PINS[] PROGMEM = {
  {}, //0
  {}, //1
  { &DDRE, &PORTE, PE2 }, // CH6 = 2  (PE2)
  { &DDRE, &PORTE, PE3 }, // CH5 = 3  (PE3)
  { &DDRE, &PORTE, PE4 }, // CH4 = 4  (PE4)
  { &DDRE, &PORTE, PE5 }, // CH3 = 5  (PE5)
  { &DDRE, &PORTE, PE6 }, // CH2 = 6  (PE6)
  { &DDRE, &PORTE, PE7 }, // CH1 = 7  (PE7)
  {}, // 8  (PH0)
  {}, // 9  (PH1)
  {}, // 10 (PH2)
  {}, // 11 (PH3)
  {}, // 12 (PH4)
  {}, // 13 (PH5)
  {}, // 14 (PB6)
  {}, // 15
  {}, // 16
  {}, // 17
  {}, // 18
  { &DDRB, &PORTB, PE4 }, // LB3  = 19 (PB4)
  { &DDRB, &PORTB, PE5 }, // LB4  = 20 (PB5)
  { &DDRB, &PORTB, PB6 }, // LB5  = 21 (PB6)
  { &DDRB, &PORTB, PB7 }, // LED = 22 (PB7)
  { &DDRH, &PORTH, PH7 }, // LB6 = 23 (PH7)
  { &DDRG, &PORTG, PG3 }, // LB7 = 24 (PG3)
  { &DDRG, &PORTG, PG4 }, // LB8 = 25 (PG4)
  { &DDRL, &PORTL, PL0 }, // LB9 = 26 (PL0)
  { &DDRL, &PORTL, PL1 }, // LB10 = 27 (PL1)
  { &DDRL, &PORTL, PL2 }, // LB11 = 28 (PL2)
  { &DDRL, &PORTL, PL3 }, // LB12 = 29 (PL3)
  { &DDRL, &PORTL, PL4 }, // LB13 = 30 (PL4)
  { &DDRL, &PORTL, PL5 }, // LB14 = 31 (PL5)
  { &DDRL, &PORTL, PL6 }, // LB15 = 32 (PL6)
  { &DDRL, &PORTL, PL7 }, // LB16 = 33 (PL7)
  { },   // JSN27 = 34 (PD0)
  { },   // JSN26 = 35 (PD1)
  { },   // JSN25 = 36 (PD2)
  { },   // JSN24 = 37 (PD3)
  { &DDRD, &PORTD, PD4 }, // LB17 = 38 (PD4)
  { &DDRD, &PORTD, PD5 }, // LB18 = 39 (PD5)
  { &DDRD, &PORTD, PD6 }, // LB19 = 40 (PD6)
  { &DDRD, &PORTD, PD7 }, // LB20 = 41 (PD7)
  { &DDRG, &PORTG, PG0 }, // LB1 = 42 (PG0)
  { &DDRG, &PORTG, PG1 }, // LB2 = 43 (PG1)
  { },   // JSN17 = 44 (PC0)
  { },   // JSN16 = 45 (PC1)
  { },   // JSN15 = 46 (PC2)
  { },   // JSN14 = 47 (PC3)
  { },   // JSN13 = 48 (PC4)
  { },   // JSN12 = 49 (PC5)
  { },   // JSN11 = 50 (PC6)
  { },   // JSN10 = 51 (PC7)
  { },   // JSN9 = 52 (PJ1)
  { },   // JSN8 = 53 (PJ0)
  { },   // JSN7 = 54 (PJ2)
  { },   // JSN6 = 55 (PJ3)
  { },   // JSN5 = 56 (PJ4)
  { },   // JSN4 = 57 (PJ5)
  { },   // JSN3 = 58 (PJ6)
  { },   // JSN2 = 59 (PG2)
  { },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61
  { },   // J2_7 = 62
  { },   // J2_6 = 63
  { },   // J2_5 = 64
  { },   // J2_4 = 65
  { },   // J2_3 = 66
  { },   // J2_2 = 67
  { },   // J2_1 = 68
  { },   // JVN6 = 69
  { },   // JVN5 = 70
  { },   // JVN4 = 71
  { },   // JVN3 = 72
  { },   // JVN2 = 73
  { },   // JVN1 = 74
  { },   // JLN2 = 75
  { },   // JLN1 = 76
  { },   // J1_8 = 77
  { },   // J1_7 = 78
  { },   // J1_6 = 79
  { },   // J1_5 = 80
  { },   // J1_4 = 81
  { },   // J1_3 = 82
  { },   // J1_2 = 83
  { },   // J1_1 = 84
  { },   // EMO = 85
};


// --- 輸入+上拉腳位定義 ---
const PinInit INPUT_PULLUP_PINS[] PROGMEM = {
  {}, //0
  {}, //1
  { }, // JO16 = 2  (PE2)
  { }, // JO15 = 3  (PE3)
  { }, // JO14 = 4  (PE4)
  { }, // JO13 = 5  (PE5)
  { }, // JO12 = 6  (PE6)
  { }, // JO11 = 7  (PE7)
  { }, // JO10 = 8  (PH0)
  { }, // JO9  = 9  (PH1)
  { }, // JO8  = 10 (PH2)
  { }, // JO7  = 11 (PH3)
  { }, // JO6  = 12 (PH4)
  { }, // JO5  = 13 (PH5)
  { }, // JO4  = 14 (PB6)
  {}, // 15
  {}, // 16
  {}, // 17
  {}, // 18
  { }, // JO3  = 19 (PB4)
  { }, // JO2  = 20 (PB5)
  { }, // JO1  = 21 (PB6)
  { }, // LED = 22 (PB7)
  { },   // JSN38 = 23 (PH7)
  { },   // JSN37 = 24 (PG3)
  { },   // JSN36 = 25 (PG4)
  { },   // JSN35 = 26 (PL0)
  { },   // JSN34 = 27 (PL1)
  { },   // JSN33 = 28 (PL2)
  { },   // JSN32 = 29 (PL3)
  { },   // JSN31 = 30 (PL4)
  { },   // JSN30 = 31 (PL5)
  { },   // JSN29 = 32 (PL6)
  { },   // JSN28 = 33 (PL7)
  { },   // JSN27 = 34 (PD0)
  { },   // JSN26 = 35 (PD1)
  { },   // JSN25 = 36 (PD2)
  { },   // JSN24 = 37 (PD3)
  { },   // JSN23 = 38 (PD4)
  { },   // JSN22 = 39 (PD5)
  { },   // JSN21 = 40 (PD6)
  { },   // JSN20 = 41 (PD7)
  { },   // JSN19 = 42 (PG0)
  { },   // JSN18 = 43 (PG1)
  { },   // JSN17 = 44 (PC0)
  { },   // JSN16 = 45 (PC1)
  { },   // JSN15 = 46 (PC2)
  { },   // JSN14 = 47 (PC3)
  { },   // JSN13 = 48 (PC4)
  { },   // JSN12 = 49 (PC5)
  { },   // JSN11 = 50 (PC6)
  { },   // JSN10 = 51 (PC7)
  { },   // JSN9 = 52 (PJ1)
  { },   // JSN8 = 53 (PJ0)
  { },   // JSN7 = 54 (PJ2)
  { },   // JSN6 = 55 (PJ3)
  { },   // JSN5 = 56 (PJ4)
  { },   // JSN4 = 57 (PJ5)
  { },   // JSN3 = 58 (PJ6)
  { },   // JSN2 = 59 (PG2)
  { },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61
  { },   // J2_7 = 62
  { },   // J2_6 = 63
  { },   // J2_5 = 64
  { },   // J2_4 = 65
  { },   // J2_3 = 66
  { },   // J2_2 = 67
  { },   // J2_1 = 68
  { },   // JVN6 = 69
  { },   // JVN5 = 70
  { },   // JVN4 = 71
  { },   // JVN3 = 72
  { },   // JVN2 = 73
  { },   // JVN1 = 74
  { },   // JLN2 = 75
  { },   // JLN1 = 76
  { },   // J1_8 = 77
  { },   // J1_7 = 78
  { },   // J1_6 = 79
  { },   // J1_5 = 80
  { },   // J1_4 = 81
  { },   // J1_3 = 82
  { },   // J1_2 = 83
  { },   // J1_1 = 84
  { },   // EMO = 85
};

// --- 輸入腳位定義（無上拉） ---
const PinInit INPUT_PINS[] PROGMEM = {
  {}, //0
  {}, //1
  { }, // JO16 = 2  (PE2)
  { }, // JO15 = 3  (PE3)
  { }, // JO14 = 4  (PE4)
  { }, // JO13 = 5  (PE5)
  { }, // JO12 = 6  (PE6)
  { }, // JO11 = 7  (PE7)
  { }, // JO10 = 8  (PH0)
  { }, // JO9  = 9  (PH1)
  { }, // JO8  = 10 (PH2)
  { }, // JO7  = 11 (PH3)
  { }, // JO6  = 12 (PH4)
  { }, // JO5  = 13 (PH5)
  { }, // JO4  = 14 (PB6)
  {}, // 15
  {}, // 16
  {}, // 17
  {}, // 18
  { }, // JO3  = 19 (PB4)
  { }, // JO2  = 20 (PB5)
  { }, // JO1  = 21 (PB6)
  { },   // LED = 22 (PB7)
  { },   // JSN38 = 23 (PH7)
  { },   // JSN37 = 24 (PG3)
  { },   // JSN36 = 25 (PG4)
  { },   // JSN35 = 26 (PL0)
  { },   // JSN34 = 27 (PL1)
  { },   // JSN33 = 28 (PL2)
  { },   // JSN32 = 29 (PL3)
  { },   // JSN31 = 30 (PL4)
  { },   // JSN30 = 31 (PL5)
  { },   // JSN29 = 32 (PL6)
  { },   // JSN28 = 33 (PL7)
  { },   // JSN27 = 34 (PD0)
  { },   // JSN26 = 35 (PD1)
  { },   // JSN25 = 36 (PD2)
  { },   // JSN24 = 37 (PD3)
  { },   // JSN23 = 38 (PD4)
  { },   // JSN22 = 39 (PD5)
  { },   // JSN21 = 40 (PD6)
  { },   // JSN20 = 41 (PD7)
  { },   // JSN19 = 42 (PG0)
  { },   // JSN18 = 43 (PG1)
  { },   // JSN17 = 44 (PC0)
  { },   // JSN16 = 45 (PC1)
  { },   // JSN15 = 46 (PC2)
  { },   // JSN14 = 47 (PC3)
  { },   // JSN13 = 48 (PC4)
  { },   // JSN12 = 49 (PC5)
  { },   // JSN11 = 50 (PC6)
  { },   // JSN10 = 51 (PC7)
  { },   // JSN9 = 52 (PJ1)
  { },   // JSN8 = 53 (PJ0)
  { },   // JSN7 = 54 (PJ2)
  { },   // JSN6 = 55 (PJ3)
  { },   // JSN5 = 56 (PJ4)
  { },   // JSN4 = 57 (PJ5)
  { },   // JSN3 = 58 (PJ6)
  { },   // JSN2 = 59 (PG2)
  { },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61
  { },   // J2_7 = 62
  { },   // J2_6 = 63
  { },   // J2_5 = 64
  { },   // J2_4 = 65
  { },   // J2_3 = 66
  { },   // J2_2 = 67
  { },   // J2_1 = 68
  { },   // JVN6 = 69
  { },   // JVN5 = 70
  { },   // JVN4 = 71
  { },   // JVN3 = 72
  { },   // JVN2 = 73
  { },   // JVN1 = 74
  { },   // JLN2 = 75
  { },   // JLN1 = 76
  { },   // J1_8 = 77
  { },   // J1_7 = 78
  { },   // J1_6 = 79
  { },   // J1_5 = 80
  { },   // J1_4 = 81
  { },   // J1_3 = 82
  { },   // J1_2 = 83
  { },   // J1_1 = 84
  { },   // EMO = 85
};




const PinInit pinMap[] PROGMEM = {
  {}, //0
  {}, //1
  { &DDRE, &PORTE, PE2 }, // CH6 = 2  (PE2)
  { &DDRE, &PORTE, PE3 }, // CH5 = 3  (PE3)
  { &DDRE, &PORTE, PE4 }, // CH4 = 4  (PE4)
  { &DDRE, &PORTE, PE5 }, // CH3 = 5  (PE5)
  { &DDRE, &PORTE, PE6 }, // CH2 = 6  (PE6)
  { &DDRE, &PORTE, PE7 }, // CH1 = 7  (PE7)
  { &DDRH, &PORTH, PE0 }, // PX = 8  (PH0)
  { &DDRH, &PORTH, PE1 }, // PX  = 9  (PH1)
  { &DDRH, &PORTH, PE2 }, // PX  = 10 (PH2)
  { &DDRH, &PORTH, PE3 }, // PX  = 11 (PH3)
  { &DDRH, &PORTH, PE4 }, // PX  = 12 (PH4)
  { &DDRH, &PORTH, PE5 }, // PX  = 13 (PH5)
  { &DDRB, &PORTB, PE6 }, // PX  = 14 (PB6)
  {}, // 15
  {}, // 16
  {}, // 17
  {}, // 18
  { &DDRB, &PORTB, PE4 }, // LB3 = 19 (PB4)
  { &DDRB, &PORTB, PE5 }, // LB4 = 20 (PB5)
  { &DDRB, &PORTB, PB6 }, // LB5 = 21 (PB6)
  { &DDRB, &PORTB, PB7 }, // LED = 22 (PB7)
  { &DDRH, &PORTH, PH7 }, // LB6  = 23 (PH7)
  { &DDRG, &PORTG, PG3 }, // LB7  = 24 (PG3)
  { &DDRG, &PORTG, PG4 }, // LB8  = 25 (PG4)
  { &DDRL, &PORTL, PL0 }, // LB9  = 26 (PL0)
  { &DDRL, &PORTL, PL1 }, // LB10 = 27 (PL1)
  { &DDRL, &PORTL, PL2 }, // LB11 = 28 (PL2)
  { &DDRL, &PORTL, PL3 }, // LB12 = 29 (PL3)
  { &DDRL, &PORTL, PL4 }, // LB13 = 30 (PL4)
  { &DDRL, &PORTL, PL5 }, // LB14 = 31 (PL5)
  { &DDRL, &PORTL, PL6 }, // LB15 = 32 (PL6)
  { &DDRL, &PORTL, PL7 }, // LB16 = 33 (PL7)
  { &DDRD, &PORTD, PD0 }, // PX = 34 (PD0)
  { &DDRD, &PORTD, PD1 }, // PX = 35 (PD1)
  { &DDRD, &PORTD, PD2 }, // PX = 36 (PD2)
  { &DDRD, &PORTD, PD3 }, // PX = 37 (PD3)
  { &DDRD, &PORTD, PD4 }, // LB17 = 38 (PD4)
  { &DDRD, &PORTD, PD5 }, // LB18 = 39 (PD5)
  { &DDRD, &PORTD, PD6 }, // LB19 = 40 (PD6)
  { &DDRD, &PORTD, PD7 }, // LB20 = 41 (PD7)
  { &DDRG, &PORTG, PG0 }, // LB1  = 42 (PG0)
  { &DDRG, &PORTG, PG1 }, // LB2  = 43 (PG1)
  { &DDRC, &PORTC, PC0 }, // PX = 44 (PC0)
  { &DDRC, &PORTC, PC1 }, // PX = 45 (PC1)
  { &DDRC, &PORTC, PC2 }, // PX = 46 (PC2)
  { &DDRC, &PORTC, PC3 }, // PX = 47 (PC3)
  { &DDRC, &PORTC, PC4 }, // PX = 48 (PC4)
  { &DDRC, &PORTC, PC5 }, // PX = 49 (PC5)
  { &DDRC, &PORTC, PC6 }, // PX = 50 (PC6)
  { &DDRC, &PORTC, PC7 }, // PX = 51 (PC7)
  { &DDRJ, &PORTJ, PJ1 }, // PX = 52 (PJ1)
  { &DDRJ, &PORTJ, PJ0 }, // PX = 53 (PJ0)
  { &DDRJ, &PORTJ, PJ2 }, // PX = 54 (PJ2)
  { &DDRJ, &PORTJ, PJ3 }, // PX = 55 (PJ3)
  { &DDRJ, &PORTJ, PJ4 }, // PX = 56 (PJ4)
  { &DDRJ, &PORTJ, PJ5 }, // PX = 57 (PJ5)
  { &DDRJ, &PORTJ, PJ6 }, // PX = 58 (PJ6)
  { &DDRG, &PORTG, PG2 }, // PX = 59 (PG2)
  { &DDRA, &PORTA, PA7 }, // PX = 60 (PA7)
  { &DDRA, &PORTA, PA6 }, // PX = 61
  { &DDRA, &PORTA, PA5 }, // PX = 62
  { &DDRA, &PORTA, PA4 }, // PX = 63
  { &DDRA, &PORTA, PA3 }, // PX = 64
  { &DDRA, &PORTA, PA2 }, // PX = 65
  { &DDRA, &PORTA, PA1 }, // PX = 66
  { &DDRA, &PORTA, PA0 }, // PX = 67
  { &DDRJ, &PORTJ, PJ7 }, // PX = 68
  { &DDRF, &PORTF, PF0 }, // PX = 69
  { &DDRF, &PORTF, PF1 }, // PX = 70
  { &DDRF, &PORTF, PF2 }, // PX = 71
  { &DDRF, &PORTF, PF3 }, // PX = 72
  { &DDRF, &PORTF, PF4 }, // PX = 73
  { &DDRF, &PORTF, PF5 }, // PX = 74
  { &DDRF, &PORTF, PF6 }, // PX = 75
  { &DDRF, &PORTF, PF7 }, // PX = 76
  { &DDRK, &PORTK, PK0 }, // PX = 77
  { &DDRK, &PORTK, PK1 }, // PX = 78
  { &DDRK, &PORTK, PK2 }, // PX = 79
  { &DDRK, &PORTK, PK3 }, // PX = 80
  { &DDRK, &PORTK, PK4 }, // PX = 81
  { &DDRK, &PORTK, PK5 }, // PX = 82
  { &DDRK, &PORTK, PK6 }, // PX = 83
  { &DDRK, &PORTK, PK7 }, // PX = 84
  { &DDRG, &PORTG, PG5 }, // PX= 85
};



inline const PinInit* getPinInit(uint8_t pin) {
  return &pinMap[pin];
}
