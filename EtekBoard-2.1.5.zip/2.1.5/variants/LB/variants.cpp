#include <Arduino.h>
#include "board_config.h"

void initVariant(void) {
  //   Serial.begin(9600);
  // Serial.println(F("initVariant() called"));
  initOutputPins();
  initInputPullupPins();
  initInputPins();
}