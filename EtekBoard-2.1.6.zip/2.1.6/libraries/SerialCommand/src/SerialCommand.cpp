#include "SerialCommand.h"

#define FSH(str) (reinterpret_cast<const __FlashStringHelper*>(str))


static inline void trim(char* str) {
  char* p = str;
  while (isspace(*p)) ++p;
  size_t len = strlen(p);
  while (len > 0 && isspace(p[len - 1])) --len;
  p[len] = '\0';
  memmove(str, p, len + 1);
}

const char status_0[]  PROGMEM = "None";
const char status_1[]  PROGMEM = "FINISH";
const char status_2[]  PROGMEM = "WAITING";
const char status_3[]  PROGMEM = "CHECK";
const char status_4[]  PROGMEM = "PROGRESS";
const char status_5[]  PROGMEM = "BUSY";
const char status_6[]  PROGMEM = "START";
const char status_7[]  PROGMEM = "STOP";
const char status_8[]  PROGMEM = "PAUSE";
const char status_9[]  PROGMEM = "RESUME";
const char status_10[] PROGMEM = "RESET";
const char status_11[] PROGMEM = "SETPARAM";
const char* const STATUS_MESSAGES[STATUS_COUNT] PROGMEM ={
    status_0,    status_1,    status_2,    status_3,    status_4,    status_5,
    status_6,    status_7,    status_8,    status_9,    status_10,   status_11,
};


#if SERIALCOMMAND_USE_EMOJI
const char emoji_0[]  PROGMEM = "";     //None";
const char emoji_1[]  PROGMEM = "🔵";  //FINISH";
const char emoji_2[]  PROGMEM = "🟡";  //WAITING";
const char emoji_3[]  PROGMEM = "❕";  //CHECK";
const char emoji_4[]  PROGMEM = "🟣";  //PROGRESS";
const char emoji_5[]  PROGMEM = "🟠";  //BUSY";
const char emoji_6[]  PROGMEM = "🟢";  //START";
const char emoji_7[]  PROGMEM = "🔴";  //STOP";
const char emoji_8[]  PROGMEM = "🟡";  //PAUSE";
const char emoji_9[]  PROGMEM = "🟢";  //RESUME";
const char emoji_10[] PROGMEM = "⚪";  //RESET";
const char emoji_11[] PROGMEM = "⚙️";  //SETPARAM";
const char* const STATUS_EMOJI[STATUS_COUNT] PROGMEM={
    emoji_0,    emoji_1,    emoji_2,    emoji_3,    emoji_4,    emoji_5,
    emoji_6,    emoji_7,    emoji_8,    emoji_9,    emoji_10,   emoji_11,
};
#endif





const char cmd_0[] PROGMEM = "start";
const char cmd_1[] PROGMEM = "stop";
const char cmd_2[] PROGMEM = "reset";
const char cmd_3[] PROGMEM = "pause";
const char cmd_4[] PROGMEM = "resume";
const char cmd_5[] PROGMEM = "set";
const char cmd_6[] PROGMEM = "done";
const char cmd_7[] PROGMEM = "ack";
const char cmd_8[] PROGMEM = "burn";
const char cmd_9[] PROGMEM = "show";

const char* const CMD_STRING[CMD_COUNT] PROGMEM = {
  cmd_0, cmd_1, cmd_2, cmd_3, cmd_4, cmd_5, cmd_6, cmd_7, cmd_8, cmd_9,
};

const char msgSet[]   PROGMEM = "Set: ";
const char msgExecuting[] PROGMEM = "Executing: ";
const char msgUnknown[]   PROGMEM = "Unknown: ";
const char msgStatus[]    PROGMEM = "Status: ";


int8_t matchCommand(const char* command) {
  char temp[8];
  for (int i = 0; i < CMD_COUNT; i++) {
    strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
    if (strcmp(command, temp) == 0) return i;
  }
  return -1;
}


SerialCommand::SerialCommand(char breakChar_, unsigned long timeout_) 
  : index(0), lastByteTime(0), commandTimeout(timeout_), breakChar(breakChar_), cmd("") {
    memset(inputBuffer, 0, BUFFER_SIZE);
}

void SerialCommand::begin(long baudrate) {
    Serial.begin(baudrate);
    DEBUG_PRINTLN(F("begin ready"));
}

inline String getName(String name){
  // String name = SOURCE_FILE;
    // 去掉副檔名
  int lastDot = name.lastIndexOf('.');
  if (lastDot >= 0) {
    name = name.substring(0, lastDot);
  }
  // Serial.println(name);
  return name;
}

void SerialCommand::showInfo(bool enable){
  if(enable){
    Serial.println(F("===Buid Info==="));
    Serial.print(F("Board: "));
    Serial.println(BOARD_PACKAGE_NAME);
    Serial.print(F("Board Package: "));
    Serial.println(BOARD_PACKAGE_VERSION);
    Serial.print(F("Source file: "));
    Serial.println(getName(SOURCE_FILE));
    // Serial.println(SOURCE_FILE);
    Serial.print(F("Compiled on: "));  
    Serial.print(__DATE__);
    Serial.print(F(" "));
    Serial.println(__TIME__);
    Serial.println(F("=============="));
    Serial.println(F(" "));
  }  else{
    Serial.println("Communication is ready.");
    Serial.println(F(" "));
  }
}


void SerialCommand::handle() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        lastByteTime = millis();

        if (c == breakChar) {
            inputBuffer[index] = '\0';
            // String command = String(inputBuffer);
            // command.trim();
            trim(inputBuffer);
            checkCommand(inputBuffer);

            // checkCommand(command.c_str());

            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
        else if (isPrintable(c)) {
            if (index < BUFFER_SIZE - 1) {
                inputBuffer[index++] = c;
            }
            else {
                DEBUG_PRINT(F("Buffer overflow. Resetting buffer."));
                index = 0;
                memset(inputBuffer, 0, BUFFER_SIZE);
            }
        }
        else if (c == '\r' || c == '\n') {
            // 忽略回車換行
        }
        else {
            DEBUG_PRINT(F("Invalid character: 0x"));
            DEBUG_PRINTLN((c, HEX));
            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
    }

    if (index > 0 && millis() - lastByteTime > commandTimeout) {
        inputBuffer[index] = '\0';
        // String errCommand = String(inputBuffer);
        // errCommand.trim();
        // trim(inputBuffer);

        DEBUG_PRINTLN(F("Command timeout. Discarding incomplete command."));
        // #if SERIALCOMMAND_USE_EMOJI
          printEmoji(F("⛔"),F("***"));
          // Serial.print(F("⛔"));
        // #endif
        Serial.print(F(" Command must end with '"));
        Serial.print(breakChar);
        Serial.println(F("'"));
        DEBUG_PRINT(F("Your command: "));
        DEBUG_PRINTLN(inputBuffer);
        index = 0;
        memset(inputBuffer, 0, BUFFER_SIZE);
    }
}

void SerialCommand::unusedCommand(){
  printEmoji(F("❕"), F("*"));
  Serial.println(F("Reserved Command."));
}

bool SerialCommand::isAllowedVar(const char* name){
  if (!allowedVarList || allowedVarCount == 0) return true;// 如果沒設定白名單，全部允許
  for (byte i = 0; i < allowedVarCount; i++) {
    if (strcmp(name, allowedVarList[i]) == 0) {
      return true;
    }
  }
  return false;
}


// 新增 setUserVar 方法
void SerialCommand::setUserVar(const char* assignment) {
    char temp[32];
    strncpy(temp, assignment, sizeof(temp)-1);

    char* equalSign = strchr(temp, '=');
    if (equalSign == nullptr) {
        printEmoji(F("⚠️"), F("*"));
        Serial.println(F("Invalid format. Use var=value"));
        return;
    }

    *equalSign = '\0';
    char* varName = temp;
    char* varValueStr = equalSign + 1;

    if (!isAllowedVar(varName)) {
      printEmoji(F("⚠️"), F("*"));
      Serial.print(F("Invalid variable name: "));
      Serial.println(varName);
      return;
    }

    int varValue = atoi(varValueStr);

    // 檢查是否已有相同名稱的變數
    for (byte i = 0; i < varCount; i++) {
        if (strcmp(vars[i].name, varName) == 0) {
            vars[i].value = varValue;
            Serial.print(F(" "));
            Serial.print(F("Updated: "));
            Serial.print(varName);
            Serial.print(F(" = "));
            Serial.println(varValue);
            return;
        }
    }

    // 新增變數
    if (varCount < MAX_VARS) {
        strncpy(vars[varCount].name, varName, sizeof(vars[varCount].name)-1);
        vars[varCount].value = varValue;
        varCount++;
        Serial.print(F(" "));
        Serial.print(FSH(msgSet));
        Serial.print(varName);
        Serial.print(F(" = "));
        Serial.println(varValue);
    } else {
        Serial.println(F("Variable storage full!"));
    }
}


void SerialCommand::showVars() {
    if (varCount == 0) {
    printEmoji(F("⚠️"),F(""));
    Serial.println(F(" No user variables set."));
    return;
  }

  printEmoji(F("📋"), F(""));
  Serial.println(F(" User Variables:"));
  for (byte i = 0; i < varCount; i++) {
    Serial.print(F(" - "));
    Serial.print(vars[i].name);
    Serial.print(F(" = "));
    Serial.println(vars[i].value);
  }
}

// 取得變數值的方法
int SerialCommand::getVar(const char* name, bool &found, int limit){
    for(byte i=0;i<varCount;i++){
        if(strcmp(vars[i].name,name)==0){
          if (vars[i].value <= limit || limit == -1){
              found=true;
              wrongValue = false;
              return vars[i].value;
            }else{
              if(!wrongValue){
                printEmoji(F("⚠️"),F("*"));
                Serial.print("Wrong: ");
                Serial.print(name);
                Serial.print(F(" = "));
                Serial.print(vars[i].value);
                Serial.print(". Maximum : ");
                Serial.print(name);
                Serial.print(F(" = "));
                Serial.print(limit);
                Serial.println(breakChar);
                wrongValue = true;
              }
              found=false;
              return 0;
            }
        }
    }
    found=false;
    return 0;
}
int SerialCommand::getVar(const char* name, int limit){
    bool found;
    return getVar(name, found, limit);
}

inline void showBreakChar(char breakChar){
  if(breakChar != '\r' && breakChar !='\n') {Serial.println(breakChar);}else{Serial.println("");}
}

void SerialCommand::checkCommand(const char* command) {
  if(!setMode){
    int8_t idx = matchCommand(command);
    if (idx >= 0 && idx < CMD_COUNT) {
      strcpy_P(cmd, (PGM_P)pgm_read_ptr(&CMD_STRING[idx]));
      // #if SERIALCOMMAND_USE_EMOJI
          printEmoji(F("✔️"),F("*"));
          // Serial.print(F("✔️"));
      // #endif
      Serial.print(FSH(msgExecuting));
      // Serial.print(F(" "));
      Serial.print(cmd);
      showBreakChar(breakChar);
      // Serial.println(breakChar);
      if(idx == CMD_SET){
        setMode = true;
        printEmoji(F("⚙️"),F(""));
        Serial.println(F("[Entered set mode]"));
      }
    } else {
      // #if SERIALCOMMAND_USE_EMOJI
          // if(showEmoji){
          printEmoji(F("⚠️"),F("*** "));
            // Serial.print(F("⚠️"));
          // }
      // #endif
      Serial.print(FSH(msgUnknown));
      Serial.println(command);
      cmd[0] = '\0';
      showCommands();
    }
  }
  else{
        // 在設定模式時的資料處理
        if (strcmp_P(command, (PGM_P)pgm_read_ptr(&CMD_STRING[CMD_DONE])) == 0) {
            setMode = false;
            printEmoji(F("🔁"),F(""));
            Serial.println(F("[Exited set mode]"));
        } else {
            // 設定模式下的自訂參數處理，可以修改為你需要的邏輯
            // Serial.print(FSH(msgSet));
            // Serial.println(command);
            setUserVar(command);
        }
    }
  }
    


void SerialCommand::showCommands() {
  char temp[8];
        printEmoji(F("💬"),F(""));
        // #if SERIALCOMMAND_USE_EMOJI
        //   if(showEmoji){
        //     Serial.print(F("💬"));
        //   }
        // #endif
        Serial.println(F(" Available commands:"));
        for (int i = 0; i < CMD_COUNT; i++) {
          strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
          printEmoji(F("✔️"),F(" "));
          // #if SERIALCOMMAND_USE_EMOJI
          //   if(showEmoji){
          //     Serial.print(F("✔️"));
          //   }
          // #else
          //     Serial.print(F(" "));
          // #endif
          Serial.print(temp);
          // Serial.print(breakChar);
          showBreakChar(breakChar);
        }
  Serial.println();
}



const char* SerialCommand::getCommand() {
    static char result[BUFFER_SIZE];
    strncpy(result, cmd, BUFFER_SIZE);
    cmd[0] = '\0';
    return result;
}


void SerialCommand::printStatus(SystemStatus status, const __FlashStringHelper* prefix) {
  if (status < STATUS_COUNT) {
    char buffer[32];
    #if SERIALCOMMAND_USE_EMOJI
      if (showEmoji) {
        strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_EMOJI[status]));
        strcat_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
      }else{
        strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
      }
    #else
      // strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_EMOJI[status]));
      strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
    #endif
    if (prefix) {
      Serial.print(prefix);
    } else {
      // printStatus(F("⚪"),F(""));
      printEmoji(F("⚪"),F(""));
      // #if SERIALCOMMAND_USE_EMOJI
      //   if(showEmoji){
      //   Serial.print(F("⚪"));
      //   }
      // #endif
      Serial.print(FSH(msgStatus));
    }
    Serial.println(buffer);
  } else {
      #if SERIALCOMMAND_USE_EMOJI
        if(showEmoji){
          DEBUG_PRINTLN(F("⚠️"));
        }
      #endif
      DEBUG_PRINTLN(F(" Invalid status."));
  }
}

// bool SerialCommand::useEmoji = true;

#if SERIALCOMMAND_USE_EMOJI
  void SerialCommand::printEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text) {
    if (showEmoji) {
      Serial.print(emoji);
    }else{
      Serial.print(text);
    }
  }
  void SerialCommand::printlnEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text) {
    if (showEmoji) {
      Serial.println(emoji);
    }else{
      Serial.println(text);
    }
  }
#else
  void SerialCommand::printEmoji(const __FlashStringHelper*, const __FlashStringHelper* text) {
    Serial.print(text); 
  }
  void SerialCommand::printlnEmoji(const __FlashStringHelper*, const __FlashStringHelper* text) {
    Serial.println(text); 
  }
#endif


void SerialCommand::printDebug(const String& str) {
  if (showDebugText){
    Serial.println(str);  // 一般字串
  }
}
void SerialCommand::printDebug(const char* text) {
  if (showDebugText){
    Serial.println(text);  // 一般字串
  }
}
void SerialCommand::printDebug(const __FlashStringHelper* ftext) {
  if (showDebugText){
    Serial.println(ftext);  // Flash 字串
  }
}


