#ifndef BUTTON_H
    #define BUTTON_H

    #include <arduino.h>
    #include <io_simple.h>


    inline void blinkLamps(int lamp1, int lamp2, int repeat = 10, int interval = 100) {
    int count = 0;
    unsigned long lastBlink = millis();
    while (count < repeat) {
        if (millis() - lastBlink > interval) {
        if (lamp1 != -1) toggle(lamp1);
        if (lamp2 != -1) toggle(lamp2);
        if (lamp1 == -1 && lamp2 == -1) toggle(LED);
        lastBlink = millis();
        count++;
        }
    }
    if (lamp1 != -1) off(lamp1);
    if (lamp2 != -1) off(lamp2);
    if (lamp1 == -1 && lamp2 == -1) off(LED);
    }

    inline bool pressed(int pin1, int pin2 = -1, int buffer = 100, bool longPressed = false,
                        int lamp1 = -1, int lamp2 = -1, int debounceDelay = 30) {
    unsigned long pressStart = 0;

    // 雙鍵模式
    if (pin2 != -1) {
        if (!get(pin1) || !get(pin2)) {
        delay(80); // 簡單彈跳濾除
        if (get(pin1) && get(pin2)) return false;

        if (!get(pin1) && !get(pin2)) {
            pressStart = millis();

            if (!longPressed) {
            // 短按處理
            while (millis() - pressStart < debounceDelay) {
                if (get(pin1) || get(pin2)) return false;
            }
            while (!get(pin1) || !get(pin2)); // 等待放開
            return true;
            } else {
            // 長按處理
            while (!get(pin1) && !get(pin2)) {
                if (millis() - pressStart >= buffer) {
                blinkLamps(lamp1, lamp2);
                while (!get(pin1) || !get(pin2)); // 等待放開
                return true;
                }
            }
            }
        }
        }
        return false;
    }

    // 單鍵模式
    if (!get(pin1)) {
        pressStart = millis();

        if (!longPressed) {
        // 短按
        while (millis() - pressStart < debounceDelay) {
            if (get(pin1)) return false;
        }
        while (!get(pin1)); // 等待放開
        return true;
        } else {
        // 長按
        while (!get(pin1)) {
            if (millis() - pressStart >= buffer) {
            blinkLamps(lamp1, -1);
            while (!get(pin1)); // 等待放開
            return true;
            }
        }
        }
    }

    return false;
    }









#endif