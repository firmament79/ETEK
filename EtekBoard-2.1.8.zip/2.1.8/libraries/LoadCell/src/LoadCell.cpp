#include "LoadCell.h"
#include <string.h>


LoadCell::LoadCell(ModbusRTUMaster& bus, uint8_t slaveId): _bus(bus), _slave(slaveId) {}

bool LoadCell::read(Data& out){
  out = {}; out.ok=false;

  // 指定此物件的從站
  _bus.setSlave(_slave);

  // 個別讀 0048/4A/4B/4C
  uint16_t v48, v4A, v4B, v4C;
  if (_bus.readHolding(0x0048,1,&v48) != ModbusError::OK) return false;
  if (_bus.readHolding(0x004A,1,&v4A) != ModbusError::OK) return false;
  if (_bus.readHolding(0x004B,1,&v4B) != ModbusError::OK) return false;
  if (_bus.readHolding(0x004C,1,&v4C) != ModbusError::OK) return false;

  int16_t raw = (int16_t)v48;
  out.lsd  = mapLSD(v4A);
  out.dp   = mapDP(v4B);
  out.unit = v4C;
  out.val  = (long)raw; //顯示值不用乘lsd
  // out.val  = (long)raw * (long)out.lsd;  // 等價於 round(value * 10^dp)
  out.ok   = true;
  return true;
}

static inline void stripTrailingDot(char* s){ 
  size_t n=strlen(s); 
  if(n>0 && s[n-1]=='.') s[n-1]='\0'; 
}

void LoadCell::formatNumber(char* out, size_t len, long val, uint8_t dp){
  if(val==0){ snprintf(out, len, "0"); return; }

  bool neg = (val<0);
  unsigned long u = neg ? (unsigned long)(-val) : (unsigned long)val;

  char tmp[32]; ultoa(u, tmp, 10);
  int L = (int)strlen(tmp);

  if(dp==0){ 
    snprintf(out, len, neg?"-%s":"%s", tmp); 
    return; 
  }

  if(L<=dp){
    // 例如 val=12, dp=4 -> "0.0012"
    int zeros = dp - L; 
    char frac[40];
    memset(frac,'0',zeros); 
    memcpy(frac+zeros,tmp,L); 
    frac[zeros+L]='\0';
    snprintf(out, len, neg?"-0.%s":"0.%s", frac);
  }else{
    // 例如 "12345", dp=2 -> "123.45"
    int ip = L - dp; 
    char ipart[24], fpart[24];
    memcpy(ipart,tmp,ip); ipart[ip]='\0'; 
    strcpy(fpart,tmp+ip);
    snprintf(out, len, neg?"-%s.%s":"%s.%s", ipart, fpart);
  }

  stripTrailingDot(out);// 防呆，避免輸出成 "0."
}




void LoadCell::frameMOD4(bool type) {
    Data d;
    if (!read(d) || !d.ok) {
        Serial.println(F("ERROR"));
        return;
    }

    char buf[48];
    char result[48];
    formatNumber(buf, sizeof(buf), d.val, d.dp);

    if (!type)
        snprintf(result, sizeof(result), "Start = %s %s", buf, unitName(d.unit));
    else
        snprintf(result, sizeof(result), "Output = %s %s", buf, unitName(d.unit));

    Serial.println(result);
}

// static ModbusRTUMaster* g_bus = nullptr;
// static uint8_t g_slave = 1;

// static inline uint32_t mapLSD(uint16_t c){ switch(c){ case 0:return 1; case 1:return 2; case 2:return 5; case 4:return 10; case 8:return 100; default:return 1; } }
// static inline uint8_t  mapDP (uint16_t c){ switch(c){ case 0:return 0; case 1:return 1; case 2:return 2; case 4:return 3; case 8:return 4; default:return 0; } }

// void LoadCell_attach(ModbusRTUMaster& bus, uint8_t slave){ g_bus=&bus; g_slave=slave; }


// bool LoadCell_readData(LoadCellData& out){
//   out = {}; out.ok=false;
//   if(!g_bus) return false;
//   g_bus->setSlave(g_slave);

//   uint16_t v48,v4A,v4B,v4C;
//   if(g_bus->readHolding(0x0048,1,&v48)!=ModbusError::OK) return false;
//   if(g_bus->readHolding(0x004A,1,&v4A)!=ModbusError::OK) return false;
//   if(g_bus->readHolding(0x004B,1,&v4B)!=ModbusError::OK) return false;
//   if(g_bus->readHolding(0x004C,1,&v4C)!=ModbusError::OK) return false;

//   int16_t raw = (int16_t)v48;
//   out.lsd  = mapLSD(v4A);
//   out.dp   = mapDP(v4B);
//   out.unit = v4C;
//   out.val  = (long)raw;  // 等價 round(value * 10^dp)
//   // out.val  = (long)raw * (long)out.lsd;  // 等價 round(value * 10^dp)
//   out.ok   = true;
//   return true;
// }