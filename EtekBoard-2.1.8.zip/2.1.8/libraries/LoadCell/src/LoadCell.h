#pragma once
#include <Arduino.h>
#include "ModbusRTU.h"



class LoadCell{
  
  public:
    struct Data {
      long     val;   // raw*lsd 的整數
      uint32_t lsd;   // 1,2,5,10,100
      uint8_t  dp;    // 0..4
      uint16_t unit;  // 0 Nt,1 kg,2 lb,4 KN,8 g
      bool     ok;
    };
    
    // 綁定一條 Modbus bus（可共用）與各自的 slave ID
    LoadCell(ModbusRTUMaster& bus, uint8_t slaveId);

    // 讀 0x0048/4A/4B/4C → 填入 out
    bool read(Data& out);
    
    // 格式化數字：val 為 raw*lsd 的整數，dp 控制小數位；val==0 顯示 "0"
    static void formatNumber(char* out, size_t len, long val, uint8_t dp);

    void frameMOD4(bool type = false);

  // 單位映射
    static const char* unitName(uint16_t code) {
      switch(code){ case 0: return "Nt"; case 1: return "KG"; case 2: return "lb"; case 4: return "KN"; case 8: return "g"; default: return "?"; }
    }

    // 允許動態調整目標從站（可選）
    void setSlave(uint8_t slaveId) { _slave = slaveId; }
    uint8_t slave() const { return _slave; }

  private:
    ModbusRTUMaster& _bus;
    uint8_t _slave;

    static inline uint32_t mapLSD(uint16_t c){
      switch(c){ case 0:return 1; case 1:return 2; case 2:return 5; case 4:return 10; case 8:return 100; default:return 1; }
    }
    
    static inline uint8_t mapDP(uint16_t c){
      switch(c){ case 0:return 0; case 1:return 1; case 2:return 2; case 4:return 3; case 8:return 4; default:return 0; }
    }

}; //class LoadCell{