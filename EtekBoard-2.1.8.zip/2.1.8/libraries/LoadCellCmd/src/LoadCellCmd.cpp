#include "LoadCellCmd.h"

// ====== 可調上限：最多登錄幾台秤 ======
#ifndef LOADCELL_MAX_INSTANCES
#define LOADCELL_MAX_INSTANCES 8
#endif

// ====== 前綴顯示結構 ======
struct ScalEntry {
    LoadCell* lc;
    String prefix;
    uint32_t prefixSize;
};

// ====== 全域狀態 ======
static SerialCommand* s_sc = nullptr;
static LoadCell*      s_lcList[LOADCELL_MAX_INSTANCES];
static uint8_t        s_lcCount = 0;
static bool           s_groupRegistered = false;
static ScalEntry      s_lcLabel[LOADCELL_MAX_INSTANCES];
// static uint8_t        g_scales = 0;

// ====== 小工具：格式化輸出 ======
static void _printReading(LoadCell& lc, const __FlashStringHelper* label) {
  LoadCell::Data d;
  if (!lc.read(d) || !d.ok) {
    if (s_sc) s_sc->printStatus(STATUS_ERROR);
    else      Serial.println(F("ERROR"));
    return;
  }
  char num[32];
  LoadCell::formatNumber(num, sizeof(num), d.val, d.dp);

  Serial.print(label);  Serial.print(F(" = "));
  Serial.print(num);    Serial.print(' ');
  Serial.println(LoadCell::unitName(d.unit));
}

// ====== 小工具：解析 "=n" 參數 → 回傳 1..count；無或錯誤回 -1 ======
static int8_t _parseIndex(const char* args, uint8_t count){
  if (!count) return -1;
  if (!args)  return 1;

  // 跳過前置空白
  while (*args==' ' || *args=='\t') ++args;
  // 若還有 '='（例如 args 是 "=2" 的情況）就再跳過
  if (*args == '=') {
    ++args;
    while (*args==' ' || *args=='\t') ++args;
  }
  if (!*args) return 1;

  // 解析純數字
  int n = 0;
  while (*args >= '0' && *args <= '9') {
    n = n*10 + (*args - '0');
    ++args;
  }
  if (n < 1 || n > count) return -1;
  return (int8_t)n;
}

// static int8_t _parseIndex(const char* args, uint8_t count){
//   if (!count) return -1;
//   if (!args || !*args) return 1;           // 預設 =1
//   // 跳過空白
//   while (*args==' ' || *args=='\t') ++args;
//   // 尋找 '='
//   const char* p = args;
//   while (*p && *p!='=') ++p;
//   if (*p != '=') return 1;                  // 沒寫 '=' 視同 1
//   ++p;
//   // 跳過空白
//   while (*p==' ' || *p=='\t') ++p;
//   if (!*p) return 1;
//   // 解析數字
//   int n = 0;
//   while (*p>='0' && *p<='9'){
//     n = n*10 + (*p - '0');
//     ++p;
//   }
//   if (n < 1 || n > count) return -1;
//   return (int8_t)n;
// }

// ====== help；列出格式與已註冊秤 ======
static void _printHelpAll(){
  Serial.println(F("=== LoadCell Commands (multi-station) ==="));
  Serial.println(F("Usage:"));
  Serial.println(F("  get=<n>;  // read & update vars from scale n (default n=1)"));
  Serial.println(F("  sp=<n>;   // print \"Start = ...\" from scale n"));
  Serial.println(F("  op=<n>;   // print \"Output = ...\" from scale n"));
  Serial.println(F("  help;     // show this list"));
  Serial.println();

  uint8_t maxLen = 0;
  char label[24];
  for (uint8_t i = 0; i<s_lcCount; i++){
    const char* tag = s_lcLabel[i].prefix.length() ? s_lcLabel[i].prefix.c_str() : "n";
    snprintf(label, sizeof(label), "%s=%u", tag, (unsigned)(i+1));
    uint8_t L = (uint8_t)strlen(label);
    if ( L> maxLen) maxLen = L;
  }


  Serial.print(F("Registered scales: ")); Serial.println(s_lcCount);
  for(uint8_t i=0;i<s_lcCount;i++){
    // Serial.print(F("  ")); 
    Serial.print(F("  (")); 
    Serial.print(i+1);
    Serial.print(F(") ID=")); Serial.print(s_lcList[i]->slave());
    Serial.print(F("  ")); 
    // const char* tag = s_lcLabel[i].prefix.length() ? Serial.print(s_lcLabel[i].prefix) : Serial.print("");
    // if (s_lcLabel[i].prefix != "") Serial.print(s_lcLabel[i].prefix); Serial.print(F(")"));
    const char* tag = s_lcLabel[i].prefix.length() ? s_lcLabel[i].prefix.c_str() : "";
    // if (tag == "n") snprintf(label, sizeof(label), "[]", tag, (unsigned)(i+1));
    snprintf(label, sizeof(label), "[%s]", tag, (unsigned)(i+1));
    
    // uint8_t L = (uint8_t)strlen(label);
    // uint8_t pad = (maxLen > L) ? (maxLen - L) : 0;
    // Serial.print(F(" "));
    Serial.print(label);
    // while (pad--) Serial.print(' '); //補空格
    // Serial.print(F("  n=")); Serial.print(i+1);
    // 若你的 LoadCell 類別有 slave() 存取器
    Serial.println();
  }
  if(s_lcCount==0){
    Serial.println(F("  (none)  -> call bindLoadCellCommands(cmd, scaleX); in setup"));
  }
}

// ====== 群組 handler：idx=0:getlc, 1:startp, 2:outputp, 3:help ======
static void _cmd_handler(uint8_t idx, const char* args){
  switch(idx){
    case 0: { // getlc
      if (!s_sc || s_lcCount==0) return;
      int8_t n = _parseIndex(args, s_lcCount);
      if (n < 0) { s_sc->printStatus(STATUS_ERROR); return; }
      LoadCell& lc = *s_lcList[n-1];

      LoadCell::Data d;
      if (!lc.read(d) || !d.ok) { s_sc->printStatus(STATUS_ERROR); return; }

      // 更新白名單變數（共同變數名；誰最後寫誰生效）
      char buf[48];
      snprintf(buf, sizeof(buf), "val=%ld", d.val);                 s_sc->setUserVar(buf, false);
      snprintf(buf, sizeof(buf), "lsd=%lu", (unsigned long)d.lsd);  s_sc->setUserVar(buf, false);
      snprintf(buf, sizeof(buf), "dp=%u", d.dp);                    s_sc->setUserVar(buf, false);
      snprintf(buf, sizeof(buf), "unit=%u", d.unit);                s_sc->setUserVar(buf, false);

      _printReading(lc, F("Get"));
      s_sc->printStatus(STATUS_FINISH);
    } break;

    case 1: { // startp
      if (s_lcCount==0) return;
      int8_t n = _parseIndex(args, s_lcCount);
      if (n < 0) { if(s_sc) s_sc->printStatus(STATUS_ERROR); return; }
      _printReading(*s_lcList[n-1], F("Start"));
    } break;

    case 2: { // outputp
      if (s_lcCount==0) return;
      int8_t n = _parseIndex(args, s_lcCount);
      if (n < 0) { if(s_sc) s_sc->printStatus(STATUS_ERROR); return; }
      _printReading(*s_lcList[n-1], F("Output"));
    } break;

    case 3: // help
      _printHelpAll();
      break;
  }
}

// ====== 公開：登錄秤（可呼叫多次）；第一次時註冊群組 ======
void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc, const char* prefix){
  // 登錄秤（多次呼叫加入陣列）
  if (s_lcCount < LOADCELL_MAX_INSTANCES){
      s_lcLabel[s_lcCount].lc = &lc;
      s_lcLabel[s_lcCount].prefix = (prefix && *prefix) ? prefix : "";
      s_lcLabel[s_lcCount].prefixSize = sizeof(prefix);
      s_lcList[s_lcCount++] = &lc;
    }

  // 第一次呼叫時註冊群組與白名單
  if (!s_groupRegistered){
    s_groupRegistered = true;
    s_sc = &sc;

    // 白名單變數（讓 setUserVar 接受 val/lsd/dp/unit）
    static const char* const VARS[] = { "val", "lsd", "dp", "unit" };
    const int8_t vg = sc.addVarGroup(VARS, 4, SerialCommand::STORAGE_RAM);

    // 指令清單（固定名稱，透過 =n 指定秤號）
    static const char* const CMDS[] = { "get", "sp", "op", "help" };

    // 只註冊一次群組（不多吃 group 名額）
    sc.addCommandGroup(CMDS, 4, _cmd_handler, vg, SerialCommand::STORAGE_RAM);
  }
}



// ******************************
// #include "LoadCellCmd.h"

// // 全域變數：單秤模式
// static SerialCommand* s_sc = nullptr;
// static LoadCell*      s_lc = nullptr;
// static String         s_pf;
// static bool           s_bound = false;   // 防止重複綁定

// // 共用輸出
// static void _printReading(const __FlashStringHelper* label) {
//   if (!s_lc) return;

//   LoadCell::Data d;
//   if (!s_lc->read(d) || !d.ok) {
//     if (s_sc) s_sc->printStatus(STATUS_ERROR);
//     else      Serial.println(F("ERROR"));
//     return;
//   }

//   char num[32];
//   LoadCell::formatNumber(num, sizeof(num), d.val, d.dp);

//   Serial.print(label);  Serial.print(F(" = "));
//   Serial.print(num);    Serial.print(' ');
//   Serial.println(LoadCell::unitName(d.unit));
// }

// // help 指令
// static void _printHelp() {
//   Serial.println(F("LoadCell Commands:"));
//   Serial.print(s_pf); Serial.println(F("getlc;"));
//   Serial.print(s_pf); Serial.println(F("startp;"));
//   Serial.print(s_pf); Serial.println(F("outputp;"));
//   Serial.print(s_pf); Serial.println(F("help;"));
// }

// // 群組 handler
// static void _cmd_handler(uint8_t idx, const char* /*args*/) {
//   switch (idx) {
//     case 0: { // getlc
//       if (!s_sc || !s_lc) return;
//       LoadCell::Data d;
//       if (!s_lc->read(d) || !d.ok) { s_sc->printStatus(STATUS_ERROR); return; }

//       char buf[48];
//       snprintf(buf, sizeof(buf), "val=%ld", d.val);                 s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "lsd=%lu", (unsigned long)d.lsd);  s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "dp=%u", d.dp);                    s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "unit=%u", d.unit);                s_sc->setUserVar(buf, false);

//       _printReading(F("GetLC"));
//       s_sc->printStatus(STATUS_FINISH);
//     } break;

//     case 1: _printReading(F("Start"));  break;
//     case 2: _printReading(F("Out"));    break;
//     case 3: _printHelp();               break; // help 不送 FINISH
//   }
// }

// void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc, const char* prefix) {
//   if (s_bound) return;
//   s_bound = true;

//   s_sc = &sc;
//   s_lc = &lc;
//   s_pf = (prefix && *prefix) ? prefix : "";

//   // 白名單變數
//   static const char* const VARS[] = { "val", "lsd", "dp", "unit" };
//   const int8_t vg = sc.addVarGroup(VARS, 4, SerialCommand::STORAGE_RAM);

//   // 準備指令名稱
//   static char c0[20], c1[20], c2[20], c3[20];
//   if (s_pf.length() > 0) {
//     snprintf(c0, sizeof(c0), "%s%s", s_pf.c_str(), "getlc");
//     snprintf(c1, sizeof(c1), "%s%s", s_pf.c_str(), "startp");
//     snprintf(c2, sizeof(c2), "%s%s", s_pf.c_str(), "outputp");
//     snprintf(c3, sizeof(c3), "%s%s", s_pf.c_str(), "help");
//   } else {
//     strncpy(c0, "getlc", sizeof(c0));
//     strncpy(c1, "startp", sizeof(c1));
//     strncpy(c2, "outputp", sizeof(c2));
//     strncpy(c3, "help", sizeof(c3));
//   }

//   static const char* CMDS[] = { c0, c1, c2, c3 };

//   // 註冊為 1 組（含前綴）
//   sc.addCommandGroup(CMDS, 4, _cmd_handler, vg, SerialCommand::STORAGE_RAM);
// }





// *************************

// #include "LoadCellCmd.h"

// // 單一秤：全域指標
// static SerialCommand* s_sc = nullptr;
// static LoadCell*      s_lc = nullptr;
// static bool           s_bound = false;   // 防止重複綁定

// // 共用輸出
// static void _printReading(const __FlashStringHelper* label) {
//   if (!s_lc) return;

//   LoadCell::Data d;
//   if (!s_lc->read(d) || !d.ok) {
//     if (s_sc) s_sc->printStatus(STATUS_ERROR);
//     else      Serial.println(F("ERROR"));
//     return;
//   }

//   char num[32];
//   LoadCell::formatNumber(num, sizeof(num), d.val, d.dp);

//   Serial.print(label);  Serial.print(F(" = "));
//   Serial.print(num);    Serial.print(' ');
//   Serial.println(LoadCell::unitName(d.unit));
// }

// // help：只列指令，不動變數／不送 FINISH（避免你說的「help; 多打幾次就變成顯示」）
// static void _printHelp() {
//   Serial.println(F("LoadCell Commands:"));
//   Serial.println(F("getlc;"));
//   Serial.println(F("startp;"));
//   Serial.println(F("outputp;"));
// //   Serial.println(F("help;"));
// }

// // 群組 handler：0=getlc, 1=startp, 2=outputp, 3=help
// static void _cmd_handler(uint8_t idx, const char* /*args*/) {
//   switch (idx) {
//     case 0: { // getlc → 讀取 + 更新變數 + 共用輸出 + FINISH
//       if (!s_sc || !s_lc) return;
//       LoadCell::Data d;
//       if (!s_lc->read(d) || !d.ok) { s_sc->printStatus(STATUS_ERROR); return; }

//       // 更新白名單變數
//       char buf[48];
//       snprintf(buf, sizeof(buf), "val=%ld", d.val);                 s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "lsd=%lu", (unsigned long)d.lsd);  s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "dp=%u", d.dp);                    s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "unit=%u", d.unit);                s_sc->setUserVar(buf, false);

//       // 顯示數值
//       _printReading(F("GetLC"));

//       // 最後送完成狀態（只在成功時送）
//       s_sc->printStatus(STATUS_FINISH);
//     } break;

//     case 1: _printReading(F("Start"));  break;
//     case 2: _printReading(F("Output")); break;

//     case 3: _printHelp();               break; // 不送 FINISH、不更動變數
//   }
// }

// void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc) {
//   if (s_bound) return;          // 避免重複註冊造成行為怪異
//   s_bound = true;

//   s_sc = &sc;
//   s_lc = &lc;

//   // 建立變數白名單，讓 setUserVar 可寫入 val/lsd/dp/unit
//   static const char* const VARS[] = { "val", "lsd", "dp", "unit" };
//   const int8_t vg = sc.addVarGroup(VARS, 4, SerialCommand::STORAGE_RAM);

//   // 指令清單（單一群組、無前綴）
//   static const char* const CMDS[] = { "getlc", "startp", "outputp", "help" };

//   // 註冊為 1 組（不會多吃群組數量）
//   sc.addCommandGroup(CMDS, 4, _cmd_handler, vg, SerialCommand::STORAGE_RAM);
// }




// #include "LoadCellCmd.h"

// // ====== 1) 每組綁定的 Context（最多 4 組，對應 MAX_CMD_GROUPS） ======
// struct LoadCellCtx {
//   SerialCommand* sc;
//   LoadCell*      lc;
//   String         prefix;
//   // 為了存放帶前綴的命令名，提供常駐緩衝（避免用暫時字串）
//   char cmd0[20]; // <prefix>getlc
//   char cmd1[20]; // <prefix>startp
//   char cmd2[20]; // <prefix>outputp
// };

// // 插槽
// static LoadCellCtx s_ctx[4];
// static uint8_t     s_ctxCount = 0;  // 下一個可用插槽索引

// // ====== 2) 共用小工具 ======
// static void _printReading(LoadCellCtx* ctx, const __FlashStringHelper* label) {
//   if (!ctx || !ctx->lc) return;

//   LoadCell::Data d;
//   if (!ctx->lc->read(d) || !d.ok) {
//     if (ctx->sc) ctx->sc->printStatus(STATUS_ERROR);
//     else         Serial.println(F("ERROR"));
//     return;
//   }

//   char num[32];
//   LoadCell::formatNumber(num, sizeof(num), d.val, d.dp);

//   Serial.print(label);  Serial.print(F(" = "));
//   Serial.print(num);    Serial.print(' ');
//   Serial.println(LoadCell::unitName(d.unit));
// }

// static void _printHelp(LoadCellCtx* ctx) {
//   Serial.println(F("LoadCell Commands:"));
//   // 三個跟 prefix
//   Serial.print(ctx->prefix); Serial.println(F("getlc;"));
//   Serial.print(ctx->prefix); Serial.println(F("startp;"));
//   Serial.print(ctx->prefix); Serial.println(F("outputp;"));
//   // help 永遠無前綴
// //   Serial.println(F("help;"));
// }

// // 核心 handler：依插槽 + 群組內索引，執行對應動作
// static void _handleCore(uint8_t slot, uint8_t idx, const char* args) {
//   LoadCellCtx* ctx = (slot < s_ctxCount) ? &s_ctx[slot] : nullptr;
//   if (!ctx) return;

//   switch (idx) {
//       case 0: { // getlc
//         if (!ctx->sc || !ctx->lc) return;
//         LoadCell::Data d;
//         if (!ctx->lc->read(d) || !d.ok) {
//           ctx->sc->printStatus(STATUS_ERROR);
//           return;
//         }
      
//         // 設定變數
//         char buf[48];
//         snprintf(buf, sizeof(buf), "val=%ld", d.val);                 ctx->sc->setUserVar(buf, false);
//         snprintf(buf, sizeof(buf), "lsd=%lu", (unsigned long)d.lsd);  ctx->sc->setUserVar(buf, false);
//         snprintf(buf, sizeof(buf), "dp=%u", d.dp);                    ctx->sc->setUserVar(buf, false);
//         snprintf(buf, sizeof(buf), "unit=%u", d.unit);                ctx->sc->setUserVar(buf, false);
      
//         // 顯示數值（共用輸出）
//         _printReading(ctx, F("GetLC"));
      
//         // 最後回報完成
//         ctx->sc->printStatus(STATUS_FINISH);
//       } break;
      
//       case 1: _printReading(ctx, F("Start"));  break;
//       case 2: _printReading(ctx, F("Out"));    break;
//       case 3: _printHelp(ctx);                 break;
//   }
// }

// // ====== 3) 為每個插槽準備一個「無捕捉」包裝函式（函式指標 OK） ======
// static void _handler0(uint8_t idx, const char* args){ _handleCore(0, idx, args); }
// static void _handler1(uint8_t idx, const char* args){ _handleCore(1, idx, args); }
// static void _handler2(uint8_t idx, const char* args){ _handleCore(2, idx, args); }
// static void _handler3(uint8_t idx, const char* args){ _handleCore(3, idx, args); }

// void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc, const char* prefix){
//   if (s_ctxCount >= 4) {  // 防超過 MAX_CMD_GROUPS
//     Serial.println(F("LoadCellCmd: no free context slot"));
//     return;
//   }

//   // 取得本次的插槽
//   uint8_t slot = s_ctxCount++;
//   LoadCellCtx& ctx = s_ctx[slot];
//   ctx.sc = &sc;
//   ctx.lc = &lc;
//   ctx.prefix = (prefix && *prefix) ? prefix : "";

//   // 變數白名單
//   static const char* const VARS[] = { "val", "lsd", "dp", "unit" };
//   int8_t vg = sc.addVarGroup(VARS, 4, SerialCommand::STORAGE_RAM);

//   // 準備 4 個命令名（idx:0..3）：前三個可帶前綴，第 4 個固定 "help"
//   static const char* const NOPFX[4] = { "getlc", "startp", "outputp", "help" };
//   const char* cmds[4];

//   if (ctx.prefix.length() == 0) {
//     // 無前綴 → 直接使用常量
//     cmds[0] = NOPFX[0];
//     cmds[1] = NOPFX[1];
//     cmds[2] = NOPFX[2];
//     cmds[3] = NOPFX[3]; // help 無前綴
//   } else {
//     // 有前綴 → 拼前三個；help 固定無前綴
//     snprintf(ctx.cmd0, sizeof(ctx.cmd0), "%s%s", ctx.prefix.c_str(), "getlc");
//     snprintf(ctx.cmd1, sizeof(ctx.cmd1), "%s%s", ctx.prefix.c_str(), "startp");
//     snprintf(ctx.cmd2, sizeof(ctx.cmd2), "%s%s", ctx.prefix.c_str(), "outputp");
//     cmds[0] = ctx.cmd0;
//     cmds[1] = ctx.cmd1;
//     cmds[2] = ctx.cmd2;
//     cmds[3] = "help";
//   }

//   // 對應插槽選用對應的包裝 handler
//   SerialCommand::UserCmdHandler h = nullptr;
//   switch (slot) {
//     case 0: h = _handler0; break;
//     case 1: h = _handler1; break;
//     case 2: h = _handler2; break;
//     case 3: h = _handler3; break;
//   }

//   // 註冊成一個群組（只占 1 個 group 名額）
//   sc.addCommandGroup(cmds, 4, h, vg, SerialCommand::STORAGE_RAM);
// }




// #include "LoadCellCmd.h"

// // 綁定後要用到的物件
// static SerialCommand* s_sc = nullptr;
// static LoadCell*      s_lc = nullptr;
// static String         s_pf;

// // ---------- 共用輸出 ----------
// static void _printReading(const __FlashStringHelper* label) {
//   if (!s_lc) return;

//   LoadCell::Data d;
//   if (!s_lc->read(d) || !d.ok) {
//     Serial.println(F("ERROR"));
//     return;
//   }

//   char num[32];
//   LoadCell::formatNumber(num, sizeof(num), d.val, d.dp);

//   Serial.print(label);  Serial.print(F(" = "));
//   Serial.print(num);    Serial.print(' ');
//   Serial.println(LoadCell::unitName(d.unit));
// }

// // 新增：help 內容
// static void _printHelp() {
//   Serial.println(F("LoadCell Commands:"));
//   Serial.print(s_pf); Serial.println(F("getlc;"));
//   Serial.print(s_pf); Serial.println(F("startp;"));
//   Serial.print(s_pf); Serial.println(F("outputp;"));
// //   Serial.println(F("help;"));
// }

// // 群組 handler：idx 0..3
// static void _cmd_handler(uint8_t idx, const char* /*args*/) {
//   switch (idx) {
//     case 0: { // getlc
//       if (!s_sc || !s_lc) return;
//       LoadCell::Data d;
//       if (!s_lc->read(d) || !d.ok) {
//         s_sc->printStatus(STATUS_ERROR);
//         return;
//       }
//       char buf[48];
//       snprintf(buf, sizeof(buf), "val=%ld", d.val);                 s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "lsd=%lu", (unsigned long)d.lsd);  s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "dp=%u", d.dp);                    s_sc->setUserVar(buf, false);
//       snprintf(buf, sizeof(buf), "unit=%u", d.unit);                s_sc->setUserVar(buf, false);
//       s_sc->printStatus(STATUS_FINISH);
//     } break;

//     case 1: // startp
//       _printReading(F("Start"));
//       break;

//     case 2: // outputp
//       _printReading(F("Out"));
//       break;

//     case 3: // help
//       _printHelp();
//       break;

//     default:
//       break;
//   }
// }

// void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc, const char* prefix) {
//   s_sc = &sc;
//   s_lc = &lc;
//   s_pf = (prefix && *prefix) ? prefix : "";

//   // 1) 變數白名單（讓 setUserVar 容得下 val/lsd/dp/unit）
//   static const char* const VARS[] = { "val", "lsd", "dp", "unit" };
//   const int8_t vg = sc.addVarGroup(VARS, 4, SerialCommand::STORAGE_RAM);

//   // 2) 指令名（多一個 help）
//   static const char* const CMDS_NO_PREFIX[] = { "getlc", "startp", "outputp", "help" };
//   const bool hasPrefix = (s_pf.length() > 0);

//   // 若有前綴，拼接後存到可長存的 static 緩衝
//   static char p0[20], p1[20], p2[20];
//   static const char* CMDS_MIXED[4];

//   const char* const* cmdList = CMDS_NO_PREFIX;
//   uint8_t cmdCount = 4;
//   SerialCommand::Storage storage = SerialCommand::STORAGE_RAM;

//   if (hasPrefix) {
//     snprintf(p0, sizeof(p0), "%s%s", s_pf.c_str(), "getlc");
//     snprintf(p1, sizeof(p1), "%s%s", s_pf.c_str(), "startp");
//     snprintf(p2, sizeof(p2), "%s%s", s_pf.c_str(), "outputp");
//     // snprintf(p3, sizeof(p3), "%s%s", s_pf.c_str(), "help");
//     CMDS_MIXED[0] = p0;
//     CMDS_MIXED[1] = p1;
//     CMDS_MIXED[2] = p2;
//     CMDS_MIXED[3] = "help";
//     cmdList = CMDS_MIXED;
//   }

//   // 3) 以群組方式註冊（帶上 var group）
//   sc.addCommandGroup(cmdList, cmdCount, _cmd_handler, vg, storage);

// }











