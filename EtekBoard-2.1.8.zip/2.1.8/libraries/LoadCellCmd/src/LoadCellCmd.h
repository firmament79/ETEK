#pragma once
#include <Arduino.h>
#include "SerialCommand.h"
#include "LoadCell.h"

// extern const char* const loadcellVars[];
// extern const byte loadcellVarCount;

// extern const char* const loadcellCMD[];
// extern const byte loadcellCmdCount;


void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc, const char* prefix="");
// void bindLoadCellCommands(SerialCommand& sc, LoadCell& lc);


// void LoadCell_register(SerialCommand& sc);   // 把 getv;/startp;/outputp; 綁進來



// static void _getlc();
// static void _printlc(const char* label);


