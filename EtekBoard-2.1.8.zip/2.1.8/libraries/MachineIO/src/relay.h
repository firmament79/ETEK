#ifndef RELAY_H
    #define RELAY_H


    #include <arduino.h>
    #include <io_simple.h>


struct Contact{
    uint8_t pin;
    enum Type {NO = 0, NC = 1} type;

    Contact(uint8_t p, Type t = NO): pin(p), type(t) {}

    bool isTriggered() const{
        if (type == NO) return !get(pin);
        else return get(pin);
    }
}






#endif //RELAY_H