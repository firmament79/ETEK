#include "ModbusRTU.h"
#include <SoftwareSerial.h>

//指向軟體串列埠
ModbusRTUMaster::ModbusRTUMaster(Stream& port){ _ser=&port; _isHW=false;}
//HardwareSerial& por 指向硬體序列埠物件的參考
ModbusRTUMaster::ModbusRTUMaster(HardwareSerial& port){ _ser=&port; _isHW=true;}


//硬體UART
// void ModbusRTUMaster::begin(uint32_t baud, uint32_t config, int dePin){
//   _dePin = dePin;
//   if(_dePin>=0){ pinMode(_dePin, OUTPUT); digitalWrite(_dePin, LOW); }
//   _ser->begin(baud, config);
//   // 依 baud 粗估 turnaround
//   _turnaroundUs = (uint16_t)( (1000000.0 * 10.0 / baud) * 40 ); // ~4 chars
// }

void ModbusRTUMaster::begin(uint32_t baud, uint32_t config, int dePin){
_baud = baud;
  _dePin = dePin;
  if(_dePin>=0){ pinMode(_dePin, OUTPUT); digitalWrite(_dePin, LOW); }
  if(_isHW){
    // cast 回 HardwareSerial 才能呼叫 begin(baud, config)
    static_cast<HardwareSerial*>(_ser)->begin(baud, config);
  }
  else{
    // SoftwareSerial 沒有 config，直接忽略 config
    // 注意：只能 8N1
    ((SoftwareSerial*)_ser)->begin(baud);
  }
  // 估算 turn-around（約 4 chars）
  const uint32_t tchar_us = (11UL * 1000000UL) / baud; // 以 8N1/8N2 都抓 ~11 bits
  _turnaroundUs = 4 * tchar_us;
}

// 軟體 UART 專用入口（語意清楚）
void ModbusRTUMaster::beginSoft(uint32_t baud, int dePin){
  begin(baud, SERIAL_8N1, dePin); // 內部會根據 _isHW 決定怎麼開
}




void ModbusRTUMaster::setSlave(uint8_t s){ _slave=s; }
void ModbusRTUMaster::setTimeout(uint16_t ms){ _timeoutMs=ms; }
void ModbusRTUMaster::setTurnaroundUs(uint16_t us){ _turnaroundUs=us; }
void ModbusRTUMaster::setTX(bool en){ if(_dePin>=0) digitalWrite(_dePin, en?HIGH:LOW);}

uint16_t ModbusRTUMaster::crc16(const uint8_t* d, size_t n){
  uint16_t crc=0xFFFF;
  for(size_t i=0;i<n;i++){ 
    crc^=d[i]; // 先跟當前 byte 做 XOR
    for(uint8_t b=0;b<8;b++) crc=(crc&1)?(crc>>1)^0xA001:(crc>>1); 
  }
  return crc;
}

ModbusError ModbusRTUMaster::readHolding(uint16_t reg, uint16_t qty, uint16_t* out){
  return txrx03(reg, qty, out);
}
ModbusError ModbusRTUMaster::writeSingle(uint16_t reg, uint16_t value){
  return txrx06(reg, value);
}

// ModbusError ModbusRTUMaster::txrx03(uint16_t reg, uint16_t qty, uint16_t* out){
//   if(!out || qty==0) return ModbusError::FrameError;
//   uint8_t tx[8] = { _slave, 0x03, uint8_t(reg>>8), uint8_t(reg), uint8_t(qty>>8), uint8_t(qty) };
//   uint16_t c = crc16(tx,6); tx[6]=c&0xFF; tx[7]=c>>8;

//   while(_ser->available()) _ser->read();
//   setTX(true); _ser->write(tx,8); _ser->flush(); delayMicroseconds(_turnaroundUs); setTX(false);

//   // 預期長度
//   const size_t need = 3 + 2*qty + 2;
//   uint8_t rx[64]; size_t idx=0; uint32_t t0=millis();
//   _exCode=0;

//   while(millis()-t0 < _timeoutMs){
//     while(_ser->available() && idx<sizeof(rx)) rx[idx++]=_ser->read();
//     if(idx>=5){
//       if(rx[0]!=_slave) continue;
//       if(rx[1]==(0x03|0x80)){ _exCode = rx[2]; return ModbusError::Exception; }
//       if(rx[1]!=0x03) return ModbusError::FrameError;
//       if(idx >= need){
//         uint16_t rcrc = rx[need-2] | (uint16_t(rx[need-1])<<8);
//         if(crc16(rx, need-2)!=rcrc) return ModbusError::CrcMismatch;
//         if(rx[2] != 2*qty) return ModbusError::FrameError;
//         for(uint16_t i=0;i<qty;i++) out[i]=(uint16_t(rx[3+2*i])<<8)|rx[4+2*i];
//         return ModbusError::OK;
//       }
//     }
//   }
//   return ModbusError::Timeout;
// }


ModbusError ModbusRTUMaster::txrx03(uint16_t reg, uint16_t qty, uint16_t* out) {
    if (!out || qty == 0) return ModbusError::FrameError;

    uint8_t tx[8] = {
        _slave, 0x03,
        uint8_t(reg >> 8), uint8_t(reg),
        uint8_t(qty >> 8), uint8_t(qty)
    };
    uint16_t c = crc16(tx, 6);
    tx[6] = c & 0xFF; tx[7] = c >> 8;

    // 清空殘留
    while (_ser->available()) _ser->read();

    // 建議以波特率換算 t3.5（這裡示意：若你有 _baud）
    // const uint32_t tchar_us = (11UL * 1000000UL) / _baud;
    // const uint32_t t3_5_us  = (uint32_t)(3.5f * tchar_us);
    setTX(true);
    _ser->write(tx, 8);
    _ser->flush();               // 等待送完
    setTX(false);
    delayMicroseconds(_turnaroundUs); // 或用 t3_5_us

    // 預期長度（正常回覆）
    const size_t need = 5 + 2 * qty;
    uint8_t rx[64];
    size_t idx = 0;
    uint32_t t0 = millis();
    uint32_t lastByteAt = t0;
    _exCode = 0;

    // 先檢查 qty 是否超過緩衝最大可承載
    const size_t maxQty = (sizeof(rx) - 5) / 2;
    if (qty > maxQty) return ModbusError::FrameError; // 或 BufferTooSmall 自定義

    while (millis() - t0 < _timeoutMs) {
        while (_ser->available() && idx < sizeof(rx)) {
            rx[idx++] = _ser->read();
            lastByteAt = millis();
        }

        // 若一段時間（t1.5）沒新 byte，可嘗試評估目前資料
        // const uint32_t t1_5_us = (uint32_t)(1.5f * tchar_us); // 若有波特率
        // if (idx > 0 && (micros() - lastByteAt_us) > t1_5_us) { ... }

        if (idx >= 5) {
            // 對齊：檢查目標站台
            if (rx[0] != _slave) {
                // 丟棄到只留最後一個 byte，嘗試重新對齊
                rx[0] = rx[idx - 1];
                idx = 1;
                continue;
            }

            // 例外回覆（長度應為 5）
            if (rx[1] == (0x03 | 0x80)) {
                if (idx >= 5) {
                    uint16_t rcrc = rx[3] | (uint16_t(rx[4]) << 8);
                    if (crc16(rx, 3) != rcrc) return ModbusError::CrcMismatch;
                    _exCode = rx[2];
                    return ModbusError::Exception;
                }
            }

            // 正常回覆
            if (rx[1] == 0x03) {
                if (idx >= need) {
                    // 驗 CRC
                    uint16_t rcrc = rx[need - 2] | (uint16_t(rx[need - 1]) << 8);
                    if (crc16(rx, need - 2) != rcrc) return ModbusError::CrcMismatch;

                    // 驗 byte count
                    if (rx[2] != 2 * qty) return ModbusError::FrameError;

                    // 擷取資料（Big‑Endian 每寄存器 2 bytes）
                    for (uint16_t i = 0; i < qty; i++) {
                        out[i] = (uint16_t(rx[3 + 2 * i]) << 8) | rx[4 + 2 * i];
                    }
                    return ModbusError::OK;
                }
            } else {
                // 非 0x03/例外 → 格式錯誤，丟棄重對齊
                rx[0] = rx[idx - 1];
                idx = 1;
            }
        }

        // 簡單的字間隔判斷：若已收到資料且一段時間沒有新資料，避免拖到整體 timeout
        if (idx > 0 && (millis() - lastByteAt) > (_timeoutMs / 4)) {
            // 已經卡一陣子，依目前資料長度直接判斷
            if (idx >= 5 && rx[0] == _slave && rx[1] == (0x03 | 0x80) && idx >= 5) {
                uint16_t rcrc = rx[3] | (uint16_t(rx[4]) << 8);
                if (crc16(rx, 3) != rcrc) return ModbusError::CrcMismatch;
                _exCode = rx[2];
                return ModbusError::Exception;
            }
            if (idx >= 5 && rx[0] == _slave && rx[1] == 0x03) {
                // 若 byte count 剛好吻合且有 CRC，就提早結束
                uint8_t bc = rx[2];
                size_t maybe = 5 + bc;
                if (bc % 2 == 0 && maybe + 2 <= idx) {
                    uint16_t rcrc = rx[maybe] | (uint16_t(rx[maybe + 1]) << 8);
                    if (crc16(rx, maybe) != rcrc) return ModbusError::CrcMismatch;
                    size_t q = bc / 2;
                    if (q > qty) return ModbusError::FrameError; // 或允許小於請求量
                    for (uint16_t i = 0; i < q; i++) {
                        out[i] = (uint16_t(rx[3 + 2 * i]) << 8) | rx[4 + 2 * i];
                    }
                    // 若 q != qty，可視規格回 FrameError；這裡採嚴格
                    if (q != qty) return ModbusError::FrameError;
                    return ModbusError::OK;
                }
            }
        }
    }

    return ModbusError::Timeout;
}



// ModbusError ModbusRTUMaster::txrx06(uint16_t reg, uint16_t value){
//   uint8_t tx[8] = { _slave, 0x06, uint8_t(reg>>8), uint8_t(reg), uint8_t(value>>8), uint8_t(value) };
//   uint16_t c = crc16(tx,6); tx[6]=c&0xFF; tx[7]=c>>8;

//   while(_ser->available()) _ser->read();
//   setTX(true); _ser->write(tx,8); _ser->flush(); delayMicroseconds(_turnaroundUs); setTX(false);

//   uint8_t rx[8]; size_t idx=0; uint32_t t0=millis(); _exCode=0;
//   while(millis()-t0 < _timeoutMs){
//     while(_ser->available() && idx<sizeof(rx)) rx[idx++]=_ser->read();
//     if(idx>=5){
//       if(rx[0]!=_slave) continue;
//       if(rx[1]==(0x06|0x80)){ _exCode=rx[2]; return ModbusError::Exception; }
//       if(idx>=8){
//         uint16_t rcrc = rx[6] | (uint16_t(rx[7])<<8);
//         if(crc16(rx,6)!=rcrc) return ModbusError::CrcMismatch;
//         // 成功時設備會回顯同一包參數
//         for(uint8_t i=0;i<6;i++) if(rx[i]!=tx[i]) return ModbusError::FrameError;
//         return ModbusError::OK;
//       }
//     }
//   }
//   return ModbusError::Timeout;
// }

ModbusError ModbusRTUMaster::txrx06(uint16_t reg, uint16_t value) {
    uint8_t tx[8] = {
        _slave, 0x06,
        uint8_t(reg >> 8),   uint8_t(reg),
        uint8_t(value >> 8), uint8_t(value)
    };
    uint16_t c = crc16(tx, 6);
    tx[6] = c & 0xFF; tx[7] = c >> 8;

    // 清空殘留
    while (_ser->available()) _ser->read();

    // 建議：以波特率換算 t3.5（若你有 _baud）
    // const uint32_t tchar_us = (11UL * 1000000UL) / _baud;
    // const uint32_t t3_5_us  = (uint32_t)(3.5f * tchar_us);

    setTX(true);
    _ser->write(tx, 8);
    _ser->flush();
    setTX(false);
    delayMicroseconds(_turnaroundUs /* 或 t3_5_us */);

    uint8_t  rx[8];
    size_t   idx = 0;
    uint32_t t0  = millis();
    uint32_t lastByteAt = t0;
    _exCode = 0;

    while (millis() - t0 < _timeoutMs) {
        while (_ser->available() && idx < sizeof(rx)) {
            rx[idx++] = _ser->read();
            lastByteAt = millis();
        }

        if (idx >= 5) {
            // 對齊：若站號不對，嘗試重對齊（保留最後一個 byte）
            if (rx[0] != _slave) {
                rx[0] = rx[idx - 1];
                idx = 1;
                continue;
            }

            // 例外回覆：長度應為 5（ID, FC|0x80, EX, CRClo, CRChi）
            if (rx[1] == (0x06 | 0x80)) {
                if (idx >= 5) {
                    uint16_t rcrc = rx[3] | (uint16_t(rx[4]) << 8);
                    if (crc16(rx, 3) != rcrc) return ModbusError::CrcMismatch;
                    _exCode = rx[2];
                    return ModbusError::Exception;
                }
            }

            // 正常回覆：應為 8 bytes，且內容回顯請求
            if (rx[1] == 0x06 && idx >= 8) {
                uint16_t rcrc = rx[6] | (uint16_t(rx[7]) << 8);
                if (crc16(rx, 6) != rcrc) return ModbusError::CrcMismatch;

                // 嚴格回顯比對（前 6 bytes）
                for (uint8_t i = 0; i < 6; i++) {
                    if (rx[i] != tx[i]) return ModbusError::FrameError;
                }
                return ModbusError::OK;
            }

            // 功能碼不符 → 重對齊
            if (rx[1] != 0x06 && rx[1] != (0x06 | 0x80)) {
                rx[0] = rx[idx - 1];
                idx = 1;
                continue;
            }
        }

        // 簡易字間隔：若已收但一段時間無新資料，提早判斷
        if (idx > 0 && (millis() - lastByteAt) > (_timeoutMs / 4)) {
            // 若已經足夠構成例外 5 bytes 或正常 8 bytes，就按現有長度驗證
            if (idx >= 5 && rx[0] == _slave && rx[1] == (0x06 | 0x80)) {
                uint16_t rcrc = rx[3] | (uint16_t(rx[4]) << 8);
                if (crc16(rx, 3) != rcrc) return ModbusError::CrcMismatch;
                _exCode = rx[2];
                return ModbusError::Exception;
            }
            if (idx >= 8 && rx[0] == _slave && rx[1] == 0x06) {
                uint16_t rcrc = rx[6] | (uint16_t(rx[7]) << 8);
                if (crc16(rx, 6) != rcrc) return ModbusError::CrcMismatch;
                for (uint8_t i = 0; i < 6; i++) {
                    if (rx[i] != tx[i]) return ModbusError::FrameError;
                }
                return ModbusError::OK;
            }
        }
    }

    return ModbusError::Timeout;
}


