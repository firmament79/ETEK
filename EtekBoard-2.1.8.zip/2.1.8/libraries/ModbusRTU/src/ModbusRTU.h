#ifndef MODBUSRTU_H
    #define MODBUSRTU_H
#pragma once
#include <Arduino.h>
#include <Stream.h>

enum class ModbusError : uint8_t{
    OK=0, Timeout, CrcMismatch, Exception, FrameError
};

class ModbusRTUMaster {

public:
    explicit ModbusRTUMaster(Stream& port);
    explicit ModbusRTUMaster(HardwareSerial& port /*= Serial1*/);

    void begin(uint32_t baud=9600, uint32_t config=SERIAL_8N1, int dePin=-1);
    void beginSoft(uint32_t baud=9600, int dePin=-1);
    void setSlave(uint8_t slave);
    void setTimeout(uint16_t ms); //預設80~120ms
    void setTurnaroundUs(uint16_t us); //預設依baud推估3.5chars+

    //基本功能碼
    ModbusError readHolding(uint16_t reg, uint16_t qty, uint16_t* out);
    ModbusError writeSingle(uint16_t reg, uint16_t value);

    // 例外碼 (當返回 Exception 時可讀
    uint8_t lastExceptionCode() const { return _exCode;}


private:
    ModbusError txrx03(uint16_t reg, uint16_t qty, uint16_t* out);
    ModbusError txrx06(uint16_t reg, uint16_t value);
    void setTX(bool en);
    static uint16_t crc16(const uint8_t* buf, size_t len);

    // HardwareSerial* _ser;
    Stream* _ser = nullptr;
    bool _isHW = false;
    uint32_t _baud = 9600;
    int _dePin = -1;
    uint8_t _slave = 1;
    uint16_t _timeoutMs = 80;
    uint16_t _turnaroundUs = 4000;  // 預設大約 9600 bps 的 3.5~4 chars
    uint8_t _exCode = 0;
};













#endif //MODBUSRTU_H