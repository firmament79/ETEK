#include <SoftwareSerial.h>

struct SoftMB {
  SoftwareSerial* ss = nullptr;
  int  dePin = -1;
  uint32_t baud = 9600;
  uint16_t timeoutMs = 200;
  uint16_t turnaroundUs = 5000;
  bool debug = true; // ← 打開除錯輸出

  void begin(SoftwareSerial& port, unsigned long bps, int de=-1){
    ss=&port; baud=bps; dePin=de;
    if (dePin>=0){ pinMode(dePin, OUTPUT); digitalWrite(dePin, LOW); }
    ss->begin(baud); // 8N1
    const uint32_t tchar = (11UL * 1000000UL) / baud;
    turnaroundUs = 4 * tchar;
  }
  void setTimeout(uint16_t ms){ timeoutMs = ms; }
  void setTurnaroundUs(uint16_t us){ turnaroundUs = us; }
  inline void setTx(bool en){ if(dePin>=0) digitalWrite(dePin, en?HIGH:LOW); }

  static uint16_t crc16(const uint8_t* data, uint16_t len){
    uint16_t crc=0xFFFF;
    for(uint16_t i=0;i<len;i++){
      crc ^= data[i];
      for(uint8_t b=0;b<8;b++) crc = (crc&1)?((crc>>1)^0xA001):(crc>>1);
    }
    return crc;
  }
  void waitTxDoneBytes(uint16_t bytes){
    const uint32_t perChar_us = (11UL * 1000000UL) / baud;
    delayMicroseconds(perChar_us * bytes);
  }
  void clearRx(){
    while (ss->available()) (void)ss->read();
  }
  void dump(const uint8_t* p, uint16_t n, const char* tag){
    if(!debug) return;
    Serial.print(tag); Serial.print(" [");
    for(uint16_t i=0;i<n;i++){
      if(i) Serial.print(' ');
      if(p[i]<16) Serial.print('0');
      Serial.print(p[i], HEX);
    }
    Serial.println("]");
  }

  bool read03(uint8_t slave, uint16_t addr, uint16_t qty, uint16_t* out){
    if (!ss) return false;

    uint8_t tx[8] = { slave, 0x03,
      uint8_t(addr>>8), uint8_t(addr),
      uint8_t(qty>>8),  uint8_t(qty), 0,0 };
    uint16_t crc = crc16(tx,6); tx[6]=crc&0xFF; tx[7]=crc>>8;

    clearRx();                   // ← 先清掉殘留
    setTx(true);
    size_t sent = ss->write(tx, 8);
    waitTxDoneBytes(sent);       // ← 等 TX 真送完
    setTx(false);
    delayMicroseconds(turnaroundUs);

    if(debug) dump(tx, 8, "TX");

    const uint16_t expect = 5 + 2*qty;  // slave,03,bcnt,data...,crc2
    uint8_t rx[64]; uint16_t rlen=0;
    uint32_t t0=millis();
    while ((millis()-t0) < timeoutMs){
      while (ss->available()){
        if (rlen < sizeof(rx)) rx[rlen++] = (uint8_t)ss->read();
      }
      if (rlen >= expect) break;
    }
    if (rlen == 0){
      if(debug) Serial.println(F("RX: none (timeout)"));
      return false;
    }
    if(debug) dump(rx, rlen, "RX");

    // 例外回應：slave, 0x83, exCode, crcL, crcH
    if (rlen >= 5 && rx[0]==slave && rx[1]==0x83){
      if(debug){ Serial.print(F("Exception code = ")); Serial.println(rx[2]); }
      return false;
    }

    if (rlen < expect) { if(debug) Serial.println(F("RX too short")); return false; }
    if (rx[0]!=slave)  { if(debug) Serial.println(F("Addr mismatch")); return false; }
    if (rx[1]!=0x03)   { if(debug) Serial.println(F("FC mismatch"));   return false; }
    if (rx[2] != qty*2){ if(debug) Serial.println(F("bcnt mismatch")); return false; }

    uint16_t got = rx[rlen-2] | (uint16_t(rx[rlen-1])<<8);
    uint16_t cal = crc16(rx, rlen-2);
    if (got != cal)    { if(debug){ Serial.print(F("CRC bad got=")); Serial.print(got,HEX); Serial.print(F(" cal=")); Serial.println(cal,HEX);} return false; }

    for(uint16_t i=0;i<qty;i++){
      out[i] = (uint16_t(rx[3+2*i])<<8) | rx[4+2*i];
    }
    return true;
  }
};
