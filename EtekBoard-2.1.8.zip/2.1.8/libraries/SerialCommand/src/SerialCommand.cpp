#include "SerialCommand.h"

#define FSH(str) (reinterpret_cast<const __FlashStringHelper*>(str))


static inline void trim(char* str) {
  char* p = str;
  while (isspace(*p)) ++p;
  size_t len = strlen(p);
  while (len > 0 && isspace(p[len - 1])) --len;
  p[len] = '\0';
  memmove(str, p, len + 1);
}

const char status_0[]  PROGMEM = "None";
const char status_1[]  PROGMEM = "FINISH";
const char status_2[]  PROGMEM = "WAITING";
const char status_3[]  PROGMEM = "CHECK";
const char status_4[]  PROGMEM = "PROGRESS";
const char status_5[]  PROGMEM = "BUSY";
const char status_6[]  PROGMEM = "START";
const char status_7[]  PROGMEM = "STOP";
const char status_8[]  PROGMEM = "PAUSE";
const char status_9[]  PROGMEM = "RESUME";
const char status_10[] PROGMEM = "RESET";
const char status_11[] PROGMEM = "SETPARAM";
const char status_12[] PROGMEM = "ERROR";
const char* const STATUS_MESSAGES[STATUS_COUNT] PROGMEM ={
    status_0,    status_1,    status_2,    status_3,    status_4,    status_5,
    status_6,    status_7,    status_8,    status_9,    status_10,   status_11,
    status_12,
};


#if SERIALCOMMAND_USE_EMOJI
const char emoji_0[]  PROGMEM = "";     //None";
const char emoji_1[]  PROGMEM = "🔵";  //FINISH";
const char emoji_2[]  PROGMEM = "🟡";  //WAITING";
const char emoji_3[]  PROGMEM = "❕";  //CHECK";
const char emoji_4[]  PROGMEM = "🟣";  //PROGRESS";
const char emoji_5[]  PROGMEM = "🟠";  //BUSY";
const char emoji_6[]  PROGMEM = "🟢";  //START";
const char emoji_7[]  PROGMEM = "🔴";  //STOP";
const char emoji_8[]  PROGMEM = "🟡";  //PAUSE";
const char emoji_9[]  PROGMEM = "🟢";  //RESUME";
const char emoji_10[] PROGMEM = "⚪";  //RESET";
const char emoji_11[] PROGMEM = "⚙️";  //SETPARAM";
const char emoji_12[] PROGMEM = "❌";  //ERROR";
const char* const STATUS_EMOJI[STATUS_COUNT] PROGMEM={
    emoji_0,    emoji_1,    emoji_2,    emoji_3,    emoji_4,    emoji_5,
    emoji_6,    emoji_7,    emoji_8,    emoji_9,    emoji_10,   emoji_11,
    emoji_12,
};
#endif





const char cmd_0[] PROGMEM = "start";
const char cmd_1[] PROGMEM = "stop";
const char cmd_2[] PROGMEM = "reset";
const char cmd_3[] PROGMEM = "pause";
const char cmd_4[] PROGMEM = "resume";
const char cmd_5[] PROGMEM = "set";
const char cmd_6[] PROGMEM = "done";
const char cmd_7[] PROGMEM = "ack";
const char cmd_8[] PROGMEM = "burn";
const char cmd_9[] PROGMEM = "show";

const char* const CMD_STRING[CMD_COUNT] PROGMEM = {
  cmd_0, cmd_1, cmd_2, cmd_3, cmd_4, cmd_5, cmd_6, cmd_7, cmd_8, cmd_9,
};

const char msgSet[]   PROGMEM = "Set: ";
const char msgExecuting[] PROGMEM = "Executing: ";
const char msgUnknown[]   PROGMEM = "Unknown: ";
const char msgStatus[]    PROGMEM = "Status: ";


int8_t matchCommand(const char* command) {
  char temp[8];
  for (int i = 0; i < CMD_COUNT; i++) {
    strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
    if (strcmp(command, temp) == 0) return i;
  }
  return -1;
}


SerialCommand::SerialCommand(char breakChar_, unsigned long timeout_) 
  : index(0), lastByteTime(0), commandTimeout(timeout_), breakChar(breakChar_), cmd("") {
    memset(inputBuffer, 0, BUFFER_SIZE);
}

void SerialCommand::begin(long baudrate) {
    Serial.begin(baudrate);
    DEBUG_PRINTLN(F("begin ready"));
}

inline String getName(String name){
  // String name = SOURCE_FILE;
    // 去掉副檔名
  int lastDot = name.lastIndexOf('.');
  if (lastDot >= 0) {
    name = name.substring(0, lastDot);
  }
  // Serial.println(name);
  return name;
}

void SerialCommand::showInfo(bool enable){
  if(enable){
    Serial.println(F("===Build Info==="));
    Serial.print(F("Board: "));
    Serial.println(BOARD_PACKAGE_NAME);
    Serial.print(F("Board Package: "));
    Serial.println(BOARD_PACKAGE_VERSION);
    Serial.print(F("Source file: "));
    Serial.println(getName(SOURCE_FILE));
    // Serial.println(SOURCE_FILE);
    Serial.print(F("Compiled on: "));  
    Serial.print(__DATE__);
    Serial.print(F(" "));
    Serial.println(__TIME__);
    Serial.println(F("=============="));
    Serial.println(F(" "));
  }  else{
    Serial.println("Communication is ready.");
    Serial.println(F(" "));
  }
}


void SerialCommand::handle() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        lastByteTime = millis();

        if (c == breakChar) {
            inputBuffer[index] = '\0';
            // String command = String(inputBuffer);
            // command.trim();
            trim(inputBuffer);
            checkCommand(inputBuffer);

            // checkCommand(command.c_str());

            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
        else if (isPrintable(c)) {
            if (index < BUFFER_SIZE - 1) {
                inputBuffer[index++] = c;
            }
            else {
                DEBUG_PRINT(F("Buffer overflow. Resetting buffer."));
                index = 0;
                memset(inputBuffer, 0, BUFFER_SIZE);
            }
        }
        else if (c == '\r' || c == '\n') {
            // 忽略回車換行
        }
        else {
            DEBUG_PRINT(F("Invalid character: 0x"));
            DEBUG_PRINTLN((c, HEX));
            index = 0;
            memset(inputBuffer, 0, BUFFER_SIZE);
        }
    }

    if (index > 0 && millis() - lastByteTime > commandTimeout) {
        inputBuffer[index] = '\0';
        // String errCommand = String(inputBuffer);
        // errCommand.trim();
        // trim(inputBuffer);

        DEBUG_PRINTLN(F("Command timeout. Discarding incomplete command."));
        // #if SERIALCOMMAND_USE_EMOJI
          printEmoji(F("⛔"),F("***"));
          // Serial.print(F("⛔"));
        // #endif
        Serial.print(F(" Command must end with '"));
        Serial.print(breakChar);
        Serial.println(F("'"));
        DEBUG_PRINT(F("Your command: "));
        DEBUG_PRINTLN(inputBuffer);
        index = 0;
        memset(inputBuffer, 0, BUFFER_SIZE);
    }
}

void SerialCommand::unusedCommand(){
  printEmoji(F("❕"), F("Info: "));
  Serial.print(F("Reserved Command"));
  showBreakChar();
}

// bool SerialCommand::isAllowedVar(const char* name){
//   if (!allowedVarList || allowedVarCount == 0) return true;// 如果沒設定白名單，全部允許
//   for (byte i = 0; i < allowedVarCount; i++) {
//     if (strcmp(name, allowedVarList[i]) == 0) {
//       return true;
//     }
//   }
//   return false;
// }


// bool SerialCommand::isAllowedVar(const char* name) const {
//   if (activeVarGroup < 0) return false;
//   const VarGroup& vg = varGroups[activeVarGroup];
//   for (uint8_t i = 0; i < vg.count; ++i) {
//     const char* n = vg.names[i];
//     if (strcmp(name, n) == 0) return true;
//   }
//   return false;
// }


// 若命令比對處理有用到群組清單，記得用 _readPtr / _strcmpSel
// 範例（示意）：在原本迴圈比對 token 與群組指令時：
// const char* entry = _readPtr(groups[g].list, j, groups[g].storage);
// if (_strcmpSel(token, entry, groups[g].storage) == 0) { /* 命中 */ }
bool SerialCommand::isAllowedVar(const char* name) const {
  if (activeVarGroup < 0) return false;
  const VarGroup& vg = varGroups[activeVarGroup];
  for (uint8_t i = 0; i < vg.count; ++i) {
    const char* entry = _readPtr(vg.names, i, vg.storage);
    if (_strcmpSel(name, entry, vg.storage) == 0) return true;
  }
  return false;
}



// bool SerialCommand::isAllowedCmd(const char* name){
//   // if (!allowedCmdList || allowedCmdList == 0) return true;// 如果沒設定白名單，全部允許
//   for (byte i = 0; i < allowedCmdCount; i++) {
//     if (strcmp(name, allowedCmdList[i]) == 0) {
//       return true;
//     }
//   }
//   return false;
// }

// int8_t SerialCommand::findAllowedCmdIndex(const char* name){
//   if (!allowedCmdList || allowedCmdCount == 0) return -1;
//   for (byte i = 0; i < allowedCmdCount; ++i) {
//     if (strcmp(allowedCmdList[i], name) == 0) return i;
//   }
//   return -1;
// }

int8_t SerialCommand::addVarGroup(const char* const* names, uint8_t count, Storage storage){
  if (varGroupCount >= MAX_VAR_GROUPS) return -1;
  varGroups[varGroupCount].names = names;
  varGroups[varGroupCount].count = count;
  varGroups[varGroupCount].storage = storage;
  return varGroupCount++;
}



//額外CMD群組
bool SerialCommand::addCommandGroup(const char* const* list, uint8_t count, UserCmdHandler handler,int8_t varGroup, Storage storage){
  if (groupCount >= MAX_CMD_GROUPS) return false;
  groups[groupCount].list = list;
  groups[groupCount].count = count;
  groups[groupCount].handler = handler;
  groups[groupCount].varGroup = varGroup;
  groups[groupCount].storage  = storage;
  groupCount++;
  return true;
}

int8_t SerialCommand::findAllowedCmdIndex(const char* name, uint8_t& outGroupIdx){
  for (uint8_t g = 0; g < groupCount; ++g) {
    for (uint8_t i = 0; i < groups[g].count; ++i) {
      // if (strcmp(groups[g].list[i], name) == 0) {
      const char* entry = _readPtr(groups[g].list, i, groups[g].storage);
      if (_strcmpSel(name, entry, groups[g].storage) == 0) {
        outGroupIdx = g;
        return i; // cmd index within group
      }
    }
  }
  outGroupIdx = 0xFF;
  return -1;
}



const char* SerialCommand::extractArgs(const char* command, const char* name){
  const char* p = command + strlen(name);
  while (*p == ' ' || *p == '=') ++p;  // 支援 "go 123" 或 "go=123"
  return p; // 若沒有參數會指向 '\0'
}

// 新增 setUserVar 方法
void SerialCommand::setUserVar(const char* assignment, bool enableText) {
    char temp[32];
    strncpy(temp, assignment, sizeof(temp)-1);
    temp[sizeof(temp)-1] = '\0';

    char* equalSign = strchr(temp, '=');
    if (equalSign == nullptr) {
        printEmoji(F("⚠️"), F("Error: "));
        Serial.print(F("Invalid format. Use var=value"));
        showBreakChar();
        return;
    }

    *equalSign = '\0';
    char* varName = temp;
    char* varValueStr = equalSign + 1;

    if (!isAllowedVar(varName)) {
      printEmoji(F("⚠️"), F("Error: "));
      Serial.print(F("Invalid variable name: "));
      Serial.print(varName);
      showBreakChar();
      return;
    }

    int varValue = atoi(varValueStr);

    // 相同名稱的變數改為更新
    for (byte i = 0; i < varCount; i++) {
        if (strcmp(vars[i].name, varName) == 0) {
            vars[i].value = varValue;
            if (enableText){
              Serial.print(F(" "));
              Serial.print(F("Updated: "));
              Serial.print(varName);
              Serial.print(F(" = "));
              Serial.print(varValue);
              showBreakChar();
            }
            return;
        }
    }

    // 新增變數
    if (varCount < MAX_VARS) {
        strncpy(vars[varCount].name, varName, sizeof(vars[varCount].name)-1);
        vars[varCount].value = varValue;
        varCount++;
        if (enableText){
          Serial.print(F(" "));
          Serial.print(FSH(msgSet));
          Serial.print(varName);
          Serial.print(F(" = "));
          Serial.print(varValue);
          showBreakChar();
        }
    } else {
        Serial.print(F("Variable storage full"));
        showBreakChar();
    }
}


void SerialCommand::showVars() {
    if (varCount == 0) {
    printEmoji(F("⚠️"),F("Warning:"));
    Serial.print(F(" No user variables set"));
    showBreakChar();
    return;
  }

  printEmoji(F("📋"), F(""));
  for (byte i = 0; i < varCount; i++) {
    Serial.print(F(" - "));
    Serial.print(vars[i].name);
    Serial.print(F(" = "));
    Serial.println(vars[i].value);
  }
}

// 取得變數值
int SerialCommand::getVar(const char* name, bool &found, int limit){
    for(byte i=0;i<varCount;i++){
        if(strcmp(vars[i].name,name)==0){
          if (vars[i].value <= limit || limit == -1){
              found=true;
              // wrongValue = false;
              return vars[i].value;
            }else{
              // if(!wrongValue){
              //   printEmoji(F("⚠️"),F("Error: "));
              //   // Serial.print("Wrong: ");
              //   Serial.print(name);
              //   Serial.print(F(" = "));
              //   Serial.print(vars[i].value);
              //   Serial.print(". Maximum : ");
              //   Serial.print(name);
              //   Serial.print(F(" = "));
              //   Serial.print(limit);
              //   Serial.println(breakChar);
              //   wrongValue = true;
              //   // vars[i].value = 0;
              // }
              found=false;
              return 0;
            }
        }
    }
    found=false;
    return 0;
}

//取得變數(簡化版)
int SerialCommand::getVar(const char* name, int limit){
    bool found;
    return getVar(name, found, limit);
}

//顯示breakchar
void SerialCommand::showBreakChar(){
  if(breakChar != '\r' && breakChar !='\n') {Serial.println(breakChar);}else{Serial.println();}
}

//確認指令是否是內建或自訂白名單
void SerialCommand::checkCommand(const char* command) {
  if(!isSetMode){
    // 1) 先比對內建指令
    int8_t idx = matchCommand(command);
    if (idx >= 0 && idx < CMD_COUNT) {
      strcpy_P(cmd, (PGM_P)pgm_read_ptr(&CMD_STRING[idx]));
          printEmoji(F("✔️"),F("*"));
      Serial.print(FSH(msgExecuting));
      Serial.print(cmd);
      showBreakChar();

      if(idx == CMD_SET && allowedSetMode){
        isSetMode = true;
        printEmoji(F("⚙️"),F("System: "));
        Serial.print(F("Entered set mode"));
        showBreakChar();
      }else if (idx == CMD_SHOW){
        // showVars();
      }
      // 其他內建如有需要可在這裡擴充
      return;
    }
    
    // 2) 不是內建 → 試「使用者白名單指令」
    char name[16];
    size_t n = 0;
    while (command[n] && command[n] != ' ' && command[n] != '=' && n<sizeof(name)-1){
      name[n] = command[n];
      ++n;
    }
    name[n] = '\0';

    uint8_t gidx;
    // int8_t uidx = findAllowedCmdIndex(name);
    int8_t cidx = findAllowedCmdIndex(name, gidx);
    // if (uidx >= 0) {
    if (cidx >= 0 && gidx < groupCount) {
      printEmoji(F("✔️"),F("*"));
      Serial.print(F("Executing: "));
      Serial.print(command);
      showBreakChar();
      const char* args = extractArgs(command, name);

      // if (userCmdHandler) {
      //   userCmdHandler((uint8_t)uidx, args);  // 把索引交給 .ino
      // }
      // if (groups[gidx].handler) groups[gidx].handler((uint8_t)cidx, args);
        // 綁定作用變數群組 → 呼叫 → （可選）解除綁定
      activeVarGroup = groups[gidx].varGroup;
      if (groups[gidx].handler) groups[gidx].handler((uint8_t)cidx, args);
      activeVarGroup = -1;
      return;
    }
    
    printEmoji(F("⚠️"),F("*** "));
    Serial.print(FSH(msgUnknown));
    Serial.print(command);
    showBreakChar();
    cmd[0] = '\0';
    showCommands();
    return;
  }
  
  // setMode：done 結束，其他字串走 setUserVar()（你的變數機制）
  if (allowedSetMode){
    if (strcmp_P(command, (PGM_P)pgm_read_ptr(&CMD_STRING[CMD_DONE])) == 0) {
      isSetMode = false;
      printEmoji(F("🔁"), F("System: "));
      Serial.print(F("Exited set mode"));
      showBreakChar();
    } else {
      setUserVar(command);
    }
  }

  // else{
  //       // 在設定模式時的資料處理
  //       if (strcmp_P(command, (PGM_P)pgm_read_ptr(&CMD_STRING[CMD_DONE])) == 0) {
  //           isSetMode = false;
  //           printEmoji(F("🔁"),F(""));
  //           Serial.println(F("[Exited set mode]"));
  //       } else {
  //           // 設定模式下的自訂參數處理，可以修改為你需要的邏輯
  //           // Serial.print(FSH(msgSet));
  //           // Serial.println(command);
  //           setUserVar(command);
  //       }
  //   }

  }
    


void SerialCommand::showCommands() {
  char temp[8];
        printEmoji(F("💬"),F(""));
        Serial.println(F(" Available commands:"));
        for (int i = 0; i < CMD_COUNT; i++) {
          strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
          printEmoji(F("✔️"),F(" "));
          Serial.print(temp);
          showBreakChar();
        }        
        // if (allowedCmdList && allowedCmdCount >0){
        //   for (int i = 0; i < allowedCmdCount; i++) {
        //     // strcpy_P(temp, (PGM_P)pgm_read_ptr(&CMD_STRING[i]));
        //     printEmoji(F("✔️"),F(" "));
        //     Serial.print(allowedCmdList[i]);
        //     showBreakChar();
        //   }
        // }
        if (groupCount){
          // Serial.println(F("User Commands:"));
          for (uint8_t g=0; g<groupCount; ++g){
            for (uint8_t i=0; i<groups[g].count; ++i){
              // Serial.print(F(" - ")); 
              printEmoji(F("✔️"),F(" "));
              Serial.print(groups[g].list[i]);
              showBreakChar();
            }
          }
        }
  Serial.println();
}



const char* SerialCommand::getCommand() {
    static char result[BUFFER_SIZE];
    strncpy(result, cmd, BUFFER_SIZE);
    cmd[0] = '\0';
    return result;
}


void SerialCommand::printStatus(SystemStatus status, const __FlashStringHelper* prefix) {
  if (status < STATUS_COUNT) {
    char buffer[32];
    #if SERIALCOMMAND_USE_EMOJI
      if (showEmoji) {
        strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_EMOJI[status]));
        strcat_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
      }else{
        strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
      }
    #else
      // strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_EMOJI[status]));
      strcpy_P(buffer, (PGM_P)pgm_read_ptr(&STATUS_MESSAGES[status]));
    #endif
    if (prefix) {
      Serial.print(prefix);
    } else {
      // printStatus(F("⚪"),F(""));
      printEmoji(F("⚪"),F(""));
      // #if SERIALCOMMAND_USE_EMOJI
      //   if(showEmoji){
      //   Serial.print(F("⚪"));
      //   }
      // #endif
      Serial.print(FSH(msgStatus));
    }
    Serial.print(buffer);
    showBreakChar();
  } else {
      #if SERIALCOMMAND_USE_EMOJI
        if(showEmoji){
          DEBUG_PRINTLN(F("⚠️"));
        }
      #endif
      DEBUG_PRINTLN(F(" Invalid status."));
  }
}

// bool SerialCommand::useEmoji = true;

#if SERIALCOMMAND_USE_EMOJI
  void SerialCommand::printEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text) {
    if (showEmoji) {
      Serial.print(emoji);
    }else{
      Serial.print(text);
    }
  }
  void SerialCommand::printlnEmoji(const __FlashStringHelper* emoji, const __FlashStringHelper* text) {
    if (showEmoji) {
      Serial.println(emoji);
    }else{
      Serial.println(text);
    }
  }
#else
  void SerialCommand::printEmoji(const __FlashStringHelper*, const __FlashStringHelper* text) {
    Serial.print(text); 
  }
  void SerialCommand::printlnEmoji(const __FlashStringHelper*, const __FlashStringHelper* text) {
    Serial.println(text); 
  }
#endif


void SerialCommand::printDebug(const String& str) {
  if (showDebugText){
    Serial.println(str);  // 一般字串
  }
}
void SerialCommand::printDebug(const char* text) {
  if (showDebugText){
    Serial.println(text);  // 一般字串
  }
}
void SerialCommand::printDebug(const __FlashStringHelper* ftext) {
  if (showDebugText){
    Serial.println(ftext);  // Flash 字串
  }
}


