#pragma once
#include <Arduino.h>

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
    #define NULLVALUE nullptr
  #else
    #define CONSTEXPR const
    #define NULLVALUE NULL
  #endif
#else
  #define CONSTEXPR const
  #define NULLVALUE NULL
#endif



typedef struct {
  volatile uint8_t* ddr;
  volatile uint8_t* port;
  uint8_t bit;
} PinInit;

// --- Arduino 腳位名稱定義（提供 digitalWrite 調用） ---

CONSTEXPR uint8_t LED   = 13; //PB5

CONSTEXPR uint8_t JO1   = 2;  //PD2
CONSTEXPR uint8_t JO2   = 3;  //PD3
CONSTEXPR uint8_t JO3   = 4;  //PD4
CONSTEXPR uint8_t JO4   = 5;  //PD5
CONSTEXPR uint8_t JO5   = 6;  //PD6

CONSTEXPR uint8_t JSN1  = 7;  //PD7
CONSTEXPR uint8_t JSN2  = 8;  //PB0
CONSTEXPR uint8_t JSN3  = 9;  //PB1
CONSTEXPR uint8_t JSN4  = 10; //PB2
CONSTEXPR uint8_t JSN5  = 11; //PB3
CONSTEXPR uint8_t JSN6  = 12; //PB4
CONSTEXPR uint8_t JSN7  = 14; //PC0
CONSTEXPR uint8_t JSN8  = 15; //PC1
CONSTEXPR uint8_t JSN9  = 16; //PC2
CONSTEXPR uint8_t JSN10 = 17; //PC3
CONSTEXPR uint8_t JSN11 = 18; //PC4
CONSTEXPR uint8_t JSN12 = 19; //PC5




// --- 底層控制定義 ---

// --- 輸出腳位定義 ---
const PinInit OUTPUT_PINS[] PROGMEM = {
  { },  // 0
  { },  // 1
  { &DDRD, &PORTD, PD2 },  // 2  = JO1
  { &DDRD, &PORTD, PD3 },  // 3  = JO2
  { &DDRD, &PORTD, PD4 },  // 4  = JO3
  { &DDRD, &PORTD, PD5 },  // 5  = JO4
  { &DDRD, &PORTD, PD6 },  // 6  = JO5
  { },  // 7  = JSN1
  { },  // 8  = JSN2
  { },  // 9  = JSN3
  { },  // 10 = JSN4
  { },  // 11 = JSN5
  { },  // 12 = JSN6
  { &DDRB, &PORTB, PB5 },  // 13 = LED
  { },  // 14 = JSN7
  { },  // 15 = JSN8
  { },  // 16 = JSN9
  { },  // 17 = JSN10
  { },  // 18 = JSN11
  { },  // 19 = JSN12
};


// --- 輸入+上拉腳位定義 ---
const PinInit INPUT_PULLUP_PINS[] PROGMEM = {
  { },  // 0
  { },  // 1
  { },  // 2  = JO1
  { },  // 3  = JO2
  { },  // 4  = JO3
  { },  // 5  = JO4
  { },  // 6  = JO5
  { &DDRD, &PORTD, PD7 },  // 7  = JSN1
  { &DDRB, &PORTB, PB0 },  // 8  = JSN2
  { &DDRB, &PORTB, PB1 },  // 9  = JSN3
  { &DDRB, &PORTB, PB2 },  // 10 = JSN4
  { &DDRB, &PORTB, PB3 },  // 11 = JSN5
  { &DDRB, &PORTB, PB4 },  // 12 = JSN6
  { },  // 13 = LED
  { &DDRC, &PORTC, PC0 },  // 14 = JSN7
  { &DDRC, &PORTC, PC1 },  // 15 = JSN8
  { &DDRC, &PORTC, PC2 },  // 16 = JSN9
  { &DDRC, &PORTC, PC3 },  // 17 = JSN10
  { &DDRC, &PORTC, PC4 },  // 18 = JSN11
  { &DDRC, &PORTC, PC5 },  // 19 = JSN12
};

// --- 輸入腳位定義（無上拉） ---
const PinInit INPUT_PINS[] PROGMEM = {
  // 若有，放在這邊
};



const PinInit pinMap[] PROGMEM = {
  { &DDRD, &PORTD, PD0 },  // 0
  { &DDRD, &PORTD, PD1 },  // 1
  { &DDRD, &PORTD, PD2 },  // 2  = JO1
  { &DDRD, &PORTD, PD3 },  // 3  = JO2
  { &DDRD, &PORTD, PD4 },  // 4  = JO3
  { &DDRD, &PORTD, PD5 },  // 5  = JO4
  { &DDRD, &PORTD, PD6 },  // 6  = JO5
  { &DDRD, &PORTD, PD7 },  // 7  = JSN1
  { &DDRB, &PORTB, PB0 },  // 8  = JSN2
  { &DDRB, &PORTB, PB1 },  // 9  = JSN3
  { &DDRB, &PORTB, PB2 },  // 10 = JSN4
  { &DDRB, &PORTB, PB3 },  // 11 = JSN5
  { &DDRB, &PORTB, PB4 },  // 12 = JSN6
  { &DDRB, &PORTB, PB5 },  // 13 = LED
  { &DDRC, &PORTC, PC0 },  // 14 = JSN7
  { &DDRC, &PORTC, PC1 },  // 15 = JSN8
  { &DDRC, &PORTC, PC2 },  // 16 = JSN9
  { &DDRC, &PORTC, PC3 },  // 17 = JSN10
  { &DDRC, &PORTC, PC4 },  // 18 = JSN11
  { &DDRC, &PORTC, PC5 },  // 19 = JSN12
};

inline const PinInit* getPinInit(uint8_t pin) {
  return &pinMap[pin];
}

