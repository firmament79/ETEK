// TANK 2.0

#pragma once
#include <Arduino.h>

#ifdef __cplusplus
  #if __cplusplus >= 201103L
    #define CONSTEXPR constexpr
    #define NULLVALUE nullptr
  #else
    #define CONSTEXPR const
    #define NULLVALUE NULL
  #endif
#else
  #define CONSTEXPR const
  #define NULLVALUE NULL
#endif



typedef struct {
  volatile uint8_t* ddr;
  volatile uint8_t* port;
  uint8_t bit;
} PinInit;

// --- Arduino 腳位名稱定義（提供 digitalWrite 調用） ---

// LED
CONSTEXPR uint8_t LED = 22;   // PB7 MCU燈號

//EMO
CONSTEXPR uint8_t EMO = 85;   // PG5 急停開關

// JO (1~16)
CONSTEXPR uint8_t JO1  = 21;  // PB6
CONSTEXPR uint8_t JO2  = 20;  // PB5
CONSTEXPR uint8_t JO3  = 19;  // PB4
CONSTEXPR uint8_t JO4  = 14;  // PH6
CONSTEXPR uint8_t JO5  = 13;  // PH5
CONSTEXPR uint8_t JO6  = 12;  // PH4
CONSTEXPR uint8_t JO7  = 11;  // PH3
CONSTEXPR uint8_t JO8  = 10;  // PH2
CONSTEXPR uint8_t JO9  = 9;   // PH1
CONSTEXPR uint8_t JO10 = 8;   // PH0
CONSTEXPR uint8_t JO11 = 7;   // PE7
CONSTEXPR uint8_t JO12 = 6;   // PE6
CONSTEXPR uint8_t JO13 = 5;   // PE5
CONSTEXPR uint8_t JO14 = 4;   // PE4
CONSTEXPR uint8_t JO15 = 3;   // PE3
CONSTEXPR uint8_t JO16 = 2;   // PE2

// JSN (1~38)
CONSTEXPR uint8_t JSN1  = 60; // PA7
CONSTEXPR uint8_t JSN2  = 59; // PG2
CONSTEXPR uint8_t JSN3  = 58; // PJ6
CONSTEXPR uint8_t JSN4  = 57; // PJ5
CONSTEXPR uint8_t JSN5  = 56; // PJ4
CONSTEXPR uint8_t JSN6  = 55; // PJ3
CONSTEXPR uint8_t JSN7  = 54; // PJ2
CONSTEXPR uint8_t JSN8  = 53; // PJ1
CONSTEXPR uint8_t JSN9  = 52; // PJ0
CONSTEXPR uint8_t JSN10 = 51; // PC7
CONSTEXPR uint8_t JSN11 = 50; // PC6
CONSTEXPR uint8_t JSN12 = 49; // PC5
CONSTEXPR uint8_t JSN13 = 48; // PC4
CONSTEXPR uint8_t JSN14 = 47; // PC3
CONSTEXPR uint8_t JSN15 = 46; // PC2
CONSTEXPR uint8_t JSN16 = 45; // PC1
CONSTEXPR uint8_t JSN17 = 44; // PC0
CONSTEXPR uint8_t JSN18 = 43; // PG1
CONSTEXPR uint8_t JSN19 = 42; // PG0
CONSTEXPR uint8_t JSN20 = 41; // PD7
CONSTEXPR uint8_t JSN21 = 40; // PD6
CONSTEXPR uint8_t JSN22 = 39; // PD5
CONSTEXPR uint8_t JSN23 = 38; // PD4
CONSTEXPR uint8_t JSN24 = 37; // PD3
CONSTEXPR uint8_t JSN25 = 36; // PD2
CONSTEXPR uint8_t JSN26 = 35; // PD1 SDA
CONSTEXPR uint8_t JSN27 = 34; // PD0 SCL
CONSTEXPR uint8_t JSN28 = 33; // PL7
CONSTEXPR uint8_t JSN29 = 32; // PL6
CONSTEXPR uint8_t JSN30 = 31; // PL5
CONSTEXPR uint8_t JSN31 = 30; // PL4
CONSTEXPR uint8_t JSN32 = 29; // PL3
CONSTEXPR uint8_t JSN33 = 28; // PL2
CONSTEXPR uint8_t JSN34 = 27; // PL1
CONSTEXPR uint8_t JSN35 = 26; // PL0
CONSTEXPR uint8_t JSN36 = 25; // PG4
CONSTEXPR uint8_t JSN37 = 24; // PG3
CONSTEXPR uint8_t JSN38 = 23; // PH7

// JLN (光柵)
CONSTEXPR uint8_t JLN1 = 76;  // PF7
CONSTEXPR uint8_t JLN2 = 75;  // PF6

// JVN
CONSTEXPR uint8_t JVN1 = 74;  // PF5
CONSTEXPR uint8_t JVN2 = 73;  // PF4
CONSTEXPR uint8_t JVN3 = 72;  // PF3
CONSTEXPR uint8_t JVN4 = 71;  // PF2
CONSTEXPR uint8_t JVN5 = 70;  // PF1
CONSTEXPR uint8_t JVN6 = 69;  // PF0

// J1 (PK)
CONSTEXPR uint8_t J1_1 = 84;  // PK7
CONSTEXPR uint8_t J1_2 = 83;  // PK6
CONSTEXPR uint8_t J1_3 = 82;  // PK5
CONSTEXPR uint8_t J1_4 = 81;  // PK4
CONSTEXPR uint8_t J1_5 = 80;  // PK3
CONSTEXPR uint8_t J1_6 = 79;  // PK2
CONSTEXPR uint8_t J1_7 = 78;  // PK1
CONSTEXPR uint8_t J1_8 = 77;  // PK0

// J2 (PJ + PA)
CONSTEXPR uint8_t J2_1 = 68;  // PJ7
CONSTEXPR uint8_t J2_2 = 67;  // PA0
CONSTEXPR uint8_t J2_3 = 66;  // PA1
CONSTEXPR uint8_t J2_4 = 65;  // PA2
CONSTEXPR uint8_t J2_5 = 64;  // PA3
CONSTEXPR uint8_t J2_6 = 63;  // PA4
CONSTEXPR uint8_t J2_7 = 62;  // PA5
CONSTEXPR uint8_t J2_8 = 61;  // PA6


// --- 底層控制定義 ---

// --- 輸出腳位定義 ---
const PinInit OUTPUT_PINS[] PROGMEM = {
  { }, //0 (PE0)
  { }, //1 (PE1)
  { &DDRE, &PORTE, PE2 }, // JO16 = 2  (PE2)
  { &DDRE, &PORTE, PE3 }, // JO15 = 3  (PE3)
  { &DDRE, &PORTE, PE4 }, // JO14 = 4  (PE4)
  { &DDRE, &PORTE, PE5 }, // JO13 = 5  (PE5)
  { &DDRE, &PORTE, PE6 }, // JO12 = 6  (PE6)
  { &DDRE, &PORTE, PE7 }, // JO11 = 7  (PE7)
  { &DDRH, &PORTH, PH0 }, // JO10 = 8  (PH0)
  { &DDRH, &PORTH, PH1 }, // JO9  = 9  (PH1)
  { &DDRH, &PORTH, PH2 }, // JO8  = 10 (PH2)
  { &DDRH, &PORTH, PH3 }, // JO7  = 11 (PH3)
  { &DDRH, &PORTH, PH4 }, // JO6  = 12 (PH4)
  { &DDRH, &PORTH, PH5 }, // JO5  = 13 (PH5)
  { &DDRH, &PORTH, PH6 }, // JO4  = 14 (PH6)
  {}, // 15 (PB0)
  {}, // 16 (PB1)
  {}, // 17 (PB2)
  {}, // 18 (PB3)
  { &DDRB, &PORTB, PB4 }, // JO3  = 19 (PB4)
  { &DDRB, &PORTB, PB5 }, // JO2  = 20 (PB5)
  { &DDRB, &PORTB, PB6 }, // JO1  = 21 (PB6)
  { &DDRB, &PORTB, PB7 }, // LED = 22 (PB7)
  { },   // JSN38 = 23 (PH7)
  { },   // JSN37 = 24 (PG3)
  { },   // JSN36 = 25 (PG4)
  { },   // JSN35 = 26 (PL0)
  { },   // JSN34 = 27 (PL1)
  { },   // JSN33 = 28 (PL2)
  { },   // JSN32 = 29 (PL3)
  { },   // JSN31 = 30 (PL4)
  { },   // JSN30 = 31 (PL5)
  { },   // JSN29 = 32 (PL6)
  { },   // JSN28 = 33 (PL7)
  { },   // JSN27 = 34 (PD0)
  { },   // JSN26 = 35 (PD1)
  { },   // JSN25 = 36 (PD2)
  { },   // JSN24 = 37 (PD3)
  { },   // JSN23 = 38 (PD4)
  { },   // JSN22 = 39 (PD5)
  { },   // JSN21 = 40 (PD6)
  { },   // JSN20 = 41 (PD7)
  { },   // JSN19 = 42 (PG0)
  { },   // JSN18 = 43 (PG1)
  { },   // JSN17 = 44 (PC0)
  { },   // JSN16 = 45 (PC1)
  { },   // JSN15 = 46 (PC2)
  { },   // JSN14 = 47 (PC3)
  { },   // JSN13 = 48 (PC4)
  { },   // JSN12 = 49 (PC5)
  { },   // JSN11 = 50 (PC6)
  { },   // JSN10 = 51 (PC7)
  { },   // JSN9 = 52 (PJ0)
  { },   // JSN8 = 53 (PJ1)
  { },   // JSN7 = 54 (PJ2)
  { },   // JSN6 = 55 (PJ3)
  { },   // JSN5 = 56 (PJ4)
  { },   // JSN4 = 57 (PJ5)
  { },   // JSN3 = 58 (PJ6)
  { },   // JSN2 = 59 (PG2)
  { },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61
  { },   // J2_7 = 62
  { },   // J2_6 = 63
  { },   // J2_5 = 64
  { },   // J2_4 = 65
  { },   // J2_3 = 66
  { },   // J2_2 = 67
  { },   // J2_1 = 68
  { },   // JVN6 = 69 (PF0)
  { },   // JVN5 = 70 (PF1)
  { },   // JVN4 = 71 (PF2)
  { },   // JVN3 = 72 (PF3)
  { },   // JVN2 = 73 (PF4)
  { },   // JVN1 = 74 (PF5)
  { },   // JLN2 = 75 (PF6)
  { },   // JLN1 = 76 (PF7)
  { },   // J1_8 = 77 (PK0)
  { },   // J1_7 = 78 (PK1)
  { },   // J1_6 = 79 (PK2)
  { },   // J1_5 = 80 (PK3)
  { },   // J1_4 = 81 (PK4)
  { },   // J1_3 = 82 (PK5)
  { },   // J1_2 = 83 (PK6)
  { },   // J1_1 = 84 (PK7)
  { },   // EMO = 85 (PG5)
};


// --- 輸入+上拉腳位定義 ---
const PinInit INPUT_PULLUP_PINS[] PROGMEM = {
  { }, //0 (PE0)
  { }, //1 (PE1)
  { }, // JO16 = 2  (PE2)
  { }, // JO15 = 3  (PE3)
  { }, // JO14 = 4  (PE4)
  { }, // JO13 = 5  (PE5)
  { }, // JO12 = 6  (PE6)
  { }, // JO11 = 7  (PE7)
  { }, // JO10 = 8  (PH0)
  { }, // JO9  = 9  (PH1)
  { }, // JO8  = 10 (PH2)
  { }, // JO7  = 11 (PH3)
  { }, // JO6  = 12 (PH4)
  { }, // JO5  = 13 (PH5)
  { }, // JO4  = 14 (PH6)
  { }, // 15 (PB0)
  { }, // 16 (PB1)
  { }, // 17 (PB2)
  { }, // 18 (PB3)
  { }, // JO3  = 19 (PB4)
  { }, // JO2  = 20 (PB5)
  { }, // JO1  = 21 (PB3)
  { }, // LED = 22 (PB7)
  { &DDRH, &PORTH, PH7 },   // JSN38 = 23 (PH7)
  { &DDRG, &PORTG, PG3 },   // JSN37 = 24 (PG3)
  { &DDRG, &PORTG, PG4 },   // JSN36 = 25 (PG4)
  { &DDRL, &PORTL, PL0 },   // JSN35 = 26 (PL0)
  { &DDRL, &PORTL, PL1 },   // JSN34 = 27 (PL1)
  { &DDRL, &PORTL, PL2 },   // JSN33 = 28 (PL2)
  { &DDRL, &PORTL, PL3 },   // JSN32 = 29 (PL3)
  { &DDRL, &PORTL, PL4 },   // JSN31 = 30 (PL4)
  { &DDRL, &PORTL, PL5 },   // JSN30 = 31 (PL5)
  { &DDRL, &PORTL, PL6 },   // JSN29 = 32 (PL6)
  { &DDRL, &PORTL, PL7 },   // JSN28 = 33 (PL7)
  { &DDRD, &PORTD, PD0 },   // JSN27 = 34 (PD0)
  { &DDRD, &PORTD, PD1 },   // JSN26 = 35 (PD1)
  { &DDRD, &PORTD, PD2 },   // JSN25 = 36 (PD2)
  { &DDRD, &PORTD, PD3 },   // JSN24 = 37 (PD3)
  { &DDRD, &PORTD, PD4 },   // JSN23 = 38 (PD4)
  { &DDRD, &PORTD, PD5 },   // JSN22 = 39 (PD5)
  { &DDRD, &PORTD, PD6 },   // JSN21 = 40 (PD6)
  { &DDRD, &PORTD, PD7 },   // JSN20 = 41 (PD7)
  { &DDRG, &PORTG, PG0 },   // JSN19 = 42 (PG0)
  { &DDRG, &PORTG, PG1 },   // JSN18 = 43 (PG1)
  { &DDRC, &PORTC, PC0 },   // JSN17 = 44 (PC0)
  { &DDRC, &PORTC, PC1 },   // JSN16 = 45 (PC1)
  { &DDRC, &PORTC, PC2 },   // JSN15 = 46 (PC2)
  { &DDRC, &PORTC, PC3 },   // JSN14 = 47 (PC3)
  { &DDRC, &PORTC, PC4 },   // JSN13 = 48 (PC4)
  { &DDRC, &PORTC, PC5 },   // JSN12 = 49 (PC5)
  { &DDRC, &PORTC, PC6 },   // JSN11 = 50 (PC6)
  { &DDRC, &PORTC, PC7 },   // JSN10 = 51 (PC7)
  { &DDRJ, &PORTJ, PJ0 },   // JSN9 = 52 (PJ0)
  { &DDRJ, &PORTJ, PJ1 },   // JSN8 = 53 (PJ1)
  { &DDRJ, &PORTJ, PJ2 },   // JSN7 = 54 (PJ2)
  { &DDRJ, &PORTJ, PJ3 },   // JSN6 = 55 (PJ3)
  { &DDRJ, &PORTJ, PJ4 },   // JSN5 = 56 (PJ4)
  { &DDRJ, &PORTJ, PJ5 },   // JSN4 = 57 (PJ5)
  { &DDRJ, &PORTJ, PJ6 },   // JSN3 = 58 (PJ6)
  { &DDRG, &PORTG, PG2 },   // JSN2 = 59 (PG2)
  { &DDRA, &PORTA, PA7 },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61 (PA6)
  { },   // J2_7 = 62 (PA5)
  { },   // J2_6 = 63 (PA4)
  { },   // J2_5 = 64 (PA3)
  { },   // J2_4 = 65 (PA2)
  { },   // J2_3 = 66 (PA1)
  { },   // J2_2 = 67 (PA0)
  { },   // J2_1 = 68 (PJ7)
  { &DDRF, &PORTF, PF0 },   // JVN6 = 69 (PF0)
  { &DDRF, &PORTF, PF1 },   // JVN5 = 70 (PF1)
  { &DDRF, &PORTF, PF2 },   // JVN4 = 71 (PF2)
  { &DDRF, &PORTF, PF3 },   // JVN3 = 72 (PF3)
  { &DDRF, &PORTF, PF4 },   // JVN2 = 73 (PF4)
  { &DDRF, &PORTF, PF5 },   // JVN1 = 74 (PF5)
  { &DDRF, &PORTF, PF6 },   // JLN2 = 75 (PF6)
  { &DDRF, &PORTF, PF7 },   // JLN1 = 76 (PF7)
  { },   // J1_8 = 77 (PK0)
  { },   // J1_7 = 78 (PK1)
  { },   // J1_6 = 79 (PK2)
  { },   // J1_5 = 80 (PK3)
  { },   // J1_4 = 81 (PK4)
  { },   // J1_3 = 82 (PK5)
  { },   // J1_2 = 83 (PK6)
  { },   // J1_1 = 84 (PK7)
  { &DDRG, &PORTG, PG5 },   // EMO = 85 (PG5)
};

// --- 輸入腳位定義（無上拉） ---
const PinInit INPUT_PINS[] PROGMEM = {
  { }, //0 (PE0)
  { }, //1 (PE1)
  { }, // JO16 = 2  (PE2)
  { }, // JO15 = 3  (PE3)
  { }, // JO14 = 4  (PE4)
  { }, // JO13 = 5  (PE5)
  { }, // JO12 = 6  (PE6)
  { }, // JO11 = 7  (PE7)
  { }, // JO10 = 8  (PH0)
  { }, // JO9  = 9  (PH1)
  { }, // JO8  = 10 (PH2)
  { }, // JO7  = 11 (PH3)
  { }, // JO6  = 12 (PH4)
  { }, // JO5  = 13 (PH5)
  { }, // JO4  = 14 (PH6)
  { }, // 15 (PB0)
  { }, // 16 (PB1)
  { }, // 17 (PB2)
  { }, // 18 (PB3)
  { }, // JO3  = 19 (PB4)
  { }, // JO2  = 20 (PB5)
  { }, // JO1  = 21 (PB3)
  { },   // LED = 22 (PB7)
  { },   // JSN38 = 23 (PH7)
  { },   // JSN37 = 24 (PG3)
  { },   // JSN36 = 25 (PG4)
  { },   // JSN35 = 26 (PL0)
  { },   // JSN34 = 27 (PL1)
  { },   // JSN33 = 28 (PL2)
  { },   // JSN32 = 29 (PL3)
  { },   // JSN31 = 30 (PL4)
  { },   // JSN30 = 31 (PL5)
  { },   // JSN29 = 32 (PL6)
  { },   // JSN28 = 33 (PL7)
  { },   // JSN27 = 34 (PD0)
  { },   // JSN26 = 35 (PD1)
  { },   // JSN25 = 36 (PD2)
  { },   // JSN24 = 37 (PD3)
  { },   // JSN23 = 38 (PD4)
  { },   // JSN22 = 39 (PD5)
  { },   // JSN21 = 40 (PD6)
  { },   // JSN20 = 41 (PD7)
  { },   // JSN19 = 42 (PG0)
  { },   // JSN18 = 43 (PG1)
  { },   // JSN17 = 44 (PC0)
  { },   // JSN16 = 45 (PC1)
  { },   // JSN15 = 46 (PC2)
  { },   // JSN14 = 47 (PC3)
  { },   // JSN13 = 48 (PC4)
  { },   // JSN12 = 49 (PC5)
  { },   // JSN11 = 50 (PC6)
  { },   // JSN10 = 51 (PC7)
  { },   // JSN9 = 52 (PJ0)
  { },   // JSN8 = 53 (PJ1)
  { },   // JSN7 = 54 (PJ2)
  { },   // JSN6 = 55 (PJ3)
  { },   // JSN5 = 56 (PJ4)
  { },   // JSN4 = 57 (PJ5)
  { },   // JSN3 = 58 (PJ6)
  { },   // JSN2 = 59 (PG2)
  { },   // JSN1 = 60 (PA7)
  { },   // J2_8 = 61 (PA6)
  { },   // J2_7 = 62 (PA5)
  { },   // J2_6 = 63 (PA4)
  { },   // J2_5 = 64 (PA3)
  { },   // J2_4 = 65 (PA2)
  { },   // J2_3 = 66 (PA1)
  { },   // J2_2 = 67 (PA0)
  { },   // J2_1 = 68 (PJ7)
  { },   // JVN6 = 69 (PF0)
  { },   // JVN5 = 70 (PF1)
  { },   // JVN4 = 71 (PF2)
  { },   // JVN3 = 72 (PF3)
  { },   // JVN2 = 73 (PF4)
  { },   // JVN1 = 74 (PF5)
  { },   // JLN2 = 75 (PF6)
  { },   // JLN1 = 76 (PF7)
  { },   // J1_8 = 77 (PK0)
  { },   // J1_7 = 78 (PK1)
  { },   // J1_6 = 79 (PK2)
  { },   // J1_5 = 80 (PK3)
  { },   // J1_4 = 81 (PK4)
  { },   // J1_3 = 82 (PK5)
  { },   // J1_2 = 83 (PK6)
  { },   // J1_1 = 84 (PK7)
  { },   // EMO = 85 (PG5)
};

//預留用的
  // { &DDRA, &PORTA, PA6 },   // J2_8 = 61 (PA6)
  // { &DDRA, &PORTA, PA5 },   // J2_7 = 62 (PA5)
  // { &DDRA, &PORTA, PA4 },   // J2_6 = 63 (PA4)
  // { &DDRA, &PORTA, PA3 },   // J2_5 = 64 (PA3)
  // { &DDRA, &PORTA, PA2 },   // J2_4 = 65 (PA2)
  // { &DDRA, &PORTA, PA1 },   // J2_3 = 66 (PA1)
  // { &DDRA, &PORTA, PA0 },   // J2_2 = 67 (PA0)
  // { &DDRJ, &PORTJ, PJ7 },   // J2_1 = 68 (PJ7)

  // { &DDRK, &PORTK, PK0 },   // J1_8 = 77 (PK0)
  // { &DDRK, &PORTK, PK1 },   // J1_7 = 78 (PK1)
  // { &DDRK, &PORTK, PK2 },   // J1_6 = 79 (PK2)
  // { &DDRK, &PORTK, PK3 },   // J1_5 = 80 (PK3)
  // { &DDRK, &PORTK, PK4 },   // J1_4 = 81 (PK4)
  // { &DDRK, &PORTK, PK5 },   // J1_3 = 82 (PK5)
  // { &DDRK, &PORTK, PK6 },   // J1_2 = 83 (PK6)
  // { &DDRK, &PORTK, PK7 },   // J1_1 = 84 (PK7)



const PinInit pinMap[] PROGMEM = {
  { }, //0 (PE0)
  { }, //1 (PE1)
  { &DDRE, &PORTE, PE2 }, // JO16 = 2  (PE2)
  { &DDRE, &PORTE, PE3 }, // JO15 = 3  (PE3)
  { &DDRE, &PORTE, PE4 }, // JO14 = 4  (PE4)
  { &DDRE, &PORTE, PE5 }, // JO13 = 5  (PE5)
  { &DDRE, &PORTE, PE6 }, // JO12 = 6  (PE6)
  { &DDRE, &PORTE, PE7 }, // JO11 = 7  (PE7)
  { &DDRE, &PORTE, PE0 }, // JO10 = 8  (PH0)
  { &DDRH, &PORTH, PH1 }, // JO9  = 9  (PH1)
  { &DDRH, &PORTH, PH2 }, // JO8  = 10 (PH2)
  { &DDRH, &PORTH, PH3 }, // JO7  = 11 (PH3)
  { &DDRH, &PORTH, PH4 }, // JO6  = 12 (PH4)
  { &DDRH, &PORTH, PH5 }, // JO5  = 13 (PH5)
  { &DDRH, &PORTH, PH6 }, // JO4  = 14 (PH6)
  { }, // 15 (PB0)
  { }, // 16 (PB1)
  { }, // 17 (PB2)
  { }, // 18 (PB3)
  { &DDRB, &PORTB, PB4 }, // JO3  = 19 (PB4)
  { &DDRB, &PORTB, PB5 }, // JO2  = 20 (PB5)
  { &DDRB, &PORTB, PB6 }, // JO1  = 21 (PB6)
  { &DDRB, &PORTB, PB7 },   // LED = 22 (PB7)
  { &DDRH, &PORTH, PH7 },   // JSN38 = 23 (PH7)
  { &DDRG, &PORTG, PG3 },   // JSN37 = 24 (PG3)
  { &DDRG, &PORTG, PG4 },   // JSN36 = 25 (PG4)
  { &DDRL, &PORTL, PL0 },   // JSN35 = 26 (PL0)
  { &DDRL, &PORTL, PL1 },   // JSN34 = 27 (PL1)
  { &DDRL, &PORTL, PL2 },   // JSN33 = 28 (PL2)
  { &DDRL, &PORTL, PL3 },   // JSN32 = 29 (PL3)
  { &DDRL, &PORTL, PL4 },   // JSN31 = 30 (PL4)
  { &DDRL, &PORTL, PL5 },   // JSN30 = 31 (PL5)
  { &DDRL, &PORTL, PL6 },   // JSN29 = 32 (PL6)
  { &DDRL, &PORTL, PL7 },   // JSN28 = 33 (PL7)
  { &DDRD, &PORTD, PD0 },   // JSN27 = 34 (PD0)
  { &DDRD, &PORTD, PD1 },   // JSN26 = 35 (PD1)
  { &DDRD, &PORTD, PD2 },   // JSN25 = 36 (PD2)
  { &DDRD, &PORTD, PD3 },   // JSN24 = 37 (PD3)
  { &DDRD, &PORTD, PD4 },   // JSN23 = 38 (PD4)
  { &DDRD, &PORTD, PD5 },   // JSN22 = 39 (PD5)
  { &DDRD, &PORTD, PD6 },   // JSN21 = 40 (PD6)
  { &DDRD, &PORTD, PD7 },   // JSN20 = 41 (PD7)
  { &DDRG, &PORTG, PG0 },   // JSN19 = 42 (PG0)
  { &DDRG, &PORTG, PG1 },   // JSN18 = 43 (PG1)
  { &DDRC, &PORTC, PC0 },   // JSN17 = 44 (PC0)
  { &DDRC, &PORTC, PC1 },   // JSN16 = 45 (PC1)
  { &DDRC, &PORTC, PC2 },   // JSN15 = 46 (PC2)
  { &DDRC, &PORTC, PC3 },   // JSN14 = 47 (PC3)
  { &DDRC, &PORTC, PC4 },   // JSN13 = 48 (PC4)
  { &DDRC, &PORTC, PC5 },   // JSN12 = 49 (PC5)
  { &DDRC, &PORTC, PC6 },   // JSN11 = 50 (PC6)
  { &DDRC, &PORTC, PC7 },   // JSN10 = 51 (PC7)
  { &DDRJ, &PORTJ, PJ0 },   // JSN9 = 52 (PJ0)
  { &DDRJ, &PORTJ, PJ1 },   // JSN8 = 53 (PJ1)
  { &DDRJ, &PORTJ, PJ2 },   // JSN7 = 54 (PJ2)
  { &DDRJ, &PORTJ, PJ3 },   // JSN6 = 55 (PJ3)
  { &DDRJ, &PORTJ, PJ4 },   // JSN5 = 56 (PJ4)
  { &DDRJ, &PORTJ, PJ5 },   // JSN4 = 57 (PJ5)
  { &DDRJ, &PORTJ, PJ6 },   // JSN3 = 58 (PJ6)
  { &DDRG, &PORTG, PG2 },   // JSN2 = 59 (PG2)
  { &DDRA, &PORTA, PA7 },   // JSN1 = 60 (PA7)
  { &DDRA, &PORTA, PA6 },   // J2_8 = 61 (PA6)
  { &DDRA, &PORTA, PA5 },   // J2_7 = 62 (PA5)
  { &DDRA, &PORTA, PA4 },   // J2_6 = 63 (PA4)
  { &DDRA, &PORTA, PA3 },   // J2_5 = 64 (PA3)
  { &DDRA, &PORTA, PA2 },   // J2_4 = 65 (PA2)
  { &DDRA, &PORTA, PA1 },   // J2_3 = 66 (PA1)
  { &DDRA, &PORTA, PA0 },   // J2_2 = 67 (PA0)
  { &DDRJ, &PORTJ, PJ7 },   // J2_1 = 68 (PJ7)
  { &DDRF, &PORTF, PF0 },   // JVN6 = 69 (PF0)
  { &DDRF, &PORTF, PF1 },   // JVN5 = 70 (PF1)
  { &DDRF, &PORTF, PF2 },   // JVN4 = 71 (PF2)
  { &DDRF, &PORTF, PF3 },   // JVN3 = 72 (PF3)
  { &DDRF, &PORTF, PF4 },   // JVN2 = 73 (PF4)
  { &DDRF, &PORTF, PF5 },   // JVN1 = 74 (PF5)
  { &DDRF, &PORTF, PF6 },   // JLN2 = 75 (PF6)
  { &DDRF, &PORTF, PF7 },   // JLN1 = 76 (PF7)
  { &DDRK, &PORTK, PK0 },   // J1_8 = 77 (PK0)
  { &DDRK, &PORTK, PK1 },   // J1_7 = 78 (PK1)
  { &DDRK, &PORTK, PK2 },   // J1_6 = 79 (PK2)
  { &DDRK, &PORTK, PK3 },   // J1_5 = 80 (PK3)
  { &DDRK, &PORTK, PK4 },   // J1_4 = 81 (PK4)
  { &DDRK, &PORTK, PK5 },   // J1_3 = 82 (PK5)
  { &DDRK, &PORTK, PK6 },   // J1_2 = 83 (PK6)
  { &DDRK, &PORTK, PK7 },   // J1_1 = 84 (PK7)
  { &DDRG, &PORTG, PG5 },   // EMO = 85 (PG5)
};



inline const PinInit* getPinInit(uint8_t pin) {
  return &pinMap[pin];
}
