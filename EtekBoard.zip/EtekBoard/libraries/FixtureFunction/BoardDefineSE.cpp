#include "Arduino.h"
#include "BoardDefineSE.h"



BoardDefineSE::BoardDefineSE()
{
    // #if DefaultBoard == 1
    #if defined(__AVR_ATmega328P__)
        pinMode(LED, OUTPUT);
        pinMode(JO1, OUTPUT);
        pinMode(JO2, OUTPUT);
        pinMode(JO3, OUTPUT);
        pinMode(JO4, OUTPUT);
        pinMode(JO5, OUTPUT);
        pinMode(JO6, OUTPUT);
        pinMode(JO7, OUTPUT);
        pinMode(JO8, OUTPUT);
        pinMode(JO9, OUTPUT);
        pinMode(JO10, OUTPUT);    
        pinMode(JSN1, INPUT_PULLUP);
        pinMode(JSN2, INPUT_PULLUP);
        pinMode(JSN3, INPUT_PULLUP);
        pinMode(JSN4, INPUT_PULLUP);
        pinMode(JSN5, INPUT_PULLUP);
        pinMode(JSN6, INPUT_PULLUP);
        pinMode(JSN7, INPUT_PULLUP);
    
    #elif defined(__AVR_ATmega328PB__)  
        pinMode(LED, OUTPUT);
        pinMode(JO1, OUTPUT);
        pinMode(JO2, OUTPUT);
        pinMode(JO3, OUTPUT);
        pinMode(JO4, OUTPUT);
        pinMode(JO5, OUTPUT); 
        pinMode(JO6, OUTPUT); 
        pinMode(JO7, OUTPUT); 
        pinMode(JSN1, INPUT_PULLUP);
        pinMode(JSN2, INPUT_PULLUP);
        pinMode(JSN3, INPUT_PULLUP);
        pinMode(JSN4, INPUT_PULLUP);
        pinMode(JSN5, INPUT_PULLUP);
        pinMode(JSN6, INPUT_PULLUP);
        pinMode(JSN7, INPUT_PULLUP);
        pinMode(JSN8, INPUT_PULLUP);
        pinMode(JSN9, INPUT_PULLUP);
        pinMode(JSN10, INPUT_PULLUP);
        pinMode(JSN11, INPUT_PULLUP);
        pinMode(JSN12, INPUT_PULLUP);  

    #elif defined(__AVR_ATmega2560__)
        pinMode(LED, OUTPUT);
        pinMode(JO1, OUTPUT);
        pinMode(JO2, OUTPUT);
        pinMode(JO3, OUTPUT);
        pinMode(JO4, OUTPUT);
        pinMode(JO5, OUTPUT);
        pinMode(JO6, OUTPUT);
        pinMode(JO7, OUTPUT);
        pinMode(JO8, OUTPUT);
        pinMode(JO9, OUTPUT);
        pinMode(JO10, OUTPUT);    
        pinMode(JO11, OUTPUT);    
        pinMode(JO12, OUTPUT);    
        pinMode(JO13, OUTPUT);    
        pinMode(JO14, OUTPUT);    
        pinMode(JO15, OUTPUT);  
        pinMode(JO16, OUTPUT);   
        pinMode(EMO, INPUT_PULLUP);
        pinMode(JSN1, INPUT_PULLUP);
        pinMode(JSN2, INPUT_PULLUP);
        pinMode(JSN3, INPUT_PULLUP);
        pinMode(JSN4, INPUT_PULLUP);
        pinMode(JSN5, INPUT_PULLUP);
        pinMode(JSN6, INPUT_PULLUP);
        pinMode(JSN7, INPUT_PULLUP);
        pinMode(JSN8, INPUT_PULLUP);
        pinMode(JSN9, INPUT_PULLUP);
        pinMode(JSN10, INPUT_PULLUP);
        pinMode(JSN11, INPUT_PULLUP);
        pinMode(JSN12, INPUT_PULLUP);   
        pinMode(JSN13, INPUT_PULLUP);  
        pinMode(JSN14, INPUT_PULLUP);  
        pinMode(JSN15, INPUT_PULLUP);  
        pinMode(JSN16, INPUT_PULLUP);  
        pinMode(JSN17, INPUT_PULLUP);  
        pinMode(JSN18, INPUT_PULLUP);  
        pinMode(JSN19, INPUT_PULLUP);  
        pinMode(JSN20, INPUT_PULLUP);  
        pinMode(JSN21, INPUT_PULLUP);  
        pinMode(JSN22, INPUT_PULLUP);  
        pinMode(JSN23, INPUT_PULLUP);  
        pinMode(JSN24, INPUT_PULLUP);  
        pinMode(JSN25, INPUT_PULLUP);  
        pinMode(JSN26, INPUT_PULLUP);  
        pinMode(JSN27, INPUT_PULLUP);  
        pinMode(JSN28, INPUT_PULLUP);  
        pinMode(JSN29, INPUT_PULLUP);  
        pinMode(JSN30, INPUT_PULLUP);  
        pinMode(JSN31, INPUT_PULLUP);  
        pinMode(JSN32, INPUT_PULLUP);  
        pinMode(JSN33, INPUT_PULLUP);  
        pinMode(JSN34, INPUT_PULLUP);  
        pinMode(JSN35, INPUT_PULLUP);  
        pinMode(JSN36, INPUT_PULLUP);  
        pinMode(JSN37, INPUT_PULLUP);  
        pinMode(JSN38, INPUT_PULLUP);  
        pinMode(JLN1, INPUT_PULLUP);  
        pinMode(JLN2, INPUT_PULLUP);  
        pinMode(JVN1, INPUT_PULLUP);  
        pinMode(JVN2, INPUT_PULLUP);  
        pinMode(JVN3, INPUT_PULLUP);  
        pinMode(JVN4, INPUT_PULLUP);  
        pinMode(JVN5, INPUT_PULLUP);  
        pinMode(JVN6, INPUT_PULLUP); 
    #else
        #error CPP錯 (SE版)
    #endif

}


// BoardDefine::PINMODE()
// // PinMode::PinMode()
// {   
//     #if defined(_TANK_V_2_0_STD_)
//     // #if defined(__AVR_ATmega328P__)
//         pinMode(LED, OUTPUT);
//         pinMode(JO1, OUTPUT);
//         pinMode(JO2, OUTPUT);
//         pinMode(JO3, OUTPUT);
//         pinMode(JO4, OUTPUT);
//         pinMode(JO5, OUTPUT); 
//         pinMode(JSN1, INPUT_PULLUP);
//         pinMode(JSN2, INPUT_PULLUP);
//         pinMode(JSN3, INPUT_PULLUP);
//         pinMode(JSN4, INPUT_PULLUP);
//         pinMode(JSN5, INPUT_PULLUP);
//         pinMode(JSN6, INPUT_PULLUP);
//         pinMode(JSN7, INPUT_PULLUP);
//         pinMode(JSN8, INPUT_PULLUP);
//         pinMode(JSN9, INPUT_PULLUP);
//         pinMode(JSN10, INPUT_PULLUP);
//         pinMode(JSN11, INPUT_PULLUP);
//         pinMode(JSN12, INPUT_PULLUP);

//     #elif defined(_TANK_V_2_0_STD_)
//     // #elif (defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__))
//         pinMode(LED, OUTPUT);
//         pinMode(JO1, OUTPUT);
//         pinMode(JO2, OUTPUT);
//         pinMode(JO3, OUTPUT);
//         pinMode(JO4, OUTPUT);
//         pinMode(JO5, OUTPUT);
//         pinMode(JO6, OUTPUT);
//         pinMode(JO7, OUTPUT);
//         pinMode(JO8, OUTPUT);
//         pinMode(JO9, OUTPUT);
//         pinMode(JO10, OUTPUT);    
//         pinMode(JO11, OUTPUT);    
//         pinMode(JO12, OUTPUT);    
//         pinMode(JO13, OUTPUT);    
//         pinMode(JO14, OUTPUT);    
//         pinMode(JO15, OUTPUT);  
//         pinMode(JO16, OUTPUT);   
//         pinMode(EMO, INPUT_PULLUP);
//         pinMode(JSN1, INPUT_PULLUP);
//         pinMode(JSN2, INPUT_PULLUP);
//         pinMode(JSN3, INPUT_PULLUP);
//         pinMode(JSN4, INPUT_PULLUP);
//         pinMode(JSN5, INPUT_PULLUP);
//         pinMode(JSN6, INPUT_PULLUP);
//         pinMode(JSN7, INPUT_PULLUP);
//         pinMode(JSN8, INPUT_PULLUP);
//         pinMode(JSN9, INPUT_PULLUP);
//         pinMode(JSN10, INPUT_PULLUP);
//         pinMode(JSN11, INPUT_PULLUP);
//         pinMode(JSN12, INPUT_PULLUP);   
//         pinMode(JSN13, INPUT_PULLUP);  
//         pinMode(JSN14, INPUT_PULLUP);  
//         pinMode(JSN15, INPUT_PULLUP);  
//         pinMode(JSN16, INPUT_PULLUP);  
//         pinMode(JSN17, INPUT_PULLUP);  
//         pinMode(JSN18, INPUT_PULLUP);  
//         pinMode(JSN19, INPUT_PULLUP);  
//         pinMode(JSN20, INPUT_PULLUP);  
//         pinMode(JSN21, INPUT_PULLUP);  
//         pinMode(JSN22, INPUT_PULLUP);  
//         pinMode(JSN23, INPUT_PULLUP);  
//         pinMode(JSN24, INPUT_PULLUP);  
//         pinMode(JSN25, INPUT_PULLUP);  
//         pinMode(JSN26, INPUT_PULLUP);  
//         pinMode(JSN27, INPUT_PULLUP);  
//         pinMode(JSN28, INPUT_PULLUP);  
//         pinMode(JSN29, INPUT_PULLUP);  
//         pinMode(JSN30, INPUT_PULLUP);  
//         pinMode(JSN31, INPUT_PULLUP);  
//         pinMode(JSN32, INPUT_PULLUP);  
//         pinMode(JSN33, INPUT_PULLUP);  
//         pinMode(JSN34, INPUT_PULLUP);  
//         pinMode(JSN35, INPUT_PULLUP);  
//         pinMode(JSN36, INPUT_PULLUP);  
//         pinMode(JSN37, INPUT_PULLUP);  
//         pinMode(JSN38, INPUT_PULLUP);  
//         pinMode(JLN1, INPUT_PULLUP);  
//         pinMode(JLN2, INPUT_PULLUP);  
//         pinMode(JVN1, INPUT_PULLUP);  
//         pinMode(JVN2, INPUT_PULLUP);  
//         pinMode(JVN3, INPUT_PULLUP);  
//         pinMode(JVN4, INPUT_PULLUP);  
//         pinMode(JVN5, INPUT_PULLUP);  
//         pinMode(JVN6, INPUT_PULLUP);  
//         // #error cpp tank2.0

//     #else
//         #error cpp選錯板子辣笨蛋!!!
//     #endif
// }

// BoardDefine::PINMODESE()
// {   
//     #if defined(_MINI_V_2_4_SE_)
//     // #if defined(__AVR_ATmega328P__)
//         pinMode(LED, OUTPUT);
//         pinMode(JO1, OUTPUT);
//         pinMode(JO2, OUTPUT);
//         pinMode(JO3, OUTPUT);
//         pinMode(JO4, OUTPUT);
//         pinMode(JO5, OUTPUT);
//         pinMode(JO6, OUTPUT);
//         pinMode(JO7, OUTPUT);
//         pinMode(JO8, OUTPUT);
//         pinMode(JO9, OUTPUT);
//         pinMode(JO10, OUTPUT);    
//         pinMode(JSN1, INPUT_PULLUP);
//         pinMode(JSN2, INPUT_PULLUP);
//         pinMode(JSN3, INPUT_PULLUP);
//         pinMode(JSN4, INPUT_PULLUP);
//         pinMode(JSN5, INPUT_PULLUP);
//         pinMode(JSN6, INPUT_PULLUP);
//         pinMode(JSN7, INPUT_PULLUP);

//     #elif (defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__))
//         pinMode(LED, OUTPUT);
//         pinMode(JO1, OUTPUT);
//         pinMode(JO2, OUTPUT);
//         pinMode(JO3, OUTPUT);
//         pinMode(JO4, OUTPUT);
//         pinMode(JO5, OUTPUT);
//         pinMode(JO6, OUTPUT);
//         pinMode(JO7, OUTPUT);
//         pinMode(JO8, OUTPUT);
//         pinMode(JO9, OUTPUT);
//         pinMode(JO10, OUTPUT);    
//         pinMode(JO11, OUTPUT);    
//         pinMode(JO12, OUTPUT);    
//         pinMode(JO13, OUTPUT);    
//         pinMode(JO14, OUTPUT);    
//         pinMode(JO15, OUTPUT);  
//         pinMode(JO16, OUTPUT);   
//         pinMode(EMO, INPUT_PULLUP);
//         pinMode(JSN1, INPUT_PULLUP);
//         pinMode(JSN2, INPUT_PULLUP);
//         pinMode(JSN3, INPUT_PULLUP);
//         pinMode(JSN4, INPUT_PULLUP);
//         pinMode(JSN5, INPUT_PULLUP);
//         pinMode(JSN6, INPUT_PULLUP);
//         pinMode(JSN7, INPUT_PULLUP);
//         pinMode(JSN8, INPUT_PULLUP);
//         pinMode(JSN9, INPUT_PULLUP);
//         pinMode(JSN10, INPUT_PULLUP);
//         pinMode(JSN11, INPUT_PULLUP);
//         pinMode(JSN12, INPUT_PULLUP);   
//         pinMode(JSN13, INPUT_PULLUP);  
//         pinMode(JSN14, INPUT_PULLUP);  
//         pinMode(JSN15, INPUT_PULLUP);  
//         pinMode(JSN16, INPUT_PULLUP);  
//         pinMode(JSN17, INPUT_PULLUP);  
//         pinMode(JSN18, INPUT_PULLUP);  
//         pinMode(JSN19, INPUT_PULLUP);  
//         pinMode(JSN20, INPUT_PULLUP);  
//         pinMode(JSN21, INPUT_PULLUP);  
//         pinMode(JSN22, INPUT_PULLUP);  
//         pinMode(JSN23, INPUT_PULLUP);  
//         pinMode(JSN24, INPUT_PULLUP);  
//         pinMode(JSN25, INPUT_PULLUP);  
//         pinMode(JSN26, INPUT_PULLUP);  
//         pinMode(JSN27, INPUT_PULLUP);  
//         pinMode(JSN28, INPUT_PULLUP);  
//         pinMode(JSN29, INPUT_PULLUP);  
//         pinMode(JSN30, INPUT_PULLUP);  
//         pinMode(JSN31, INPUT_PULLUP);  
//         pinMode(JSN32, INPUT_PULLUP);  
//         pinMode(JSN33, INPUT_PULLUP);  
//         pinMode(JSN34, INPUT_PULLUP);  
//         pinMode(JSN35, INPUT_PULLUP);  
//         pinMode(JSN36, INPUT_PULLUP);  
//         pinMode(JSN37, INPUT_PULLUP);  
//         pinMode(JSN38, INPUT_PULLUP);  
//         pinMode(JLN1, INPUT_PULLUP);  
//         pinMode(JLN2, INPUT_PULLUP);  
//         pinMode(JVN1, INPUT_PULLUP);  
//         pinMode(JVN2, INPUT_PULLUP);  
//         pinMode(JVN3, INPUT_PULLUP);  
//         pinMode(JVN4, INPUT_PULLUP);  
//         pinMode(JVN5, INPUT_PULLUP);  
//         pinMode(JVN6, INPUT_PULLUP);  
//         // #error cpp tank2.0

//     #else
//         #error cpp選錯板子辣笨蛋!!!
//     #endif
// }


