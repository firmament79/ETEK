// Release Date: 2023.07.28
// Version: 1.0.0.0

#ifndef FixtureFunction_h
#define FixtureFunction_h



#include "Arduino.h"
// #include "BoardDefine.h"

class FixtureFunction
{
    public:
        #define isIn isInput()
        #define isOut isOutput()
        #define ON turnOn()
        #define OFF turnOff()
        #define checkLow checkNPN()
        #define ckeckHigh checkPNP()
        #define debounce sw_debounce()

        FixtureFunction(int pin);
        void isInput();
        void isOutput();
        void turnOn();
        void turnOff();
        boolean checkNPN();
        boolean checkPNP();
        void sw_debounce();

    private:
        int _pin;
        
};





#endif