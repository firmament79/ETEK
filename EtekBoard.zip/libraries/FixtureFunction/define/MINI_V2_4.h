#ifndef MINI_V2_4_h
#define MINI_V2_4_h

    #define LED 13
    #define JO1 2
    #define JO2 3
    #define JO3 4
    #define JO4 5
    #define JO5 6
    #define JSN1 7
    #define JSN2 8
    #define JSN3 9
    #define JSN4 10
    #define JSN5 11
    #define JSN6 12
    #define JSN7 14
    #define JSN8 15
    #define JSN9 16
    #define JSN10 17
    #define JSN11 18
    #define JSN12 19



#endif