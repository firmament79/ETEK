#include "Arduino.h"
#include "MINI_V2_4_SE.h"


DefinePin_Mini_SE::DefinePin_Mini_SE()
{
    #if defined(__AVR_ATmega328P__)
    pinMode(LED, OUTPUT);
    pinMode(JO1, OUTPUT);
    pinMode(JO2, OUTPUT);
    pinMode(JO3, OUTPUT);
    pinMode(JO4, OUTPUT);
    pinMode(JO5, OUTPUT);
    pinMode(JO6, OUTPUT);
    pinMode(JO7, OUTPUT);
    pinMode(JO8, OUTPUT);
    pinMode(JO9, OUTPUT);
    pinMode(JO10, OUTPUT);    
    pinMode(JSN1, INPUT_PULLUP);
    pinMode(JSN2, INPUT_PULLUP);
    pinMode(JSN3, INPUT_PULLUP);
    pinMode(JSN4, INPUT_PULLUP);
    pinMode(JSN5, INPUT_PULLUP);
    pinMode(JSN6, INPUT_PULLUP);
    pinMode(JSN7, INPUT_PULLUP);
    #elif defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
        
    #else
        #error cpp選錯板子辣笨蛋!!!
    #endif
}


