#ifndef TANK_V2_0_h
#define TANK_V2_0_h

    #define LED   22  //PG5 MCU燈號
    #define EMO   85  //PG5 急停開關
    #define JO1   21  //PB6
    #define JO2   20  //PB5
    #define JO3   19  //PB4
    #define JO4   14  //PH6
    #define JO5   13  //PH5
    #define JO6   12  //PH4
    #define JO7   11  //PH3
    #define JO8   10  //PH2 
    #define JO9   9   //PH1 
    #define JO10  8   //PH0 
    #define JO11  7   //PE7
    #define JO12  6   //PE6
    #define JO13  5   //PE5
    #define JO14  4   //PE4
    #define JO15  3   //PE3
    #define JO16  2   //PE2
    #define JSN1   60  //PA7
    #define JSN2   59  //PG2
    #define JSN3   58  //PJ6
    #define JSN4   57  //PJ5
    #define JSN5   56  //PJ4
    #define JSN6   55  //PJ3
    #define JSN7   54  //PJ2
    #define JSN8   53  //PJ0
    #define JSN9   52  //PJ1
    #define JSN10  51  //PC7
    #define JSN11  50  //PC6
    #define JSN12  49  //PC5
    #define JSN13  48  //PC4  
    #define JSN14  47  //PC3  
    #define JSN15  46  //PC2  
    #define JSN16  45  //PC1  
    #define JSN17  44  //PC0  
    #define JSN18  43  //PG1  
    #define JSN19  42  //PG0  
    #define JSN20  41  //PD7  
    #define JSN21  40  //PD6  
    #define JSN22  39  //PD5  
    #define JSN23  38  //PD4  
    #define JSN24  37  //PD3  
    #define JSN25  36  //PD2
    #define JSN26  35  //PD1 SDA
    #define JSN27  34  //PD0 SCL
    #define JSN28  33  //PL7
    #define JSN29  32  //PL6
    #define JSN30  31  //PL5
    #define JSN31  30  //PL4
    #define JSN32  29  //PL3
    #define JSN33  28  //PL2
    #define JSN34  27  //PL1
    #define JSN35  26  //PL0
    #define JSN36  25  //PG4
    #define JSN37  24  //PG3
    #define JSN38  23  //PH7
    #define JLN1   76  //PF7 光柵
    #define JLN2   75  //PF6 
    #define JVN1   74  //PF5
    #define JVN2   73  //PF4
    #define JVN3   72  //PF3
    #define JVN4   71  //PF2
    #define JVN5   70  //PF1
    #define JVN6   69  //PF0
    #define J1_1   84  //PK7
    #define J1_2   83  //PK6
    #define J1_3   82  //PK5
    #define J1_4   81  //PK4
    #define J1_5   80  //PK3
    #define J1_6   79  //PK2
    #define J1_7   78  //PK13 
    #define J1_8   77  //PK0
    #define J2_1   68  //PJ7
    #define J2_2   67  //PA0
    #define J2_3   66  //PA1
    #define J2_4   65  //PA2
    #define J2_5   64  //PA3
    #define J2_6   63  //PA4
    #define J2_7   62  //PA5
    #define J2_8   61  //PA6
    


#endif